namespace Provider.RadEditor
{
    public class Class1
    {
        //this is only here to allow msbuild to successfully build this project
    }
}