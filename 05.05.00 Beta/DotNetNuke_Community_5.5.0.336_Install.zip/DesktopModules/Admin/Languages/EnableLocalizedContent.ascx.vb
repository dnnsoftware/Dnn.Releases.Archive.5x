﻿'
' DotNetNuke® - http://www.dotnetnuke.com
' Copyright (c) 2002-2009
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Collections.Generic

Imports DotNetNuke
Imports DotNetNuke.Services.Exceptions
Imports DotNetNuke.Services.Localization
Imports System.Globalization
Imports System.Linq
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.Entities.Modules.Actions
Imports DotNetNuke.Services.Installer
Imports DotNetNuke.Security.Permissions
Imports DotNetNuke.Web.UI.WebControls
Imports DotNetNuke.Entities.Modules
Imports Telerik.Web.UI
Imports DotNetNuke.UI.Utilities
Imports DotNetNuke.Services.Personalization

Namespace DotNetNuke.Modules.Admin.Languages

    Partial Class EnableLocalizedContent
        Inherits PortalModuleBase

#Region "Private Members"

        Private _PortalDefault As String = ""
        Private MyFileName As String = "EnableLocalizedContent.ascx"

#End Region

#Region "Protected Properties"

        Protected ReadOnly Property PortalDefault As String
            Get
                Return _PortalDefault
            End Get
        End Property

#End Region

        Private Sub BindDefaultLanguageSelector()
            Localization.LoadCultureDropDownList(languagesDropDown, CultureDropDownTypes.EnglishName, PortalDefault)
        End Sub

        Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
            Me.LocalResourceFile = Services.Localization.Localization.GetResourceFile(Me, "EnableLocalizedContent.ascx")
        End Sub

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            _PortalDefault = PortalSettings.DefaultLanguage
            BindDefaultLanguageSelector()
            defaultLanguageLabel.Language = PortalSettings.DefaultLanguage
            defaultLanguageLabel.Visible = True
        End Sub

        Protected Sub cancelButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cancelButton.Click
            'Redirect to refresh page (and skinobjects)
            Response.Redirect(NavigateURL(), True)
        End Sub

        Protected Sub updateButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles updateButton.Click
            PortalController.UpdatePortalSetting(PortalId, "ContentLocalizationEnabled", "True")

            If chkEnabled.Checked = True Then
                UpdatePortalDefault()
            End If

            'Localize Default Languagee
            LocalizePages(PortalSettings.DefaultLanguage)
            'if unchecked only publish default
            If populateCheckbox.Checked = False Then
                PublishLanguage(PortalSettings.DefaultLanguage, True)
            Else
                Dim locales As Dictionary(Of String, Locale)

                locales = LocaleController.Instance().GetLocales(PortalSettings.PortalId)
                For Each kvp As KeyValuePair(Of String, Locale) In locales
                    If LocaleController.Instance.IsEnabled(kvp.Value.Culture.ToString, PortalId) Then
                        PublishLanguage(kvp.Value.Culture.ToString, True)
                    End If
                Next
            End If

            'Redirect to refresh page (and skinobjects)
            Response.Redirect(NavigateURL(), True)
        End Sub

        Private Sub PublishLanguage(ByVal cultureCode As String, ByVal publish As Boolean)
            Dim enabledLanguages As Dictionary(Of String, Locale) = LocaleController.Instance().GetLocales(PortalId)
            Dim enabledlanguage As Locale = Nothing
            If enabledLanguages.TryGetValue(cultureCode, enabledlanguage) Then
                enabledlanguage.IsPublished = publish
                LocaleController.Instance().UpdatePortalLocale(enabledlanguage)
            End If
        End Sub

        Private Sub LocalizePages(ByVal cultureCode As String)
            TabController.LocalizePages(PortalId, cultureCode)
        End Sub

        Protected Function IsLanguageEnabled(ByVal Code As String) As Boolean
            Dim enabledLanguage As Locale = Nothing
            Return LocaleController.Instance().GetLocales(Me.ModuleContext.PortalId).TryGetValue(Code, enabledLanguage)
        End Function

        Private Sub UpdatePortalDefault()
            Dim language As Locale

            ' first check whether or not portal default language has changed
            Dim newDefaultLanguage As String = languagesDropDown.SelectedValue
            If newDefaultLanguage <> PortalSettings.DefaultLanguage Then
                If Not IsLanguageEnabled(newDefaultLanguage) Then
                    language = LocaleController.Instance().GetLocale(newDefaultLanguage)
                    Localization.AddLanguageToPortal(Me.ModuleContext.PortalId, language.LanguageId, True)
                End If

                ' update portal default language
                Dim objPortalController As New PortalController
                Dim objPortal As PortalInfo = objPortalController.GetPortal(PortalId)
                objPortal.DefaultLanguage = newDefaultLanguage
                objPortalController.UpdatePortalInfo(objPortal)

                _PortalDefault = newDefaultLanguage
            End If
        End Sub

        Protected Function IsDefaultLanguage(ByVal code As String) As Boolean
            Dim returnValue As Boolean = False
            If code = PortalDefault Then
                returnValue = True
            End If
            Return returnValue
        End Function

    End Class
End Namespace