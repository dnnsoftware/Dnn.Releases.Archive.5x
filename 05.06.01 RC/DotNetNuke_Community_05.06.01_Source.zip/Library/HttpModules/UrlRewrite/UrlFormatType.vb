Namespace DotNetNuke.HttpModules

    Public Enum UrlFormatType

        SearchFriendly
        HumanFriendly

    End Enum

End Namespace
