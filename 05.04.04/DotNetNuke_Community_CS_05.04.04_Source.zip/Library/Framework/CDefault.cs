//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System.Web.UI;
using System.Web.UI.HtmlControls;
namespace DotNetNuke.Framework
{
	public class CDefault : DotNetNuke.Framework.PageBase
	{
		public string Comment = "";
		public string Description = "";
		public string KeyWords = "";
		public string Copyright = "";
		public string Generator = "";
		public string Author = "";
		public new string Title = "";
		public override void Dispose()
		{
			base.Dispose();
		}
		public void AddStyleSheet(string id, string href, bool isFirst)
		{
			Control objCSS = this.FindControl("CSS");
			if (objCSS != null) {
				Control objCtrl = Page.Header.FindControl(id);
				if (objCtrl == null) {
					HtmlLink objLink = new HtmlLink();
					objLink.ID = id;
					objLink.Attributes["rel"] = "stylesheet";
					objLink.Attributes["type"] = "text/css";
					objLink.Href = href;
					if (isFirst) {
						int iLink;
						for (iLink = 0; iLink <= objCSS.Controls.Count - 1; iLink++) {
							if (objCSS.Controls[iLink] is HtmlLink) {
								break;
							}
						}
						objCSS.Controls.AddAt(iLink, objLink);
					} else {
						objCSS.Controls.Add(objLink);
					}
				}
			}
		}
		public void AddStyleSheet(string id, string href)
		{
			AddStyleSheet(id, href, false);
		}
		public void ScrollToControl(Control objControl)
		{
			if (DotNetNuke.UI.Utilities.ClientAPI.BrowserSupportsFunctionality(DotNetNuke.UI.Utilities.ClientAPI.ClientFunctionality.Positioning)) {
				DotNetNuke.UI.Utilities.ClientAPI.RegisterClientReference(this, DotNetNuke.UI.Utilities.ClientAPI.ClientNamespaceReferences.dnn_dom_positioning);
				DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(this, "ScrollToControl", objControl.ClientID, true);
				DotNetNuke.UI.Utilities.DNNClientAPI.AddBodyOnloadEventHandler(Page, "__dnn_setScrollTop();");
			}
		}
	}
}
