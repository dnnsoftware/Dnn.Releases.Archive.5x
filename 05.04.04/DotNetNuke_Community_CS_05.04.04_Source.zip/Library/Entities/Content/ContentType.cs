﻿using System;
using DotNetNuke.Common.Utilities;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using DotNetNuke.Entities.Modules;

namespace DotNetNuke.Entities.Content
{

    [Serializable()]
    public class ContentType : IHydratable
    {

        #region "Private Members"

        private int _ContentTypeId;

        private string _ContentType;
        #endregion

        #region "Constructors"

        public ContentType()
            : this(Null.NullString)
        {
        }

        public ContentType(string scopeType)
        {
            _ContentTypeId = Null.NullInteger;
            _ContentType = scopeType;
        }

        #endregion

        #region "Public Properties"

        public int ContentTypeId
        {
            get { return _ContentTypeId; }
            set { _ContentTypeId = value; }
        }

        public string Type
        {
            get { return _ContentType; }
            set { _ContentType = value; }
        }

        #endregion

        #region "IHydratable Implementation"

        public void Fill(System.Data.IDataReader dr)
        {
            ContentTypeId = Null.SetNullInteger(dr["ContentTypeID"]);
            Type = Null.SetNullString(dr["ContentType"]);
        }

        public int KeyID
        {
            get { return ContentTypeId; }
            set { ContentTypeId = value; }
        }

        #endregion

        public override string ToString()
        {
            return Type;
        }

    }
}

