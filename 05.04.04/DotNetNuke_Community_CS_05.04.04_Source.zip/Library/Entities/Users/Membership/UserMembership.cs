//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.ComponentModel;
using DotNetNuke.UI.WebControls;
namespace DotNetNuke.Entities.Users
{
	[Serializable()]
	public class UserMembership
	{
		private bool _Approved = true;
		private System.DateTime _CreatedDate;
		private bool _IsOnLine;
		private System.DateTime _LastActivityDate;
		private System.DateTime _LastLockoutDate;
		private System.DateTime _LastLoginDate;
		private System.DateTime _LastPasswordChangeDate;
		private bool _LockedOut = false;
		private bool _ObjectHydrated;
		private string _Password;
		private string _PasswordAnswer;
		private string _PasswordQuestion;
		private bool _UpdatePassword;
		private bool IsSuperUser;
		private UserInfo _User;
		public UserMembership(UserInfo user)
		{
			_User = user;
		}
		[SortOrder(9)]
		public bool Approved {
			get { return _Approved; }
			set { _Approved= value; }
		}
		[SortOrder(1), IsReadOnly(true)]
		public System.DateTime CreatedDate {
			get { return _CreatedDate; }
			set { _CreatedDate= value; }
		}
		[SortOrder(7)]
		public bool IsOnLine {
			get { return _IsOnLine; }
			set { _IsOnLine= value; }
		}
		[SortOrder(3), IsReadOnly(true)]
		public System.DateTime LastActivityDate {
			get { return _LastActivityDate; }
			set { _LastActivityDate= value; }
		}
		[SortOrder(5), IsReadOnly(true)]
		public System.DateTime LastLockoutDate {
			get { return _LastLockoutDate; }
			set { _LastLockoutDate= value; }
		}
		[SortOrder(2), IsReadOnly(true)]
		public System.DateTime LastLoginDate {
			get { return _LastLoginDate; }
			set { _LastLoginDate= value; }
		}
		[SortOrder(4), IsReadOnly(true)]
		public System.DateTime LastPasswordChangeDate {
			get { return _LastPasswordChangeDate; }
			set { _LastPasswordChangeDate= value; }
		}
		[SortOrder(8)]
		public bool LockedOut {
			get { return _LockedOut; }
			set { _LockedOut= value; }
		}
		[Browsable(false)]
		public string Password {
			get { return _Password; }
			set { _Password= value; }
		}
		[Browsable(false)]
		public string PasswordAnswer {
			get { return _PasswordAnswer; }
			set { _PasswordAnswer= value; }
		}
		[Browsable(false)]
		public string PasswordQuestion {
			get { return _PasswordQuestion; }
			set { _PasswordQuestion= value; }
		}
		[SortOrder(10)]
		public bool UpdatePassword {
			get { return _UpdatePassword; }
			set { _UpdatePassword= value; }
		}
		[Obsolete("Deprecated in DNN 5.1")]
		public UserMembership()
		{
			_User = new UserInfo();
		}
		[Obsolete("Deprecated in DNN 5.1")]
		[Browsable(false)]
		public string Email {
			get { return _User.Email; }
			set { _User.Email= value; }
		}
		[Obsolete("Deprecated in DNN 5.1")]
		[Browsable(false)]
		public bool ObjectHydrated {
			get { return _ObjectHydrated; }
			set { _ObjectHydrated = true; }
		}
		[Obsolete("Deprecated in DNN 5.1")]
		[Browsable(false)]
		public string Username {
			get { return _User.Username; }
			set { _User.Username= value; }
		}
	}
}
