//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

namespace DotNetNuke.Common.Utilities
{
	public class UrlLogInfo
	{
		private int _UrlLogID;
		private int _UrlTrackingID;
		private System.DateTime _ClickDate;
		private int _UserID;
		private string _FullName;
		public UrlLogInfo()
		{
		}
		public int UrlLogID {
			get { return _UrlLogID; }
			set { _UrlLogID= value; }
		}
		public int UrlTrackingID {
			get { return _UrlTrackingID; }
			set { _UrlTrackingID= value; }
		}
		public System.DateTime ClickDate {
			get { return _ClickDate; }
			set { _ClickDate= value; }
		}
		public int UserID {
			get { return _UserID; }
			set { _UserID= value; }
		}
		public string FullName {
			get { return _FullName; }
			set { _FullName= value; }
		}
	}
}
