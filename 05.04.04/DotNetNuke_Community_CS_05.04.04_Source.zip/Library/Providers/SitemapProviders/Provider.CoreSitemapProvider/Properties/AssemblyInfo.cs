
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Xml.Linq;
using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

// Review the values of the assembly attributes

[assembly: AssemblyTitle("DotNetNuke")]
[assembly: AssemblyDescription("Open Source Web Application Framework")]
[assembly: AssemblyCompany("DotNetNuke Corporation")]
[assembly: AssemblyProduct("http://www.dotnetnuke.com")]
[assembly: AssemblyCopyright("DotNetNuke® is copyright 2002-2008 by DotNetNuke Corporation. All Rights Reserved.")]
[assembly: AssemblyTrademark("DotNetNuke")]

[assembly: CLSCompliant(true)]
//The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("34127f21-2826-4b3b-bb87-78d6c9ef729f")]
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// <Assembly: AssemblyVersion("1.0.*")> 

[assembly: AssemblyVersion("5.2.0.0")]
