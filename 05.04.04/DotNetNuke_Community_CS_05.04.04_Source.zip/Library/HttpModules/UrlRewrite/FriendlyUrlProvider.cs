//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Text.RegularExpressions;
using System.Web;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Tabs;
using DotNetNuke.Framework.Providers;
using DotNetNuke.HttpModules;
namespace DotNetNuke.Services.Url.FriendlyUrl
{
	public class DNNFriendlyUrlProvider : FriendlyUrlProvider
	{
		private const string ProviderType = "friendlyUrl";
		private const string RegexMatchExpression = "[^a-zA-Z0-9 ]";
		private ProviderConfiguration _providerConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType);
		private bool _includePageName;
		private string _regexMatch;
		private string _fileExtension;
		private UrlFormatType _urlFormat = UrlFormatType.SearchFriendly;
		private static Regex _friendlyPathRegex = new Regex("[^?]*/Tab[Ii]d/(\\d+)/default.aspx$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private static Regex _friendlyReturn = new Regex("[^?]*/Tab[Ii]d/(\\d+)/ctl/([A-Z][a-z]+)/default.aspx(\\?returnurl=([^>]+))?$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
		public DNNFriendlyUrlProvider()
		{
			Provider objProvider = (Provider)_providerConfiguration.Providers[_providerConfiguration.DefaultProvider];
			if (!String.IsNullOrEmpty(objProvider.Attributes["includePageName"]))
			{
				_includePageName = bool.Parse(objProvider.Attributes["includePageName"]);
			} else {
				_includePageName = true;
			}
			if (!String.IsNullOrEmpty(objProvider.Attributes["regexMatch"])) {
				_regexMatch = objProvider.Attributes["regexMatch"];
			} else {
				_regexMatch = RegexMatchExpression;
			}
			if (!String.IsNullOrEmpty(objProvider.Attributes["fileExtension"])) {
				_fileExtension = objProvider.Attributes["fileExtension"];
			} else {
				_fileExtension = ".aspx";
			}
			if (!String.IsNullOrEmpty(objProvider.Attributes["urlFormat"])) {
				switch (objProvider.Attributes["urlFormat"].ToLower()) {
					case "searchfriendly":
						_urlFormat = UrlFormatType.SearchFriendly;
						break;
					case "humanfriendly":
						_urlFormat = UrlFormatType.HumanFriendly;
						break;
					default:
						_urlFormat = UrlFormatType.SearchFriendly;
						break;
				}
			}
		}
		public string FileExtension {
			get { return _fileExtension; }
		}
		public bool IncludePageName {
			get { return _includePageName; }
		}
		public string RegexMatch {
			get { return _regexMatch; }
		}
		public UrlFormatType UrlFormat {
			get { return _urlFormat; }
		}
		public override string FriendlyUrl(TabInfo tab, string path)
		{
			PortalSettings _portalSettings = PortalController.GetCurrentPortalSettings();
			return FriendlyUrl(tab, path, Common.Globals.glbDefaultPage, _portalSettings);
		}
		public override string FriendlyUrl(TabInfo tab, string path, string pageName)
		{
			PortalSettings _portalSettings = PortalController.GetCurrentPortalSettings();
			return FriendlyUrl(tab, path, pageName, _portalSettings);
		}
		public override string FriendlyUrl(TabInfo tab, string path, string pageName, PortalSettings settings)
		{
			return FriendlyUrl(tab, path, pageName, settings.PortalAlias.HTTPAlias);
		}
		public override string FriendlyUrl(TabInfo tab, string path, string pageName, string portalAlias)
		{
			string friendlyPath = path;
			string matchString = "";
			bool isPagePath = tab != null;
			friendlyPath = GetFriendlyAlias(path, portalAlias, isPagePath);
			friendlyPath = GetFriendlyQueryString(tab, friendlyPath, pageName);
			if ((UrlFormat == UrlFormatType.HumanFriendly)) 
			{
				if (tab != null)
				{
					if (_friendlyPathRegex.IsMatch(friendlyPath))
					{
						friendlyPath = GetFriendlyAlias("~/" + tab.TabPath.Replace("//", "/").TrimStart('/') + ".aspx", portalAlias, isPagePath);
					}
				} 
				else 
				{
					if (_friendlyReturn.IsMatch(friendlyPath))
					{
						Match sesMatch = _friendlyReturn.Match(friendlyPath);
						if ((sesMatch.Groups.Count > 2)) {
							switch (sesMatch.Groups[2].Value.ToLower()) {
								case "terms":
									friendlyPath = GetFriendlyAlias("~/" + sesMatch.Groups[2].Value + ".aspx", portalAlias, isPagePath);
									break;
								case "privacy":
									friendlyPath = GetFriendlyAlias("~/" + sesMatch.Groups[2].Value + ".aspx", portalAlias, isPagePath);
									break;
								case "login":
									if (!String.IsNullOrEmpty(sesMatch.Groups[4].Value.ToLower()))
									{
										friendlyPath = GetFriendlyAlias("~/" + sesMatch.Groups[2].Value + ".aspx?ReturnUrl=" + sesMatch.Groups[4].Value, portalAlias, isPagePath);
									} else {
										friendlyPath = GetFriendlyAlias("~/" + sesMatch.Groups[2].Value + ".aspx", portalAlias, isPagePath);
									}
									break;
								case "register":
									if (!String.IsNullOrEmpty(sesMatch.Groups[4].Value.ToLower())) {
										friendlyPath = GetFriendlyAlias("~/" + sesMatch.Groups[2].Value + ".aspx?ReturnUrl=" + sesMatch.Groups[4].Value, portalAlias, isPagePath);
									} else {
										friendlyPath = GetFriendlyAlias("~/" + sesMatch.Groups[2].Value + ".aspx", portalAlias, isPagePath);
									}
									break;
								default:
									return friendlyPath;
							}
						} 
						else 
						{
							return friendlyPath;
						}
					} 
					else
					{
						return friendlyPath;
					}
				}
			}
			friendlyPath = CheckPathLength(friendlyPath, path);
			return friendlyPath;
		}
		private string CheckPathLength(string friendlyPath, string originalpath)
		{
			if (friendlyPath.Length >= 260) {
				return Common.Globals.ResolveUrl(originalpath);
			} else {
				return friendlyPath;
			}
		}
		private string AddPage(string path, string pageName)
		{
			string friendlyPath = path;
			if ((friendlyPath.EndsWith("/"))) {
				friendlyPath = friendlyPath + pageName;
			} else {
				friendlyPath = friendlyPath + "/" + pageName;
			}
			return friendlyPath;
		}
		private string GetFriendlyAlias(string path, string portalAlias, bool IsPagePath)
		{
			string friendlyPath = path;
			string matchString = "";
			if (portalAlias != Null.NullString) {
				if (HttpContext.Current.Items["UrlRewrite:OriginalUrl"] != null) {
					string originalUrl = HttpContext.Current.Items["UrlRewrite:OriginalUrl"].ToString();
					Match portalMatch = Regex.Match(originalUrl, "^" + Common.Globals.AddHTTP(portalAlias), RegexOptions.IgnoreCase);
					if (!object.ReferenceEquals(portalMatch, Match.Empty)) {
						matchString = Common.Globals.AddHTTP(portalAlias);
					}
					if ((String.IsNullOrEmpty(matchString))) 
					{
						portalMatch = Regex.Match(originalUrl, "^?alias=" + portalAlias, RegexOptions.IgnoreCase);
						if (!object.ReferenceEquals(portalMatch, Match.Empty)) {
							matchString = Common.Globals.AddHTTP(portalAlias);
						}
					}

					if ((String.IsNullOrEmpty(matchString))) 
					{
                        //Manage the special case of child portals 
                        //http://www.domain.com/child/default.aspx
                        string tempurl  = HttpContext.Current.Request.Url.Host + DotNetNuke.Common.Globals.ResolveUrl(friendlyPath);
                       if( tempurl.Contains(portalAlias))
					   {
                            matchString = DotNetNuke.Common.Globals.AddHTTP(portalAlias);
                       }
                    }

                    if ((String.IsNullOrEmpty(matchString))) 
					{
                        // manage the case where the current hostname is www.domain.com and the portalalias is domain.com
                        // (this occurs when www.domain.com is not listed as portal alias for the portal, but domain.com is)
                        portalMatch = Regex.Match(originalUrl, "^" + DotNetNuke.Common.Globals.AddHTTP("www." + portalAlias), RegexOptions.IgnoreCase);
                        if( portalMatch != Match.Empty)
						{
							matchString = DotNetNuke.Common.Globals.AddHTTP("www." + portalAlias);
                        }
                    }
				}
			}
			if ((!String.IsNullOrEmpty(matchString))) {
				if ((path.IndexOf("~") != -1)) {
					friendlyPath = friendlyPath.Replace("~", matchString);
				} else {
					friendlyPath = matchString + friendlyPath;
				}
			} else {
				friendlyPath = Common.Globals.ResolveUrl(friendlyPath);
			}
			if (friendlyPath.StartsWith("//") && IsPagePath) {
				friendlyPath = friendlyPath.Substring(1);
			}
			return friendlyPath;
		}
		private string GetFriendlyQueryString(TabInfo tab, string path, string pageName)
		{
			string friendlyPath = path;
			Match queryStringMatch = Regex.Match(friendlyPath, "(.[^\\\\?]*)\\\\?(.*)", RegexOptions.IgnoreCase);
			string queryStringSpecialChars = "";
			if (!object.ReferenceEquals(queryStringMatch, Match.Empty)) {
				friendlyPath = queryStringMatch.Groups[1].Value;
				friendlyPath = Regex.Replace(friendlyPath, Common.Globals.glbDefaultPage, "", RegexOptions.IgnoreCase);
				string queryString = queryStringMatch.Groups[2].Value.Replace("&amp;", "&");
				if ((queryString.StartsWith("?"))) {
					queryString = queryString.TrimStart(Convert.ToChar("?"));
				}
				string[] nameValuePairs = queryString.Split(Convert.ToChar("&"));
				for (int i = 0; i <= nameValuePairs.Length - 1; i++) {
					string pathToAppend = "";
					string[] pair = nameValuePairs[i].Split(Convert.ToChar("="));
					if ((friendlyPath.EndsWith("/"))) {
						pathToAppend = pathToAppend + pair[0];
					} else {
						pathToAppend = pathToAppend + "/" + pair[0];
					}
					if ((pair.Length > 1)) {
						if ((!String.IsNullOrEmpty(pair[1]))) {
							if ((Regex.IsMatch(pair[1], _regexMatch) == false)) {
								if ((pair[0].ToLower() == "tabid")) {
									if ((Regex.IsMatch(pair[1],"^\\d+$"))) {
										if (tab != null) {
											int tabId = Convert.ToInt32(pair[1]);
											if ((tab.TabID == tabId)) {
												if ((tab.TabPath != Null.NullString) && IncludePageName) {
													pathToAppend = tab.TabPath.Replace("//", "/").TrimStart('/') + "/" + pathToAppend;
												}
											}
										}
									}
								}
								pathToAppend = pathToAppend + "/" + System.Web.HttpUtility.UrlPathEncode(pair[1]);
							} else {
								if (String.IsNullOrEmpty(queryStringSpecialChars))
								{
									queryStringSpecialChars = pair[0] + "=" + pair[1];
								} else {
									queryStringSpecialChars = queryStringSpecialChars + "&" + pair[0] + "=" + pair[1];
								}
								pathToAppend = "";
							}
						} else {
							pathToAppend = pathToAppend + "/" + System.Web.HttpUtility.UrlPathEncode((' ').ToString());
						}
					}
					friendlyPath = friendlyPath + pathToAppend;
				}
			}
			if ((!String.IsNullOrEmpty(queryStringSpecialChars))) {
				return AddPage(friendlyPath, pageName) + "?" + queryStringSpecialChars;
			} else {
				return AddPage(friendlyPath, pageName);
			}
		}
	}
}
