using System;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System.ComponentModel;
using System.Web.UI.WebControls;
using DotNetNuke.Services.Localization;
using System.Web.UI;

namespace DotNetNuke.Web.UI.WebControls
{

	public class DnnImageTextButton : System.Web.UI.WebControls.ImageButton, DotNetNuke.Web.UI.ILocalizable
	{

		#region "Private Members"

		private bool _Localize = true;
		private string _LocalResourceFile;

		private HyperLink _TextLinkControl = null;
		#endregion

		#region "Constructors"

		public DnnImageTextButton()
		{
			CssClass = "dnnImageTextButton";
			DisabledCssClass = "dnnImageTextButton disabled";
		}

		#endregion

		#region "Public Properties"

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public new string ConfirmMessage
		{
			get { return ViewState["ConfirmMessage"] == null ? string.Empty : (string)ViewState["ConfirmMessage"]; }
			set { ViewState["ConfirmMessage"] = value; }
		}

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public override string CssClass
		{
			get { return ViewState["CssClass"] == null ? string.Empty : (string)ViewState["CssClass"]; }
			set { ViewState["CssClass"] = value; }
		}

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public string DisabledCssClass
		{
			get { return ViewState["DisabledCssClass"] == null ? string.Empty : (string)ViewState["DisabledCssClass"]; }
			set { ViewState["DisabledCssClass"] = value; }
		}

		[Bindable(true)]
		[Category("Behavior")]
		[DefaultValue("")]
		[Localizable(true)]
		public string DisabledImageUrl
		{
			get { return ViewState["DisabledImageUrl"] == null ? string.Empty : (string)ViewState["DisabledImageUrl"]; }
			set { ViewState["DisabledImageUrl"] = value; }
		}

		public override string ImageUrl
		{
			get { return base.ImageUrl; }
			set { base.ImageUrl = value; }
		}

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public new string Text
		{
			get { return ViewState["Text"] == null ? string.Empty : (string)ViewState["Text"]; }
			set { ViewState["Text"] = value; }
		}

		#endregion


		private HyperLink TextLinkControl
		{
			get
			{
				if (_TextLinkControl == null)
				{
					_TextLinkControl = new HyperLink();
				}
				return _TextLinkControl;
			}
		}

		protected override void OnPreRender(System.EventArgs e)
		{
			base.OnPreRender(e);

			LocalResourceFile = Utilities.GetLocalResourceFile(this);

			if ((!string.IsNullOrEmpty(ConfirmMessage)))
			{
				string msg = ConfirmMessage;
				if ((Localize))
				{
					msg = Localization.GetString(ConfirmMessage, LocalResourceFile);
				}
				//must be done before render
				OnClientClick = Utilities.GetOnClientClickConfirm(this, msg);
			}
		}

		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			LocalizeStrings();

			HyperLink textLink = new HyperLink();
			textLink.Text = Text;
			textLink.ToolTip = ToolTip;

			if ((!Enabled))
			{
				if ((!string.IsNullOrEmpty(DisabledCssClass)))
				{
					CssClass = DisabledCssClass;
				}
				ImageUrl = GetImageUrl(Enabled);
				textLink.NavigateUrl = "javascript:void(0);";
			}
			else
			{
				textLink.NavigateUrl = "javascript:document.getElementById('" + ClientID + "').click();";
			}

			writer.AddAttribute("class", CssClass);
			writer.RenderBeginTag("span");

			base.Render(writer);
			textLink.RenderControl(writer);

			writer.RenderEndTag();
		}

		private string GetImageUrl(bool enabled)
		{
			if ((!enabled && !string.IsNullOrEmpty(this.DisabledImageUrl)))
			{
				return DisabledImageUrl;
			}
			else if ((!string.IsNullOrEmpty(ImageUrl)))
			{
				string ext = System.IO.Path.GetExtension(ImageUrl);
				string imageName = System.IO.Path.GetFileNameWithoutExtension(ImageUrl);
				string fullImgName = System.IO.Path.GetFileName(ImageUrl);

				if ((!string.IsNullOrEmpty(ext) && !string.IsNullOrEmpty(imageName) && !string.IsNullOrEmpty(fullImgName)))
				{
					try
					{
						string disabledImg = ImageUrl.Replace(fullImgName, imageName + "_Disabled" + ext);
						if ((System.IO.File.Exists(Page.Server.MapPath(disabledImg))))
						{
							return disabledImg;
						}
					}
					catch (Exception ex)
					{
						//return default
					}
				}
			}

			return ImageUrl;
		}

		#region "ILocalizable Implementation"

		public bool Localize
		{
			get { return _Localize; }
			set { _Localize = value; }
		}

		public string LocalResourceFile
		{
			get { return _LocalResourceFile; }
			set { _LocalResourceFile = value; }
		}

		public virtual void LocalizeStrings()
		{
			if ((Localize))
			{
				if ((!string.IsNullOrEmpty(ToolTip)))
				{
					ToolTip = Localization.GetString(ToolTip, LocalResourceFile);
				}

				if ((!string.IsNullOrEmpty(Text)))
				{
					Text = Localization.GetString(Text, LocalResourceFile);

					if ((string.IsNullOrEmpty(ToolTip)))
					{
						ToolTip = Localization.GetString(string.Format("{0}.ToolTip", Text), LocalResourceFile);
					}

					if ((string.IsNullOrEmpty(ToolTip)))
					{
						ToolTip = Text;
					}
				}
			}
		}

		#endregion

	}

}
