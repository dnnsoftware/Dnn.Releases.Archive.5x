using System;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System.ComponentModel;
using System.Web.UI.WebControls;
using DotNetNuke.Services.Localization;

namespace DotNetNuke.Web.UI.WebControls
{

	public class DnnImageTextLink : System.Web.UI.WebControls.WebControl, DotNetNuke.Web.UI.ILocalizable
	{

		#region "Private Members"

		private HyperLink _ImageHyperlinkControl = null;
		private bool _Localize = true;
		private string _LocalResourceFile;

		private HyperLink _TextHyperlinkControl = null;
		#endregion

		public DnnImageTextLink()
			: base("span")
		{
			CssClass = "dnnImageTextLink";
			DisabledCssClass = "dnnImageTextLink disabled";
		}

		protected override void CreateChildControls()
		{
			Controls.Clear();

			Controls.Add(ImageHyperlinkControl);
			Controls.Add(TextHyperlinkControl);
		}

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public string Text
		{
			get { return TextHyperlinkControl.Text; }
			set { TextHyperlinkControl.Text = value; }
		}

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public override string ToolTip
		{
			get { return TextHyperlinkControl.ToolTip; }
			set { TextHyperlinkControl.ToolTip = value; }
		}

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public string ImageUrl
		{
			get { return ImageHyperlinkControl.ImageUrl; }
			set { ImageHyperlinkControl.ImageUrl = value; }
		}

		[Bindable(true)]
		[Category("Behavior")]
		[DefaultValue("")]
		[Localizable(true)]
		public string NavigateUrl
		{
			get { return TextHyperlinkControl.NavigateUrl; }
			set
			{
				TextHyperlinkControl.NavigateUrl = value;
				ImageHyperlinkControl.NavigateUrl = value;
			}
		}

		[Bindable(true)]
		[Category("Behavior")]
		[DefaultValue("")]
		[Localizable(true)]
		public string Target
		{
			get { return TextHyperlinkControl.Target; }
			set
			{
				TextHyperlinkControl.Target = value;
				ImageHyperlinkControl.Target = value;
			}
		}

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public string DisabledImageUrl
		{
			get { return ViewState["DisabledImageUrl"] == null ? string.Empty : (string)ViewState["DisabledImageUrl"]; }
			set { ViewState["DisabledImageUrl"] = value; }
		}

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public string DisabledCssClass
		{
			get { return ViewState["DisabledCssClass"] == null ? string.Empty : (string)ViewState["DisabledCssClass"]; }
			set { ViewState["DisabledCssClass"] = value; }
		}

		private HyperLink ImageHyperlinkControl
		{
			get
			{
				if (_ImageHyperlinkControl == null)
				{
					_ImageHyperlinkControl = new HyperLink();
				}
				return _ImageHyperlinkControl;
			}
		}

		private HyperLink TextHyperlinkControl
		{
			get
			{
				if (_TextHyperlinkControl == null)
				{
					_TextHyperlinkControl = new HyperLink();
				}
				return _TextHyperlinkControl;
			}
		}

		private string GetImageUrl(bool enabled)
		{
			if ((!enabled && !string.IsNullOrEmpty(this.DisabledImageUrl)))
			{
				return DisabledImageUrl;
			}
			else if ((!string.IsNullOrEmpty(ImageUrl)))
			{
				string ext = System.IO.Path.GetExtension(ImageUrl);
				string imageName = System.IO.Path.GetFileNameWithoutExtension(ImageUrl);
				string fullImgName = System.IO.Path.GetFileName(ImageUrl);

				if ((!string.IsNullOrEmpty(ext) && !string.IsNullOrEmpty(imageName) && !string.IsNullOrEmpty(fullImgName)))
				{
					try
					{
						string disabledImg = ImageUrl.Replace(fullImgName, imageName + "_Disabled" + ext);
						if ((System.IO.File.Exists(Page.Server.MapPath(disabledImg))))
						{
							return disabledImg;
						}
					}
					catch (Exception ex)
					{
						//return default
					}
				}
			}

			return ImageUrl;
		}

		#region "Protected Methods"

		protected override void OnPreRender(System.EventArgs e)
		{
			base.OnPreRender(e);
			LocalResourceFile = Utilities.GetLocalResourceFile(this);
		}

		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			LocalizeStrings();

			if ((!Enabled))
			{
				if ((!string.IsNullOrEmpty(DisabledCssClass)))
				{
					CssClass = DisabledCssClass;
				}
				ImageUrl = GetImageUrl(Enabled);
				NavigateUrl = "javascript:void(0);";
			}

			ImageHyperlinkControl.ToolTip = ToolTip;
			ImageHyperlinkControl.Attributes.Add("alt", Text);

			base.RenderBeginTag(writer);
			base.RenderChildren(writer);
			base.RenderEndTag(writer);
		}

		#endregion

		#region "ILocalizable Implementation"

		public bool Localize
		{
			get { return _Localize; }
			set { _Localize = value; }
		}

		public string LocalResourceFile
		{
			get { return _LocalResourceFile; }
			set { _LocalResourceFile = value; }
		}

		public virtual void LocalizeStrings()
		{
			if ((Localize))
			{
				if ((!string.IsNullOrEmpty(ToolTip)))
				{
					ToolTip = Localization.GetString(ToolTip, LocalResourceFile);
				}

				if ((!string.IsNullOrEmpty(Text)))
				{
					Text = Localization.GetString(Text, LocalResourceFile);

					if ((string.IsNullOrEmpty(ToolTip)))
					{
						ToolTip = Localization.GetString(string.Format("{0}.ToolTip", Text), LocalResourceFile);
					}

					if ((string.IsNullOrEmpty(ToolTip)))
					{
						ToolTip = Text;
					}
				}
			}
		}

		#endregion

	}

}
