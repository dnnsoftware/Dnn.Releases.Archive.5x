#region Copyright

// 
// DotNetNuke� - http://www.dotnetnuke.com
// Copyright (c) 2002-2011
// by DotNetNuke Corporation
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.

#endregion

#region Usings

using System;
using System.Web.UI;
using System.Web.UI.WebControls;

using DotNetNuke.Application;
using DotNetNuke.Entities.Host;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Users;
using DotNetNuke.Security;
using DotNetNuke.Security.Permissions;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Services.Localization;
using DotNetNuke.Services.Upgrade;
using DotNetNuke.UI.Utilities;
using DotNetNuke.Web.UI.WebControls;

using Globals = DotNetNuke.Common.Globals;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

#endregion

namespace DotNetNuke.UI.ControlPanels
{
    public partial class RibbonBar : ControlPanelBase
    {
        #region "Private Methods"

        private void Localize()
        {
            RibbonBarTabs.Tabs[0].Text = Localization.GetString("Tab_CommonTasks", LocalResourceFile);
            RibbonBarTabs.Tabs[1].Text = Localization.GetString("Tab_CurrentPage", LocalResourceFile);
            RibbonBarTabs.Tabs[2].Text = Localization.GetString("Tab_Site", LocalResourceFile);
            RibbonBarTabs.Tabs[3].Text = Localization.GetString("Tab_Host", LocalResourceFile);

            cmdAdmin.Text = Localization.GetString("AdminConsole", LocalResourceFile);
            cmdAdmin.ToolTip = Localization.GetString("AdminConsole.ToolTip", LocalResourceFile);
            cmdHost.Text = Localization.GetString("HostConsole", LocalResourceFile);
            cmdHost.ToolTip = Localization.GetString("HostConsole.ToolTip", LocalResourceFile);

            Control ctrl = G101.FindControl("SiteNewPage");
            if (((ctrl != null) && ctrl is DnnRibbonBarTool))
            {
                var toolCtrl = (DnnRibbonBarTool) ctrl;
                toolCtrl.Text = Localization.GetString("SiteNewPage", LocalResourceFile);
                toolCtrl.ToolTip = Localization.GetString("SiteNewPage.ToolTip", LocalResourceFile);
            }

            ListItem lstItem = optMode.Items.FindByValue("VIEW");
            if (((lstItem != null)))
                lstItem.Text = Localization.GetString("ModeView", LocalResourceFile);
            lstItem = optMode.Items.FindByValue("EDIT");
            if (((lstItem != null)))
                lstItem.Text = Localization.GetString("ModeEdit", LocalResourceFile);
            lstItem = optMode.Items.FindByValue("LAYOUT");
            if (((lstItem != null)))
                lstItem.Text = Localization.GetString("ModeLayout", LocalResourceFile);
        }

        private void SetMode(bool Update)
        {
            if (Update)
                SetUserMode(optMode.SelectedValue);

            if (!TabPermissionController.CanAddContentToPage())
                optMode.Items.Remove(optMode.Items.FindByValue("LAYOUT"));

            switch (UserMode)
            {
                case PortalSettings.Mode.View:
                    optMode.Items.FindByValue("VIEW").Selected = true;
                    break;
                case PortalSettings.Mode.Edit:
                    optMode.Items.FindByValue("EDIT").Selected = true;
                    break;
                case PortalSettings.Mode.Layout:
                    optMode.Items.FindByValue("LAYOUT").Selected = true;
                    break;
            }
        }

        private void SetVisibility(bool Toggle)
        {
            if (Toggle)
                SetVisibleMode(!IsVisible);
        }

        #endregion

        #region "Event Handlers"

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            ID = "RibbonBar.ascx";
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            cmdVisibility.Click += cmdVisibility_Click;
            optMode.SelectedIndexChanged += optMode_SelectedIndexChanged;

            try
            {
                RibbonBarTabs.Tabs[2].Visible = false;
                Pages.PageViews[2].Visible = false;
                RibbonBarTabs.Tabs[3].Visible = false;
                Pages.PageViews[3].Visible = false;
                cmdHost.Visible = false;
                cmdAdmin.Visible = false;

                //AddModule group
                //CommonTabAddModuleGroup.Visible = TabPermissionController.CanAddContentToPage()

                //AddPage groups
                //CommonTabAddPageGroup.Visible = TabPermissionController.CanAddPage()

                Control copyPageButton = G5.FindControl("CopyPage");
                if ((copyPageButton != null))
                {
                    copyPageButton.Visible =
                        LocaleController.Instance.IsDefaultLanguage(
                            LocaleController.Instance.GetCurrentLocale(PortalSettings.PortalId).Code);
                }


                if ((Request.IsAuthenticated))
                {
                    UserInfo user = UserController.GetCurrentUserInfo();
                    if (((user != null)))
                    {
                        RibbonBarTabs.Tabs[2].Visible = user.IsInRole(PortalSettings.Current.AdministratorRoleName);
                        Pages.PageViews[2].Visible = user.IsInRole(PortalSettings.Current.AdministratorRoleName);
                        RibbonBarTabs.Tabs[3].Visible = user.IsSuperUser;
                        Pages.PageViews[3].Visible = user.IsSuperUser;
                        cmdHost.Visible = user.IsSuperUser;
                        cmdAdmin.Visible = user.IsInRole(PortalSettings.Current.AdministratorRoleName);
                    }
                }

                if (IsPageAdmin())
                {
                    Web.UI.Utilities.ApplySkin(RibbonBarTabs, "", "", "RibbonBar");
                    RB.Visible = true;
                    cmdVisibility.Visible = true;
                    RB_RibbonBar.Visible = true;

                    //Hide Support icon in CE
                    if ((DotNetNukeContext.Current.Application.Name == "DNNCORP.CE"))
                        G16.FindControl("SupportTickets").Visible = false;

                    Localize();

                    if (!Page.IsPostBack)
                    {
                        UserInfo objUser = UserController.GetCurrentUserInfo();
                        if ((objUser != null))
                        {
                            if (objUser.IsSuperUser)
                            {
                                hypMessage.ImageUrl =
                                    Upgrade.UpgradeIndicator(DotNetNukeContext.Current.Application.Version,
                                                             Request.IsLocal, Request.IsSecureConnection);
                                if (!string.IsNullOrEmpty(hypMessage.ImageUrl))
                                {
                                    hypMessage.ToolTip = Localization.GetString("hypUpgrade.Text", LocalResourceFile);
                                    hypMessage.NavigateUrl = Upgrade.UpgradeRedirect();
                                }
                                // branding
                            }
                            else
                            {
                                if (PortalSecurity.IsInRole(PortalSettings.AdministratorRoleName) &&
                                    Host.DisplayCopyright)
                                {
                                    hypMessage.ImageUrl = "~/images/branding/iconbar_logo.png";
                                    hypMessage.ToolTip = DotNetNukeContext.Current.Application.Description;
                                    hypMessage.NavigateUrl = Localization.GetString("hypMessageUrl.Text",
                                                                                    LocalResourceFile);
                                }
                                else
                                    hypMessage.Visible = false;
                            }
                        }
                        SetMode(false);
                        SetVisibility(false);
                    }
                }
                else if (IsModuleAdmin())
                {
                    RB.Visible = true;
                    cmdVisibility.Visible = false;
                    RB_RibbonBar.Visible = false;
                    if (!Page.IsPostBack)
                    {
                        SetMode(false);
                        SetVisibility(false);
                    }
                }
                else
                    RB.Visible = false;
                //Module failed to load
            } catch (Exception exc)
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            //Set initial value
            DNNClientAPI.EnableMinMax(imgVisibility, RB_RibbonBar, PortalSettings.DefaultControlPanelVisibility,
                                      Globals.ApplicationPath + "/images/collapse.gif",
                                      Globals.ApplicationPath + "/images/expand.gif",
                                      DNNClientAPI.MinMaxPersistanceType.Personalization, "Usability",
                                      "ControlPanelVisible" + PortalSettings.PortalId);

            //Dim rbTool As New DotNetNuke.Web.UI.WebControls.DnnRibbonBarTool
            //Dim webServersTool As New DotNetNuke.Web.UI.WebControls.RibbonBarToolInfo("WebServerManager", True, False, "", "WebServerManager", "")
            //Dim healthMonitorTool As New DotNetNuke.Web.UI.WebControls.RibbonBarToolInfo("HealthMonitoring", True, False, "", "HealthMonitoring", "")
            //webServersTool.

            //rbTool.AllTools.Add(
            //Dim profileSelectedTab As Object = DotNetNuke.Services.Personalization.Personalization.GetProfile("RibbonBar", "SelectedTabIndex")
            //If (Not IsNothing(profileSelectedTab)) Then
            //	If (TypeOf profileSelectedTab Is Integer) Then
            //		Dim selectedTabIndex As Integer = DirectCast(profileSelectedTab, Integer)
            //		If (RibbonBarTabs.Tabs.Count > selectedTabIndex) Then
            //			RibbonBarTabs.SelectedIndex = selectedTabIndex
            //			Pages.SelectedIndex = selectedTabIndex
            //		End If
            //	End If
            //End If
        }

        protected void cmdVisibility_Click(object sender, EventArgs e)
        {
            SetVisibility(true);
            Response.Redirect(Request.RawUrl, true);
        }

        //Make async Ajax request, don't interrupt the flow of using the tabs
        //Protected Sub OnClick_RibbonBarTabs(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonBarTabs.TabClick
        //	DotNetNuke.Services.Personalization.Personalization.SetProfile("RibbonBar", "SelectedTabIndex", RibbonBarTabs.SelectedIndex)
        //End Sub

        protected void optMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!Page.IsCallback)
            {
                SetMode(true);
                Response.Redirect(Request.RawUrl, true);
            }
        }

        #endregion
    }
}