/*
  DotNetNuke� - http://www.dotnetnuke.com
  Copyright (c) 2002-2008
  by DotNetNuke Corporation
 
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
  documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
  the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
  to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 
  The above copyright notice and this permission notice shall be included in all copies or substantial portions 
  of the Software.
 
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
  DEALINGS IN THE SOFTWARE.

	''' -----------------------------------------------------------------------------
	''' <remarks>
	''' </remarks>
	''' <history>
	'''     Version 1.0.0: Nov. 7, 2008, Nik Kalyani, nik.kalyani@dotnetnuke.com 
	''' </history>
	''' -----------------------------------------------------------------------------
*/

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// BEGIN: FlashWidget class                                                                              //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
DotNetNuke.UI.WebControls.Widgets.FlashWidget = function(widget)
{
    DotNetNuke.UI.WebControls.Widgets.FlashWidget.initializeBase(this, [widget]);
    this._height = 200;
    this._width = 400;
    this._url = "";
    this._elementId = "";
    this._styleclass = "";
    this._align = "";
    this._play = "";
    this._loop = "";
    this._menu = "";
    this._quality = "";
    this._scale = "";
    this._salign = "";
    this._wmode = "";
    this._bgcolor = "";
    this._base = "";
    this._swliveconnect = "";
    this._devicefont = "";
    this._allowscriptaccess = "";
    this._seamlesstabbing = "";
    this._allowfullscreen = "";
    this._allownetworking = "";
    this._flashvars = "";
}

DotNetNuke.UI.WebControls.Widgets.FlashWidget.prototype =
{
    // BEGIN: render
    render:
        function()
        {
            var params = this._widget.childNodes;
            for (var p = 0; p < params.length; p++)
            {
                try
                {
                    var paramName = params[p].name.toLowerCase();
                    switch (paramName)
                    {
                        case "height": if (params[p].value > 0) this._height = params[p].value; break;
                        case "width": if (params[p].value > 0) this._width = params[p].value; break;
                        case "url": this._url = params[p].value; break;
                        case "elementid": this._elementId = params[p].value; break;
                        case "styleclass": this._styleclass = params[p].value; break;
                        case "align": this._align = params[p].value; break;
                        case "play": this._play = params[p].value; break;
                        case "loop": this._loop = params[p].value; break;
                        case "menu": this._menu = params[p].value; break;
                        case "quality": this._quality = params[p].value; break;
                        case "scale": this._scale = params[p].value; break;
                        case "salign": this._salign = params[p].value; break;
                        case "wmode": this._wmode = params[p].value; break;
                        case "bgcolor": this._bgcolor = params[p].value; break;
                        case "base": this._base = params[p].value; break;
                        case "swliveconnect": this._swliveconnect = params[p].value; break;
                        case "devicefont": this._devicefont = params[p].value; break;
                        case "allowscriptaccess": this._allowscriptaccess = params[p].value; break;
                        case "seamlesstabbing": this._seamlesstabbing = params[p].value; break;
                        case "allowfullscreen": this._allowfullscreen = params[p].value; break;
                        case "allownetworking": this._allownetworking = params[p].value; break;
                        case "flashvars": this._flashvars = params[p].value; break;
                    }
                }
                catch (e)
                {
                }
            }
            if (this._url != "")
            {
                var self = this;
                if (typeof (swfobject) === "undefined")
                    $.getScript($dnn.baseResourcesUrl + "Widgets/DNN/FlashWidgetResources/swfobject.js", function() { self._internalRender(); });
                else
                    this._internalRender();
            }

        },
    // END: render

    _internalRender:
        function()
        {

            var att = {};
            att.data = this._url;
            att.width = this._width;
            att.height = this._height;
            att.styleclass = this._styleclass;
            att.align = this._align;

            var par = {};
            if (this._play != "") par.play = this._play;
            if (this._loop != "") par.loop = this._loop;
            if (this._menu != "") par.menu = this._menu;
            if (this._quality != "") par.quality = this._quality;
            if (this._scale != "") par.scale = this._scale;
            if (this._salign != "") par.salign = this._salign;
            if (this._wmode != "") par.wmode = this._wmode;
            if (this._bgcolor != "") par.bgcolor = this._bgcolor;
            if (this._base != "") par.base = this._base;
            if (this._swliveconnect != "") par.swliveconnect = this._swliveconnect;
            if (this._devicefont != "") par.devicefont = this._devicefont;
            if (this._allowscriptaccess != "") par.allowscriptaccess = this._allowscriptaccess;
            if (this._seamlesstabbing != "") par.seamlesstabbing = this._seamlesstabbing;
            if (this._allowfullscreen != "") par.allowfullscreen = this._allowfullscreen;
            if (this._allownetworking != "") par.allownetworking = this._allownetworking;
            if (this._flashvars != "") par.flashvars = this._flashvars;



            if (this._elementId == "")
            {
                var flashObject = swfobject.createSWF(att, par, this._widget.id);
                DotNetNuke.UI.WebControls.Widgets.FlashWidget.callBaseMethod(this, "render", [flashObject]);
            }
            else
            {
                swfobject.createSWF(att, par, this._elementId);
                var div = document.createElement("div");
                DotNetNuke.UI.WebControls.Widgets.FlashWidget.callBaseMethod(this, "render", [div]);
            }

        }
}

DotNetNuke.UI.WebControls.Widgets.FlashWidget.inheritsFrom(DotNetNuke.UI.WebControls.Widgets.BaseWidget);
DotNetNuke.UI.WebControls.Widgets.FlashWidget.registerClass("DotNetNuke.UI.WebControls.Widgets.FlashWidget", DotNetNuke.UI.WebControls.Widgets.BaseWidget);
DotNetNuke.UI.WebControls.Widgets.renderWidgetType("DotNetNuke.UI.WebControls.Widgets.FlashWidget");
// END: FlashWidget class
