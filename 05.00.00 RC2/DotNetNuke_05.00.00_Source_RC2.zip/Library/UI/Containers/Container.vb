'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2008
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Web.UI

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Actions
Imports System.IO
Imports DotNetNuke.Entities.Modules.Communications
Imports DotNetNuke.UI.Modules
Imports DotNetNuke.UI.Skins
Imports DotNetNuke.Entities.Host

Namespace DotNetNuke.UI.Containers

    ''' -----------------------------------------------------------------------------
    ''' Project	 : DotNetNuke
    ''' Namespace: DotNetNuke.UI.Containers
    ''' Class	 : Container
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Container is the base for the Containers 
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	07/04/2005	Documented
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class Container
        Inherits System.Web.UI.UserControl

#Region "Private Members"

        Private _Communicator As New ModuleCommunicate
        Private _ContentPane As HtmlContainerControl
        Private _ModuleConfiguration As ModuleInfo
        Private _ModuleHost As ModuleHost

#End Region

#Region "Protected Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Content Pane Control (Id="ContentPane")
        ''' </summary>
        ''' <returns>An HtmlContainerControl</returns>
        ''' <history>
        ''' 	[cnurse]	12/05/2007  created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property ContentPane() As HtmlContainerControl
            Get
                If _ContentPane Is Nothing Then
                    _ContentPane = TryCast(FindControl(glbDefaultPane), HtmlContainerControl)
                End If
                Return _ContentPane
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Portal Settings for the current Portal
        ''' </summary>
        ''' <returns>A PortalSettings object</returns>
        ''' <history>
        ''' 	[cnurse]	12/05/2007  created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property PortalSettings() As PortalSettings
            Get
                PortalSettings = PortalController.GetCurrentPortalSettings
            End Get
        End Property

#End Region

#Region "Public Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the ModuleInfo object that this container is displaying
        ''' </summary>
        ''' <returns>A ModuleInfo object</returns>
        ''' <history>
        ''' 	[cnurse]	12/05/2007  created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property ModuleConfiguration() As ModuleInfo
            Get
                Return _ModuleConfiguration
            End Get
            Set(ByVal value As ModuleInfo)
                _ModuleConfiguration = value
                ProcessModule()
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Parent Skin for this container
        ''' </summary>
        ''' <returns>A String</returns>
        ''' <history>
        ''' 	[cnurse]	12/05/2007  documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property ParentSkin() As DotNetNuke.UI.Skins.Skin
            Get
                'This finds a reference to the containing skin
                Return DotNetNuke.UI.Skins.Skin.GetParentSkin(Me)
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Path for this container
        ''' </summary>
        ''' <returns>A String</returns>
        ''' <history>
        ''' 	[cnurse]	12/05/2007  documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property SkinPath() As String
            Get
                Return Me.TemplateSourceDirectory & "/"
            End Get
        End Property

#End Region

#Region "Private Helper Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ProcessChildControls parses all the controls in the container, and if the
        ''' control is an action (IActionControl) it attaches the ModuleControl (IModuleControl)
        ''' and an EventHandler to respond to the Actions Action event.  If the control is a
        ''' Skin Object (ISkinControl) it attaches the ModuleControl.
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	12/05/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ProcessChildControls(ByVal control As Control)
            Dim objActions As IActionControl
            Dim objSkinControl As ISkinControl

            For Each objChildControl As Control In control.Controls
                ' check if control is an action control
                objActions = TryCast(objChildControl, IActionControl)
                If objActions IsNot Nothing Then
                    objActions.ModuleControl = _ModuleHost.ModuleControl
                    AddHandler objActions.Action, AddressOf ModuleAction_Click
                End If

                ' check if control is a skin control
                objSkinControl = TryCast(objChildControl, ISkinControl)
                If objSkinControl IsNot Nothing Then
                    objSkinControl.ModuleControl = _ModuleHost.ModuleControl
                End If

                If objChildControl.HasControls Then
                    ' recursive call for child controls
                    ProcessChildControls(objChildControl)
                End If
            Next
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ProcessContentPane processes the ContentPane, setting its style and other 
        ''' attributes.
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	12/05/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ProcessContentPane()
            If ModuleConfiguration.Alignment <> "" Then
                If Not ContentPane.Attributes.Item("class") Is Nothing Then
                    ContentPane.Attributes.Item("class") = ContentPane.Attributes.Item("class") + " DNNAlign" + ModuleConfiguration.Alignment.ToLower()
                Else
                    ContentPane.Attributes.Item("class") = "DNNAlign" + ModuleConfiguration.Alignment.ToLower()
                End If
            End If
            If ModuleConfiguration.Color <> "" Then
                ContentPane.Style("background-color") = ModuleConfiguration.Color
            End If
            If ModuleConfiguration.Border <> "" Then
                ContentPane.Style("border-top") = ModuleConfiguration.Border & "px #000000 solid"
                ContentPane.Style("border-bottom") = ModuleConfiguration.Border & "px #000000 solid"
                ContentPane.Style("border-right") = ModuleConfiguration.Border & "px #000000 solid"
                ContentPane.Style("border-left") = ModuleConfiguration.Border & "px #000000 solid"
            End If

            ' display visual indicator if module is only visible to administrators
            'If IsAdminControl() = False Then
            '    If (ModuleConfiguration.StartDate >= Now Or ModuleConfiguration.EndDate <= Now) Or (ModuleConfiguration.AuthorizedViewRoles.ToLower = ";" & PortalSettings.AdministratorRoleName.ToLower & ";") Then
            '        ContentPane.Style("border-top") = "2px #FF0000 solid"
            '        ContentPane.Style("border-bottom") = "2px #FF0000 solid"
            '        ContentPane.Style("border-right") = "2px #FF0000 solid"
            '        ContentPane.Style("border-left") = "2px #FF0000 solid"
            '        ContentPane.Controls.Add(New LiteralControl("<span class=""NormalRed""><center>" & Localization.GetString("ModuleVisibleAdministrator.Text") & "</center></span>"))
            '    End If
            'End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ProcessFooter adds an optional footer (and an End_Module comment)..
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	12/05/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ProcessFooter()
            ' inject the footer
            If ModuleConfiguration.Footer <> "" Then
                Dim objLabel As New Label
                objLabel.Text = ModuleConfiguration.Footer
                objLabel.CssClass = "Normal"
                ContentPane.Controls.Add(objLabel)
            End If

            ' inject an end comment around the module content
            If Not IsAdminControl() Then
                ContentPane.Controls.Add(New LiteralControl("<!-- End_Module_" & ModuleConfiguration.ModuleID.ToString & " -->"))
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ProcessHeader adds an optional header (and a Start_Module_ comment)..
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	12/05/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ProcessHeader()
            If Not IsAdminControl() Then
                ' inject a start comment around the module content
                ContentPane.Controls.Add(New LiteralControl("<!-- Start_Module_" & ModuleConfiguration.ModuleID.ToString & " -->"))
            End If

            ' inject the header
            If ModuleConfiguration.Header <> "" Then
                Dim objLabel As New Label
                objLabel.Text = ModuleConfiguration.Header
                objLabel.CssClass = "Normal"
                ContentPane.Controls.Add(objLabel)
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ProcessModule processes the module which is attached to this container
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	12/05/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ProcessModule()

            If ContentPane IsNot Nothing Then
                'Process Content Pane Attributes
                ProcessContentPane()

                'Process Module Header
                ProcessHeader()

                'Try to load the module control
                _ModuleHost = New ModuleHost(ModuleConfiguration)
                ContentPane.Controls.Add(_ModuleHost)

                'Process Module Footer
                ProcessFooter()

                'Process the Action Controls
                If _ModuleHost IsNot Nothing AndAlso _ModuleHost.ModuleControl IsNot Nothing Then
                    ProcessChildControls(Me)
                End If

                'Add Module Stylesheets
                ProcessStylesheets(_ModuleHost IsNot Nothing)
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ProcessStylesheets processes the Module and Container stylesheets and adds
        ''' them to the Page.
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	12/05/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ProcessStylesheets(ByVal includeModuleCss As Boolean)
            Dim containerPath As String = ModuleConfiguration.ContainerPath
            Dim containerSrc As String = ModuleConfiguration.ContainerSrc

            'Get a reference to the Page
            Dim DefaultPage As CDefault = DirectCast(Page, CDefault)

            Dim ID As String
            Dim objCSSCache As Hashtable = Nothing
            If Host.PerformanceSetting <> Common.Globals.PerformanceSettings.NoCaching Then
                objCSSCache = CType(DataCache.GetCache("CSS"), Hashtable)
            End If
            If objCSSCache Is Nothing Then
                objCSSCache = New Hashtable
            End If

            ' container package style sheet
            ID = CreateValidID(containerPath)
            If objCSSCache.ContainsKey(ID) = False Then
                If File.Exists(Server.MapPath(containerPath) & "container.css") Then
                    objCSSCache(ID) = containerPath & "container.css"
                Else
                    objCSSCache(ID) = ""
                End If
            End If
            If objCSSCache(ID).ToString <> "" Then
                DefaultPage.AddStyleSheet(ID, objCSSCache(ID).ToString)
            End If

            ' container file style sheet
            ID = CreateValidID(containerSrc.Replace(".ascx", ".css"))
            If objCSSCache.ContainsKey(ID) = False Then
                If File.Exists(Server.MapPath(Replace(containerSrc, ".ascx", ".css"))) Then
                    objCSSCache(ID) = Replace(containerSrc, ".ascx", ".css")
                Else
                    objCSSCache(ID) = ""
                End If
            End If
            If objCSSCache(ID).ToString <> "" Then
                DefaultPage.AddStyleSheet(ID, objCSSCache(ID).ToString)
            End If

            ' process the base class module properties 
            If includeModuleCss Then
                Dim controlSrc As String = ModuleConfiguration.ModuleControl.ControlSrc
                Dim folderName As String = ModuleConfiguration.DesktopModule.FolderName

                ' module stylesheet
                ID = CreateValidID(Common.Globals.ApplicationPath & "/DesktopModules/" & folderName)
                If objCSSCache.ContainsKey(ID) = False Then
                    ' default to nothing
                    objCSSCache(ID) = ""

                    ' 1.try to load module.css from module folder
                    If File.Exists(Server.MapPath(Common.Globals.ApplicationPath & "/DesktopModules/" & folderName & "/module.css")) Then
                        objCSSCache(ID) = Common.Globals.ApplicationPath & "/DesktopModules/" & folderName & "/module.css"
                    Else
                        ' 2.otherwise try to load from Path to control
                        If controlSrc.ToLower.EndsWith(".ascx") Then
                            If File.Exists(Server.MapPath(Common.Globals.ApplicationPath & "/" & controlSrc.Substring(0, controlSrc.LastIndexOf("/") + 1)) & "module.css") Then
                                objCSSCache(ID) = Common.Globals.ApplicationPath & "/" & controlSrc.Substring(0, controlSrc.LastIndexOf("/") + 1) & "module.css"
                            End If
                        End If
                    End If
                End If

                If objCSSCache.ContainsKey(ID) AndAlso Not String.IsNullOrEmpty(objCSSCache(ID).ToString()) Then
                    'Add it to beginning of style list
                    DefaultPage.AddStyleSheet(ID, objCSSCache(ID).ToString(), True)
                End If
            End If

            If Host.PerformanceSetting <> Common.Globals.PerformanceSettings.NoCaching Then
                DataCache.SetCache("CSS", objCSSCache)
            End If
        End Sub

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ModuleAction_Click runs when a ModuleAction is clicked.
        ''' </summary>
        ''' <remarks>The Module Action must be configured to fire an event (it may be configured 
        ''' to redirect to a new url).  The event handler finds the Parent Skin and invokes each
        ''' registered ModuleActionEventListener delegate.
        ''' 
        ''' Note: with the refactoring of this to the Container, this could be handled at the container level.
        ''' However, for legacy purposes this is left this way, as many moodules would have registered their
        ''' listeners on the Skin directly, rather than through the helper method in PortalModuleBase.</remarks>
        ''' <history>
        ''' 	[cnurse]	07/04/2005	Documented
        '''     [cnurse]    12/05/2007  Moved from Skin.vb
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ModuleAction_Click(ByVal sender As Object, ByVal e As ActionEventArgs)
            'Search through the listeners
            Dim Listener As ModuleActionEventListener
            For Each Listener In ParentSkin.ActionEventListeners

                'If the associated module has registered a listener
                If e.ModuleConfiguration.ModuleID = Listener.ModuleID Then

                    'Invoke the listener to handle the ModuleAction_Click event
                    Listener.ActionEvent.Invoke(sender, e)
                End If
            Next
        End Sub

#End Region

#Region "Obsolete"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetPortalModuleBase gets the parent PortalModuleBase Control
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	07/04/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Obsolete("Deprecated in 5.0. Shouldn't need to be used any more.  SkinObjects (ISkinControl implementations) have a property ModuleControl.")> _
        Public Shared Function GetPortalModuleBase(ByVal objControl As UserControl) As PortalModuleBase
            Dim objModuleControl As PortalModuleBase = Nothing
            Dim ctlPanel As Panel

            If TypeOf objControl Is UI.Skins.SkinObjectBase Then
                ctlPanel = CType(objControl.Parent.FindControl("ModuleContent"), Panel)
            Else
                ctlPanel = CType(objControl.FindControl("ModuleContent"), Panel)
            End If

            If Not ctlPanel Is Nothing Then
                Try
                    objModuleControl = CType(ctlPanel.Controls(1), PortalModuleBase)
                Catch
                    ' check if it is nested within an UpdatePanel 
                    Try
                        objModuleControl = CType(ctlPanel.Controls(0).Controls(0).Controls(1), PortalModuleBase)
                    Catch
                    End Try
                End Try
            End If

            If objModuleControl Is Nothing Then
                objModuleControl = New PortalModuleBase
                objModuleControl.ModuleConfiguration = New ModuleInfo
            End If

            Return objModuleControl
        End Function

#End Region

    End Class

End Namespace