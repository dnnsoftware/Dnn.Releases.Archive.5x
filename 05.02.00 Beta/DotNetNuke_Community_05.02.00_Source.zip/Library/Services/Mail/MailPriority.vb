Imports Localize = DotNetNuke.Services.Localization.Localization
Imports DotNetNuke.Entities.Host
Imports System.Net.Mail

Namespace DotNetNuke.Services.Mail

    Public Enum MailPriority
        Normal
        Low
        High
    End Enum

End Namespace
