//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System.Collections.Generic;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Data;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Users;
namespace DotNetNuke.Entities.Modules
{
	public class SkinControlController
	{
		private static DataProvider dataProvider = DataProvider.Instance();
		public static void DeleteSkinControl(SkinControlInfo skinControl)
		{
			dataProvider.DeleteSkinControl(skinControl.SkinControlID);
			Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
			objEventLog.AddLog(skinControl, PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, "", DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.SKINCONTROL_DELETED);
		}
		public static SkinControlInfo GetSkinControl(int skinControlID)
		{
			return CBO.FillObject<SkinControlInfo>(dataProvider.GetSkinControl(skinControlID));
		}
		public static SkinControlInfo GetSkinControlByPackageID(int packageID)
		{
			return CBO.FillObject<SkinControlInfo>(dataProvider.GetSkinControlByPackageID(packageID));
		}
		public static SkinControlInfo GetSkinControlByKey(string key)
		{
			return CBO.FillObject<SkinControlInfo>(dataProvider.GetSkinControlByKey(key));
		}
		public static Dictionary<string, SkinControlInfo> GetSkinControls()
		{
			return CBO.FillDictionary<string, SkinControlInfo>("ControlKey", dataProvider.GetSkinControls(), new Dictionary<string, SkinControlInfo>());
		}
		public static int SaveSkinControl(SkinControlInfo skinControl)
		{
			int skinControlID = skinControl.SkinControlID;
			Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
			if (skinControlID == Null.NullInteger) {
				skinControlID = dataProvider.AddSkinControl(skinControl.PackageID, skinControl.ControlKey, skinControl.ControlSrc, skinControl.SupportsPartialRendering, UserController.GetCurrentUserInfo().UserID);
				objEventLog.AddLog(skinControl, PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, "", DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.SKINCONTROL_CREATED);
			} else {
				dataProvider.UpdateSkinControl(skinControl.SkinControlID, skinControl.PackageID, skinControl.ControlKey, skinControl.ControlSrc, skinControl.SupportsPartialRendering, UserController.GetCurrentUserInfo().UserID);
				objEventLog.AddLog(skinControl, PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, "", DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.SKINCONTROL_UPDATED);
			}
			return skinControlID;
		}
	}
}
