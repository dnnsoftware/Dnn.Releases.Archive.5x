//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.ComponentModel;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Profile;
using DotNetNuke.Services.Tokens;
using DotNetNuke.UI.WebControls;
namespace DotNetNuke.Entities.Users
{
	[Serializable()]
	public class UserInfo : BaseEntityInfo, IPropertyAccess
	{
		private int _UserID;
		private string _Username;
		private string _DisplayName;
		private string _FullName;
		private string _Email;
		private int _PortalID;
		private bool _IsSuperUser;
		private int _AffiliateID;
		private UserMembership _Membership;
		private UserProfile _Profile;
		private string[] _Roles;
		private bool _RolesHydrated = Null.NullBoolean;
		private string _LastIPAddress;
		private bool _RefreshRoles = Null.NullBoolean;
		private bool _IsDeleted = Null.NullBoolean;
		public UserInfo()
		{
			_UserID = Null.NullInteger;
			_PortalID = Null.NullInteger;
			_IsSuperUser = Null.NullBoolean;
			_AffiliateID = Null.NullInteger;
			_Roles = new string[] {
				
			};
		}
		[Browsable(false)]
		public int AffiliateID
		{
			get { return _AffiliateID; }
			set { _AffiliateID = value; }
		}
		[SortOrder(3), Required(true), MaxLength(128)]
		public string DisplayName
		{
			get { return _DisplayName; }
			set { _DisplayName = value; }
		}
		[SortOrder(4), MaxLength(256), Required(true), RegularExpressionValidator(DotNetNuke.Common.Globals.glbEmailRegEx)]
		public string Email
		{
			get { return _Email; }
			set { _Email = value; }
		}
		[SortOrder(1), MaxLength(50), Required(true)]
		public string FirstName
		{
			get { return Profile.FirstName; }
			set { Profile.FirstName = value; }
		}
		[Browsable(false)]
		public bool IsDeleted
		{
			get { return _IsDeleted; }
			set { _IsDeleted = value; }
		}
		[Browsable(false)]
		public bool IsSuperUser
		{
			get { return _IsSuperUser; }
			set { _IsSuperUser = value; }
		}
		[Browsable(false)]
		public string LastIPAddress
		{
			get { return _LastIPAddress; }
			set { _LastIPAddress = value; }
		}
		[SortOrder(2), MaxLength(50), Required(true)]
		public string LastName
		{
			get { return Profile.LastName; }
			set { Profile.LastName = value; }
		}
		[Browsable(false)]
		public Entities.Users.UserMembership Membership
		{
			get
			{
				if (_Membership == null)
				{
					_Membership = new UserMembership(this);
					if ((this.Username != null) && (!String.IsNullOrEmpty(this.Username)))
					{
						UserController.GetUserMembership(this);
					}
				}
				return _Membership;
			}
			set { _Membership = value; }
		}
		[Browsable(false)]
		public int PortalID
		{
			get { return _PortalID; }
			set { _PortalID = value; }
		}
		[Browsable(false)]
		public UserProfile Profile
		{
			get
			{
				if (_Profile == null)
				{
					_Profile = new UserProfile();
					ProfileController.GetUserProfile(this);
				}
				return _Profile;
			}
			set { _Profile = value; }
		}
		[Browsable(false)]
		public bool RefreshRoles
		{
			get { return _RefreshRoles; }
			set { _RefreshRoles = value; }
		}
		[Browsable(false)]
		public string[] Roles
		{
			get
			{
				if (!_RolesHydrated)
				{
					if (_UserID > Null.NullInteger)
					{
						DotNetNuke.Security.Roles.RoleController controller = new DotNetNuke.Security.Roles.RoleController();
						_Roles = controller.GetRolesByUser(_UserID, PortalID);
						_RolesHydrated = true;
					}
				}
				return _Roles;
			}
			set
			{
				_Roles = value;
				_RolesHydrated = true;
			}
		}
		[Browsable(false)]
		public int UserID
		{
			get { return _UserID; }
			set { _UserID = value; }
		}
		[SortOrder(0), MaxLength(100), IsReadOnly(true), Required(true)]
		public string Username
		{
			get { return _Username; }
			set { _Username = value; }
		}
		public bool IsInRole(string role)
		{
			if (IsSuperUser || role == DotNetNuke.Common.Globals.glbRoleAllUsersName)
			{
				return true;
			}
			else
			{
				if ("[" + UserID + "]" == role)
				{
					return true;
				}
				if (Roles != null)
				{
					foreach (string strRole in Roles)
					{
						if (strRole == role)
						{
							return true;
						}
					}
				}
			}
			return false;
		}
		public void UpdateDisplayName(string format)
		{
			format = format.Replace("[USERID]", this.UserID.ToString());
			format = format.Replace("[FIRSTNAME]", this.FirstName);
			format = format.Replace("[LASTNAME]", this.LastName);
			format = format.Replace("[USERNAME]", this.Username);
			DisplayName = format;
		}
		[Browsable(false), Obsolete("Deprecated in DNN 5.1. This property has been deprecated in favour of Display Name")]
		public string FullName
		{
			get
			{
				if (String.IsNullOrEmpty(_FullName))
				{
					_FullName = FirstName + " " + LastName;
				}
				return _FullName;
			}
			set { _FullName = value; }
		}
		string strAdministratorRoleName;
		private bool isAdminUser(ref UserInfo AccessingUser)
		{
			if (AccessingUser == null || AccessingUser.UserID == -1)
			{
				return false;
			}
			else if (String.IsNullOrEmpty(strAdministratorRoleName))
			{
				DotNetNuke.Entities.Portals.PortalInfo ps = new DotNetNuke.Entities.Portals.PortalController().GetPortal(AccessingUser.PortalID);
				strAdministratorRoleName = ps.AdministratorRoleName;
			}
			return AccessingUser.IsInRole(strAdministratorRoleName) || AccessingUser.IsSuperUser;
		}
		public string GetProperty(string strPropertyName, string strFormat, System.Globalization.CultureInfo formatProvider, UserInfo AccessingUser, Services.Tokens.Scope CurrentScope, ref bool PropertyNotFound)
		{
			DotNetNuke.Services.Tokens.Scope internScope;
			if (this.UserID == -1 && CurrentScope > Scope.Configuration)
			{
				internScope = Scope.Configuration;
			}
			else if (this.UserID != AccessingUser.UserID && !isAdminUser(ref AccessingUser) && CurrentScope > Scope.DefaultSettings)
			{
				internScope = Scope.DefaultSettings;
			}
			else
			{
				internScope = CurrentScope;
			}
			string OutputFormat = string.Empty;
			if (strFormat == string.Empty)
				OutputFormat = "g";
			else
				OutputFormat = strFormat;
			switch (strPropertyName.ToLower())
			{
				case "verificationcode":
					if (internScope < Scope.SystemMessages) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return this.PortalID.ToString() + "-" + this.UserID.ToString();
				case "affiliateid":
					if (internScope < Scope.SystemMessages) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return (this.AffiliateID.ToString(OutputFormat, formatProvider));
				case "displayname":
					if (internScope < Scope.Configuration) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return PropertyAccess.FormatString(this.DisplayName, strFormat);
				case "email":
					if (internScope < Scope.DefaultSettings) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return (PropertyAccess.FormatString(this.Email, strFormat));
				case "firstname":
					if (internScope < Scope.DefaultSettings) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return (PropertyAccess.FormatString(this.FirstName, strFormat));
				case "issuperuser":
					if (internScope < Scope.Debug) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return (this.IsSuperUser.ToString(formatProvider));
				case "lastname":
					if (internScope < Scope.DefaultSettings) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return (PropertyAccess.FormatString(this.LastName, strFormat));
				case "portalid":
					if (internScope < Scope.Configuration) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return (this.PortalID.ToString(OutputFormat, formatProvider));
				case "userid":
					if (internScope < Scope.DefaultSettings) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return (this.UserID.ToString(OutputFormat, formatProvider));
				case "username":
					if (internScope < Scope.DefaultSettings) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return (PropertyAccess.FormatString(this.Username, strFormat));
				case "fullname":
					if (internScope < Scope.Configuration) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return (PropertyAccess.FormatString(this.DisplayName, strFormat));
				case "roles":
					if (CurrentScope < Scope.SystemMessages) { PropertyNotFound = true; return PropertyAccess.ContentLocked; }
					return (PropertyAccess.FormatString(string.Join(", ", this.Roles), strFormat));
			}
			PropertyNotFound = true;
			return string.Empty;
		}
		[Browsable(false)]
		public CacheLevel Cacheability
		{
			get { return CacheLevel.notCacheable; }
		}
	}
}
