//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System.IO;
using System.Text;
using System.Web.UI;
using DotNetNuke.Entities.Portals;
namespace DotNetNuke.Framework
{
	public class DiskPageStatePersister : PageStatePersister
	{
		public DiskPageStatePersister(Page page) : base(page)
		{
		}
		public string CacheDirectory {
			get { return PortalController.GetCurrentPortalSettings().HomeDirectoryMapPath + "Cache"; }
		}
		public string StateFileName {
			get {
				StringBuilder key = new StringBuilder();
				{
					key.Append("VIEWSTATE_");
					key.Append(Page.Session.SessionID);
					key.Append("_");
					key.Append(Page.Request.RawUrl);
				}
				return CacheDirectory + "\\" + DotNetNuke.Common.Globals.CleanFileName(key.ToString()) + ".txt";
			}
		}
		public override void Load()
		{
			StreamReader reader = null;
			try {
				reader = new StreamReader(StateFileName);
				string serializedStatePair = reader.ReadToEnd();
				IStateFormatter formatter = this.StateFormatter;
				Pair statePair = (Pair)formatter.Deserialize(serializedStatePair);
				ViewState = statePair.First;
				ControlState = statePair.Second;
			} finally {
				if (reader != null) {
					reader.Close();
				}
			}
		}
		public override void Save()
		{
			if (ViewState == null && ControlState == null) {
				return;
			}
			if (Page.Session != null) {
				if (!Directory.Exists(CacheDirectory)) {
					Directory.CreateDirectory(CacheDirectory);
				}
				StreamWriter writer = new StreamWriter(StateFileName, false);
				IStateFormatter formatter = this.StateFormatter;
				Pair statePair = new Pair(ViewState, ControlState);
				string serializedState = formatter.Serialize(statePair);
				writer.Write(serializedState);
				writer.Close();
			}
		}
	}
}
