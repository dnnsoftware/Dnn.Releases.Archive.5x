//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Net;
using System.Web;
using System.Xml.Serialization;
using DotNetNuke.Common;
namespace DotNetNuke.Modules.Dashboard.Components.Server
{
	[XmlRoot("serverInfo")]
	public class ServerInfo : IXmlSerializable
	{
		public string Framework {
			get { return System.Environment.Version.ToString(); }
		}
		public string HostName {
			get { return Dns.GetHostName(); }
		}
		public string Identity {
			get { return System.Security.Principal.WindowsIdentity.GetCurrent().Name; }
		}
		public string IISVersion {
			get { return HttpContext.Current.Request.ServerVariables["SERVER_SOFTWARE"]; }
		}
		public string OSVersion {
			get { return System.Environment.OSVersion.ToString(); }
		}
		public string PhysicalPath {
			get { return DotNetNuke.Common.Globals.ApplicationMapPath; }
		}
		public string Url {
			get { return Globals.GetDomainName(HttpContext.Current.Request); }
		}
		public string RelativePath {
			get {
				string path;
				if (string.IsNullOrEmpty(DotNetNuke.Common.Globals.ApplicationPath)) {
					path = "/";
				} else {
					path = DotNetNuke.Common.Globals.ApplicationPath;
				}
				return path;
			}
		}
		public string ServerTime {
			get { return System.DateTime.Now.ToString(); }
		}
		public System.Xml.Schema.XmlSchema GetSchema()
		{
			throw new NotImplementedException();
		}
		public void ReadXml(System.Xml.XmlReader reader)
		{
			throw new NotImplementedException();
		}
		public void WriteXml(System.Xml.XmlWriter writer)
		{
			writer.WriteElementString("osVersion", OSVersion);
			writer.WriteElementString("iisVersion", IISVersion);
			writer.WriteElementString("framework", Framework);
			writer.WriteElementString("identity", Identity);
			writer.WriteElementString("hostName", HostName);
			writer.WriteElementString("physicalPath", PhysicalPath);
			writer.WriteElementString("url", Url);
			writer.WriteElementString("relativePath", RelativePath);
		}
	}
}
