//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System.Collections;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Tabs;
using DotNetNuke.Entities.Users;
using DotNetNuke.Security.Roles;
namespace DotNetNuke.Modules.Dashboard.Components.Portals
{
	public class PortalInfo
	{
		private int _Pages = Null.NullInteger;
		private int _Roles = Null.NullInteger;
		private int _Users = Null.NullInteger;
		private System.Guid _GUID;
		public System.Guid GUID {
			get { return _GUID; }
			set { _GUID = value; }
		}
		public int Pages {
			get {
				if (_Pages < 0) {
					TabController controller = new TabController();
					_Pages = controller.GetTabCount(PortalID);
				}
				return _Pages;
			}
		}
		private int _PortalID;
		public int PortalID {
			get { return _PortalID; }
			set { _PortalID = value; }
		}
		private string _PortalName;
		public string PortalName {
			get { return _PortalName; }
			set { _PortalName = value; }
		}
		public int Roles {
			get {
				if (_Roles < 0) {
					RoleController controller = new RoleController();
					ArrayList portalRoles = controller.GetPortalRoles(PortalID);
					_Roles = portalRoles.Count;
				}
				return _Roles;
			}
		}
		public int Users {
			get {
				if (_Users < 0) {
					_Users = UserController.GetUserCountByPortal(PortalID);
				}
				return _Users;
			}
		}
		public void WriteXml(System.Xml.XmlWriter writer)
		{
			writer.WriteStartElement("portal");
			writer.WriteElementString("portalName", PortalName);
			writer.WriteElementString("GUID", GUID.ToString());
			writer.WriteElementString("pages", Pages.ToString());
			writer.WriteElementString("users", Users.ToString());
			writer.WriteElementString("roles", Roles.ToString());
			writer.WriteEndElement();
		}
	}
}
