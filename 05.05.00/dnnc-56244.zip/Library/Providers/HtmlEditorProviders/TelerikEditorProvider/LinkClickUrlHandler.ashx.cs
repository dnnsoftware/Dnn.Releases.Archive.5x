﻿using DotNetNuke.Framework;
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Services.FileSystem;
using DotNetNuke.Entities.Tabs;
using DotNetNuke.Services.Localization;

namespace DotNetNuke.HtmlEditor.TelerikEditorProvider
{
	/// <summary>
	/// Returns a LinkClickUrl if provided a tabid and LinkUrl.
	/// </summary>
	/// <remarks>This uses the new BaseHttpHandler which encapsulates most common scenarios including the retrieval of AJAX request data.
	/// See http://blog.theaccidentalgeek.com/post/2008/10/28/An-Updated-Abstract-Boilerplate-HttpHandler.aspx for more information on 
	/// the BaseHttpHandler.
	/// </remarks>
	public class LinkClickUrlHandler : BaseHttpHandler
	{

		public override void HandleRequest()
		{
			string output = null;

			// This uses the new JSON Extensions in DotNetNuke.Common.Utilities.JsonExtensionsWeb
			DialogParams dialogParams = Content.FromJson<DialogParams>();
            string link = dialogParams.LinkUrl;
            dialogParams.LinkClickUrl = link;
			PortalAliasController pac = new PortalAliasController();
            ArrayList aliasList = pac.GetPortalAliasArrayByPortalID(dialogParams.PortalId);
            if ((dialogParams != null))
			{
                if (dialogParams.Track)
				{
                    if (!dialogParams.LinkUrl.ToLower().Contains("linkclick.aspx"))
					{
                        if (dialogParams.LinkUrl.Contains(dialogParams.HomeDirectory))
						{
							DotNetNuke.Services.FileSystem.FileController fc = new DotNetNuke.Services.FileSystem.FileController();
                            int linkedFileId = fc.ConvertFilePathToFileId(dialogParams.LinkUrl.Replace(dialogParams.HomeDirectory, ""), dialogParams.PortalId);
							link = string.Format("fileID={0}", linkedFileId);
						}
						else
						{
							foreach (PortalAliasInfo portalAlias in aliasList)
							{
                                dialogParams.LinkUrl = dialogParams.LinkUrl.Replace(portalAlias.HTTPAlias, "");
							}
                            string tabPath = dialogParams.LinkUrl.Replace("http://", "").Replace("/", "//").Replace(".aspx", "");
                            string cultureCode = Localization.SystemLocale;

                            //Try HumanFriendlyUrl TabPath
                            int tabId = TabController.GetTabByTabPath(dialogParams.PortalId, tabPath, cultureCode);
                            if (tabId == Null.NullInteger)
                            {
                                //Try getting the tabId from the querystring
                                string[] arrParams = dialogParams.LinkUrl.Split('/');
                                for (int i = 0; i < arrParams.Length; i++)
                                {
                                    if (arrParams[i].ToLowerInvariant() == "tabid")
                                    {
                                        tabId = Convert.ToInt32(arrParams[i + 1]);
                                        break;
                                    }
                                }
                                if (tabId == Null.NullInteger)
                                {
                                    link = dialogParams.LinkUrl;
                                }
                            }
						}
                        dialogParams.LinkClickUrl = DotNetNuke.Common.Globals.LinkClick(link, dialogParams.TabId, dialogParams.ModuleId, true, false, dialogParams.PortalId, dialogParams.EnableUrlLanguage, dialogParams.PortalGuid);
					}
					UrlController objUrls = new UrlController();
                    objUrls.UpdateUrl(dialogParams.PortalId, link, DotNetNuke.Common.Globals.GetURLType(link).ToString(), dialogParams.TrackUser, true, dialogParams.ModuleId, false);
				}
				else
				{
                    if (dialogParams.LinkUrl.Contains("fileticket"))
					{
                        string[] queryString = dialogParams.LinkUrl.Split('=');
						string encryptedFileId = queryString[1].Split('&')[0];
                        int fileID = Convert.ToInt32(UrlUtils.DecryptParameter(encryptedFileId, dialogParams.PortalGuid));
						FileController fc = new FileController();
                        FileInfo savedFile = fc.GetFileById(fileID, dialogParams.PortalId);
					    string s = dialogParams.LinkClickUrl = string.Format("{0}{1}/{2}", dialogParams.HomeDirectory, savedFile.Folder, savedFile.FileName).Replace("//", "/");
					}
					else
					{
						try
						{
                            link = dialogParams.LinkUrl.Split('?')[1].Split('&')[0].Split('=')[1];
							int tabId = 0;
							if (int.TryParse(link, out tabId))
							{
								TabController tc = new TabController();
                                dialogParams.LinkClickUrl = tc.GetTab(tabId, dialogParams.PortalId, true).FullUrl;
							}
							else
							{
                                dialogParams.LinkClickUrl = HttpContext.Current.Server.UrlDecode(link);
							}
						}
						catch (Exception ex)
						{
                            dialogParams.LinkClickUrl = dialogParams.LinkUrl;
						}
					}
				}
                output = dialogParams.ToJson();
			}
			else
			{
				output = (new DialogParams()).ToJson();
			}

			Response.Write(output);
		}


		public override string ContentMimeType
		{
			//Normally we could use the ContentEncoding property, but because of an IE bug we have to ensure
			//that the UTF-8 is capitalized which requires inclusion in the mimetype property as shown here
			get { return "application/json; charset=UTF-8"; }
		}

		public override bool ValidateParameters()
		{
			//TODO: This should be updated to validate the Content paramater and return false if the content can't be converted to a DialogParams
			return true;
		}

		public override bool HasPermission
		{
			//TODO: This should be updated to ensure the user has appropriate permissions for the passed in TabId.
			get { return Context.User.Identity.IsAuthenticated; }
		}

	}
}
