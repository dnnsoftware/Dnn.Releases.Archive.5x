'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2008
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Collections.Generic
Imports System.Data
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Host

Namespace DotNetNuke.Security.Permissions

    ''' -----------------------------------------------------------------------------
    ''' Project	 : DotNetNuke
    ''' Namespace: DotNetNuke.Security.Permissions
    ''' Class	 : ModulePermissionController
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' ModulePermissionController provides the Business Layer for Module Permissions
    ''' </summary>
    ''' <history>
    ''' 	[cnurse]	01/14/2008   Documented
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class ModulePermissionController

#Region "Private Members"

        Private Shared provider As DataProvider = DataProvider.Instance()

#End Region

#Region "Private Shred Methdos"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FillModulePermissionDictionary fills a Dictionary of ModulePermissions from a
        ''' dataReader
        ''' </summary>
        ''' <param name="dr">The IDataReader</param>
        ''' <history>
        ''' 	[cnurse]	01/14/2008   Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function FillModulePermissionDictionary(ByVal dr As IDataReader) As Dictionary(Of Integer, ModulePermissionCollection)
            Dim dic As New Dictionary(Of Integer, ModulePermissionCollection)
            Try
                Dim obj As ModulePermissionInfo
                While dr.Read
                    ' fill business object
                    obj = CBO.FillObject(Of ModulePermissionInfo)(dr, False)

                    ' add Module Permission to dictionary
                    If dic.ContainsKey(obj.ModuleID) Then
                        'Add ModulePermission to ModulePermission Collection already in dictionary for TabId
                        dic(obj.ModuleID).Add(obj)
                    Else
                        'Create new ModulePermission Collection for ModuleId
                        Dim collection As New ModulePermissionCollection

                        'Add Permission to Collection
                        collection.Add(obj)

                        'Add Collection to Dictionary
                        dic.Add(obj.ModuleID, collection)
                    End If
                End While
            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try
            Return dic
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetModulePermissions gets a Dictionary of ModulePermissionCollections by 
        ''' Module.
        ''' </summary>
        ''' <param name="tabID">The ID of the tab</param>
        ''' <history>
        ''' 	[cnurse]	01/14/2008   Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetModulePermissions(ByVal tabID As Integer) As Dictionary(Of Integer, ModulePermissionCollection)
            Dim cacheKey As String = String.Format(DataCache.ModulePermissionCacheKey, tabID.ToString())
            Return CBO.GetCachedObject(Of Dictionary(Of Integer, ModulePermissionCollection))(New CacheItemArgs(cacheKey, DataCache.ModulePermissionCacheTimeOut, DataCache.ModulePermissionCachePriority, tabID), _
                                                                                                        AddressOf GetModulePermissionsCallBack)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetModulePermissionsCallBack gets a Dictionary of ModulePermissionCollections by 
        ''' Module from the the Database.
        ''' </summary>
        ''' <param name="cacheItemArgs">The CacheItemArgs object that contains the parameters
        ''' needed for the database call</param>
        ''' <history>
        ''' 	[cnurse]	01/14/2008   Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetModulePermissionsCallBack(ByVal cacheItemArgs As CacheItemArgs) As Object
            Dim tabID As Integer = DirectCast(cacheItemArgs.ParamList(0), Integer)
            Return FillModulePermissionDictionary(provider.GetModulePermissionsByTabID(tabID))
        End Function

#End Region

#Region "Public Shared Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetModulePermissions gets a ModulePermissionCollection
        ''' </summary>
        ''' <param name="moduleID">The ID of the module</param>
        ''' <param name="tabID">The ID of the tab</param>
        ''' <history>
        ''' 	[cnurse]	01/14/2008   Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetModulePermissions(ByVal moduleID As Integer, ByVal tabID As Integer) As ModulePermissionCollection
            Dim bFound As Boolean = False

            'Get the Tab ModulePermission Dictionary
            Dim dicModulePermissions As Dictionary(Of Integer, ModulePermissionCollection) = GetModulePermissions(TabId)

            'Get the Collection from the Dictionary
            Dim modulePermissions As ModulePermissionCollection = Nothing
            bFound = dicModulePermissions.TryGetValue(ModuleId, modulePermissions)

            If Not bFound Then
                'try the database
                modulePermissions = New ModulePermissionCollection(CBO.FillCollection(provider.GetModulePermissionsByModuleID(moduleID, -1), GetType(ModulePermissionInfo)), moduleID)
            End If

            Return modulePermissions
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' HasModulePermission checks whether the current user has a specific Module Permission
        ''' </summary>
        ''' <param name="objModulePermissions">The Permissions for the Module</param>
        ''' <param name="permissionKey">The Permission to check</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function HasModulePermission(ByVal objModulePermissions As ModulePermissionCollection, ByVal permissionKey As String) As Boolean
            Return PortalSecurity.IsInRoles(objModulePermissions.ToString(permissionKey))
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' HasModulePermission checks whether the current user has a specific Module Permission
        ''' </summary>
        ''' <param name="moduleID">The ID of the Module</param>
        ''' <param name="tabID">The ID of the Tab</param>
        ''' <param name="permissionKey">The Permission to check</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function HasModulePermission(ByVal moduleID As Integer, ByVal tabID As Integer, ByVal PermissionKey As String) As Boolean
            Dim objModulePermissionController As New ModulePermissionController
            Dim objModulePermissions As ModulePermissionCollection = objModulePermissionController.GetModulePermissionsCollectionByModuleID(moduleID, TabId)
            Return HasModulePermission(objModulePermissions, PermissionKey)
        End Function

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ClearPermissionCache clears the Module Permission Cache
        ''' </summary>
        ''' <param name="moduleID">The ID of the Module</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ClearPermissionCache(ByVal moduleId As Integer)
            Dim objModules As New ModuleController
            Dim objModule As ModuleInfo = objModules.GetModule(moduleId, Null.NullInteger, False)
            DataCache.ClearModulePermissionsCache(objModule.TabID)
        End Sub

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModulePermission adds a Module Permission to the Database
        ''' </summary>
        ''' <param name="objModulePermission">The Module Permission to add</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function AddModulePermission(ByVal objModulePermission As ModulePermissionInfo) As Integer
            Dim Id As Integer = provider.AddModulePermission(objModulePermission.ModuleID, objModulePermission.PermissionID, objModulePermission.RoleID, objModulePermission.AllowAccess, objModulePermission.UserID)
            ClearPermissionCache(objModulePermission.ModuleID)
            Return Id
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModulePermission adds a Module Permission to the Database
        ''' </summary>
        ''' <param name="objModulePermission">The Module Permission to add</param>
        ''' <param name="tabId">The ID of the Tab</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function AddModulePermission(ByVal objModulePermission As ModulePermissionInfo, ByVal tabId As Integer) As Integer
            Dim Id As Integer = provider.AddModulePermission(objModulePermission.ModuleID, objModulePermission.PermissionID, objModulePermission.RoleID, objModulePermission.AllowAccess, objModulePermission.UserID)
            DataCache.ClearModulePermissionsCache(tabId)
            Return Id
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DeleteModulePermission deletes a Module Permission in the Database
        ''' </summary>
        ''' <param name="modulePermissionID">The ID of the Module Permission to delete</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteModulePermission(ByVal modulePermissionID As Integer)
            provider.DeleteModulePermission(modulePermissionID)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DeleteModulePermissionsByModuleID deletes a module's Module Permission in the Database
        ''' </summary>
        ''' <param name="moduleID">The ID of the Module Permission to delete</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteModulePermissionsByModuleID(ByVal moduleID As Integer)
            provider.DeleteModulePermissionsByModuleID(moduleID)
            ClearPermissionCache(moduleID)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DeleteModulePermissionsByUserID deletes a user's Module Permission in the Database
        ''' </summary>
        ''' <param name="objUser">The user</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteModulePermissionsByUserID(ByVal objUser As UserInfo)
            provider.DeleteModulePermissionsByUserID(objUser.PortalID, objUser.UserID)
            DataCache.ClearModulePermissionsCachesByPortal(objUser.PortalID)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetModulePermission gets a Module Permission from the Database
        ''' </summary>
        ''' <param name="modulePermissionID">The ID of the Module Permission</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetModulePermission(ByVal modulePermissionID As Integer) As ModulePermissionInfo
            Return CBO.FillObject(Of ModulePermissionInfo)(provider.GetModulePermission(modulePermissionID), True)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetModulePermissionsCollectionByModuleID gets a ModulePermissionCollection
        ''' </summary>
        ''' <param name="moduleID">The ID of the Module</param>
        ''' <param name="tabID">The ID of the Tab</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetModulePermissionsCollectionByModuleID(ByVal moduleID As Integer, ByVal tabID As Integer) As ModulePermissionCollection
            Return GetModulePermissions(moduleID, tabID)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UpdateModulePermission updates a Module Permission in the Database
        ''' </summary>
        ''' <param name="objModulePermission">The Module Permission to update</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub UpdateModulePermission(ByVal objModulePermission As ModulePermissionInfo)
            provider.UpdateModulePermission(objModulePermission.ModulePermissionID, objModulePermission.ModuleID, objModulePermission.PermissionID, objModulePermission.RoleID, objModulePermission.AllowAccess, objModulePermission.UserID)
            ClearPermissionCache(objModulePermission.ModuleID)
        End Sub

#End Region

#Region "Obsolete Methods"

        <Obsolete("This method has been replaced in DotNetNuke 5.0 by ModulePermissionColelction.ToString(String)")> _
        Public Function GetModulePermissions(ByVal modulePermissions As ModulePermissionCollection, ByVal permissionKey As String) As String
            Return modulePermissions.ToString(permissionKey)
        End Function

        <Obsolete("This method has been deprecated.  This should have been declared as Friend as it was never meant to be used outside of the core.")> _
        Public Function GetModulePermissionsByPortal(ByVal PortalID As Integer) As ArrayList
            Return CBO.FillCollection(DataProvider.Instance().GetModulePermissionsByPortal(PortalID), GetType(ModulePermissionInfo))
        End Function

        <Obsolete("This method has been deprecated.  This should have been declared as Friend as it was never meant to be used outside of the core.")> _
        Public Function GetModulePermissionsByTabID(ByVal TabID As Integer) As ArrayList
            Dim key As String = String.Format(DataCache.ModulePermissionCacheKey, TabID)
            Dim arrModulePermissions As ArrayList = Nothing

            arrModulePermissions = CType(DataCache.GetCache(key), ArrayList)
            If arrModulePermissions Is Nothing Then
                'modulePermission caching settings
                Dim timeOut As Int32 = DataCache.ModulePermissionCacheTimeOut * Convert.ToInt32(Host.PerformanceSetting)

                arrModulePermissions = CBO.FillCollection(DataProvider.Instance().GetModulePermissionsByTabID(TabID), GetType(ModulePermissionInfo))

                If timeOut <> 0 Then
                    DataCache.SetCache(key, arrModulePermissions, TimeSpan.FromMinutes(timeOut), True)
                End If
            End If
            Return arrModulePermissions
        End Function

        <Obsolete("This method has been deprecated.  GetModulePermissions(ModulePermissionCollection, String) ")> _
        Public Function GetModulePermissionsByModuleID(ByVal objModule As ModuleInfo, ByVal PermissionKey As String) As String
            Dim strRoles As String = ";"
            Dim strUsers As String = ";"
            Dim i As Integer
            For i = 0 To objModule.ModulePermissions.Count - 1
                Dim objModulePermission As Security.Permissions.ModulePermissionInfo = CType(objModule.ModulePermissions(i), Security.Permissions.ModulePermissionInfo)
                If objModulePermission.ModuleID = objModule.ModuleID AndAlso objModulePermission.AllowAccess = True AndAlso objModulePermission.PermissionKey = PermissionKey Then
                    If Null.IsNull(objModulePermission.UserID) Then
                        strRoles += objModulePermission.RoleName + ";"
                    Else
                        strUsers += "[" + objModulePermission.UserID.ToString + "];"
                    End If
                End If
            Next
            Return strRoles + strUsers
        End Function

        <Obsolete("This method has been deprecated.  Please use GetModulePermissionsCollectionByModuleID(ModuleID,TabId)")> _
        Public Function GetModulePermissionsCollectionByModuleID(ByVal moduleID As Integer) As Security.Permissions.ModulePermissionCollection
            Return New ModulePermissionCollection(CBO.FillCollection(DataProvider.Instance().GetModulePermissionsByModuleID(moduleID, -1), GetType(ModulePermissionInfo)))
        End Function

        <Obsolete("This method has been deprecated.  Please use GetModulePermissionsCollectionByModuleID(ModuleID,TabId)")> _
        Public Function GetModulePermissionsCollectionByModuleID(ByVal arrModulePermissions As ArrayList, ByVal moduleID As Integer) As Security.Permissions.ModulePermissionCollection
            Return New ModulePermissionCollection(arrModulePermissions, moduleID)
        End Function

        <Obsolete("This method is obsoleted.  It was used to replace lists of RoleIds by lists of RoleNames.")> _
        Public Function GetRoleNamesFromRoleIDs(ByVal Roles As String) As String
            Dim strRoles As String = ""
            If Roles.IndexOf(";") > 0 Then
                Dim arrRoles As String() = Split(Roles, ";")
                Dim i As Integer
                For i = 0 To arrRoles.Length - 1
                    If IsNumeric(arrRoles(i)) Then
                        strRoles += GetRoleName(Convert.ToInt32(arrRoles(i))) + ";"
                    End If
                Next
            ElseIf Roles.Trim.Length > 0 Then
                strRoles = GetRoleName(Convert.ToInt32(Roles.Trim))
            End If
            If Not strRoles.StartsWith(";") Then
                strRoles += ";"
            End If
            Return strRoles
        End Function

        <Obsolete("This method has been deprecated.  Please use HasModulePermission(ModuleID,TabId, PermissionKey)")> _
        Public Shared Function HasModulePermission(ByVal moduleID As Integer, ByVal PermissionKey As String) As Boolean
            Dim objModulePermissions As ModulePermissionCollection = New ModulePermissionCollection(CBO.FillCollection(DataProvider.Instance().GetModulePermissionsByModuleID(moduleID, -1), GetType(ModulePermissionInfo)))
            Return HasModulePermission(objModulePermissions, PermissionKey)
        End Function

#End Region

    End Class



End Namespace
