﻿' 
'' DotNetNuke® - http://www.dotnetnuke.com 
'' Copyright (c) 2002-2008 
'' by DotNetNuke Corporation 
'' 
'' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
'' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
'' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
'' to permit persons to whom the Software is furnished to do so, subject to the following conditions: 
'' 
'' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
'' of the Software. 
'' 
'' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
'' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
'' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
'' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
'' DEALINGS IN THE SOFTWARE. 
' 


Imports DotNetNuke.Services.Localization

Namespace DotNetNuke.Modules.Dashboard.Components
    Public Class DashboardControl
        Private _ControllerClass As String
        Public Property ControllerClass() As String
            Get
                Return _ControllerClass
            End Get
            Set(ByVal value As String)
                _ControllerClass = value
            End Set
        End Property
        Private _DashboardControlID As Integer
        Public Property DashboardControlID() As Integer
            Get
                Return _DashboardControlID
            End Get
            Set(ByVal value As Integer)
                _DashboardControlID = value
            End Set
        End Property
        Private _DashboardControlKey As String
        Public Property DashboardControlKey() As String
            Get
                Return _DashboardControlKey
            End Get
            Set(ByVal value As String)
                _DashboardControlKey = value
            End Set
        End Property
        Private _IsEnabled As Boolean
        Public Property IsEnabled() As Boolean
            Get
                Return _IsEnabled
            End Get
            Set(ByVal value As Boolean)
                _IsEnabled = value
            End Set
        End Property
        Private _DashboardControlSrc As String
        Public Property DashboardControlSrc() As String
            Get
                Return _DashboardControlSrc
            End Get
            Set(ByVal value As String)
                _DashboardControlSrc = value
            End Set
        End Property
        Private _DashboardControlLocalResources As String
        Public Property DashboardControlLocalResources() As String
            Get
                Return _DashboardControlLocalResources
            End Get
            Set(ByVal value As String)
                _DashboardControlLocalResources = value
            End Set
        End Property
        Private _ViewOrder As Integer
        Public Property ViewOrder() As Integer
            Get
                Return _ViewOrder
            End Get
            Set(ByVal value As Integer)
                _ViewOrder = value
            End Set
        End Property

        Public ReadOnly Property LocalizedTitle() As String
            Get
                Return Localization.GetString(DashboardControlKey & ".Title", "~/" & DashboardControlLocalResources)
            End Get
        End Property
    End Class
End Namespace