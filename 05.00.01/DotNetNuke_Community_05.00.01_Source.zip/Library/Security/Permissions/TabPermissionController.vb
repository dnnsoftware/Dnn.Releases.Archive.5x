'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2009
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Collections.Generic
Imports System.Data
Imports DotNetNuke
Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.Entities.Host

Namespace DotNetNuke.Security.Permissions

    ''' -----------------------------------------------------------------------------
    ''' Project	 : DotNetNuke
    ''' Namespace: DotNetNuke.Security.Permissions
    ''' Class	 : TabPermissionController
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' TabPermissionController provides the Business Layer for Tab Permissions
    ''' </summary>
    ''' <history>
    ''' 	[cnurse]	01/14/2008   Documented
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class TabPermissionController

#Region "Private Members"

        Private Shared provider As DataProvider = DataProvider.Instance()

#End Region

#Region "Private Shred Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FillTabPermissionDictionary fills a Dictionary of TabPermissions from a
        ''' dataReader
        ''' </summary>
        ''' <param name="dr">The IDataReader</param>
        ''' <history>
        ''' 	[cnurse]	01/14/2008   Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function FillTabPermissionDictionary(ByVal dr As IDataReader) As Dictionary(Of Integer, TabPermissionCollection)
            Dim dic As New Dictionary(Of Integer, TabPermissionCollection)
            Try
                Dim obj As TabPermissionInfo
                While dr.Read
                    ' fill business object
                    obj = CBO.FillObject(Of TabPermissionInfo)(dr, False)

                    ' add Tab Permission to dictionary
                    If dic.ContainsKey(obj.TabID) Then
                        'Add TabPermission to TabPermission Collection already in dictionary for TabId
                        dic(obj.TabID).Add(obj)
                    Else
                        'Create new TabPermission Collection for TabId
                        Dim collection As New TabPermissionCollection

                        'Add Permission to Collection
                        collection.Add(obj)

                        'Add Collection to Dictionary
                        dic.Add(obj.TabID, collection)
                    End If
                End While
            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try
            Return dic
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetTabPermissions gets a Dictionary of TabPermissionCollections by 
        ''' Tab.
        ''' </summary>
        ''' <param name="portalID">The ID of the portal</param>
        ''' <history>
        ''' 	[cnurse]	01/14/2008   Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetTabPermissions(ByVal portalID As Integer) As Dictionary(Of Integer, TabPermissionCollection)
            Dim cacheKey As String = String.Format(DataCache.TabPermissionCacheKey, portalID.ToString())
            Return CBO.GetCachedObject(Of Dictionary(Of Integer, TabPermissionCollection))(New CacheItemArgs(cacheKey, DataCache.TabPermissionCacheTimeOut, DataCache.TabPermissionCachePriority, portalID), _
                                                                                                     AddressOf GetTabPermissionsCallBack)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetTabPermissionsCallBack gets a Dictionary of TabPermissionCollections by 
        ''' Tab from the the Database.
        ''' </summary>
        ''' <param name="cacheItemArgs">The CacheItemArgs object that contains the parameters
        ''' needed for the database call</param>
        ''' <history>
        ''' 	[cnurse]	01/14/2008   Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetTabPermissionsCallBack(ByVal cacheItemArgs As CacheItemArgs) As Object
            Dim portalID As Integer = DirectCast(cacheItemArgs.ParamList(0), Integer)
            Return FillTabPermissionDictionary(provider.GetTabPermissionsByPortal(portalID))
        End Function

#End Region

#Region "Public Shared Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetTabPermissions gets a TabPermissionCollection
        ''' </summary>
        ''' <param name="tabID">The ID of the tab</param>
        ''' <param name="portalID">The ID of the portal</param>
        ''' <history>
        ''' 	[cnurse]	01/14/2008   Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetTabPermissions(ByVal tabID As Integer, ByVal portalID As Integer) As TabPermissionCollection
            Dim bFound As Boolean = False

            'Get the Portal TabPermission Dictionary
            Dim dicTabPermissions As Dictionary(Of Integer, TabPermissionCollection) = GetTabPermissions(portalID)

            'Get the Collection from the Dictionary
            Dim tabPermissions As TabPermissionCollection = Nothing
            bFound = dicTabPermissions.TryGetValue(tabID, tabPermissions)

            If Not bFound Then
                'try the database
                tabPermissions = New TabPermissionCollection(CBO.FillCollection(provider.GetTabPermissionsByTabID(tabID, -1), GetType(TabPermissionInfo)), tabID)
            End If

            Return tabPermissions
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' HasTabPermission checks whether the current user has a specific Tab Permission
        ''' </summary>
        ''' <param name="permissionKey">The Permission to check</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function HasTabPermission(ByVal permissionKey As String) As Boolean
            Dim _PortalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
            Return HasTabPermission(_PortalSettings.ActiveTab.TabPermissions, permissionKey)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' HasTabPermission checks whether the current user has a specific Tab Permission
        ''' </summary>
        ''' <param name="objTabPermissions">The Permissions for the Tab</param>
        ''' <param name="permissionKey">The Permission to check</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function HasTabPermission(ByVal objTabPermissions As Security.Permissions.TabPermissionCollection, ByVal permissionKey As String) As Boolean
            Return PortalSecurity.IsInRoles(objTabPermissions.ToString(permissionKey))
        End Function

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ClearPermissionCache clears the Tab Permission Cache
        ''' </summary>
        ''' <param name="tabId">The ID of the Tab</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ClearPermissionCache(ByVal tabId As Integer)
            Dim objTabs As New TabController
            Dim objTab As TabInfo = objTabs.GetTab(tabId, Null.NullInteger, False)
            DataCache.ClearTabPermissionsCache(objTab.PortalID)
        End Sub

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddTabPermission adds a Tab Permission to the Database
        ''' </summary>
        ''' <param name="objTabPermission">The Tab Permission to add</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function AddTabPermission(ByVal objTabPermission As TabPermissionInfo) As Integer
            Dim Id As Integer = CType(provider.AddTabPermission(objTabPermission.TabID, objTabPermission.PermissionID, objTabPermission.RoleID, objTabPermission.AllowAccess, objTabPermission.UserID), Integer)
            ClearPermissionCache(objTabPermission.TabID)
            Return Id
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DeleteTabPermission deletes a Tab Permission in the Database
        ''' </summary>
        ''' <param name="tabPermissionID">The ID of the Tab Permission to delete</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteTabPermission(ByVal tabPermissionID As Integer)
            provider.DeleteTabPermission(tabPermissionID)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DeleteTabPermissionsByTabID deletes a tabs's Tab Permissions in the Database
        ''' </summary>
        ''' <param name="tabID">The ID of the Tab Permissions to delete</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteTabPermissionsByTabID(ByVal tabID As Integer)
            provider.DeleteTabPermissionsByTabID(tabID)
            ClearPermissionCache(tabID)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DeleteTabPermissionsByUserID deletes a user's Tab Permissions in the Database
        ''' </summary>
        ''' <param name="objUser">The user</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteTabPermissionsByUserID(ByVal objUser As UserInfo)
            provider.DeleteTabPermissionsByUserID(objUser.PortalID, objUser.UserID)
            DataCache.ClearTabPermissionsCache(objUser.PortalID)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetTabPermissionsCollectionByTabID gets a TabPermissionCollection
        ''' </summary>
        ''' <param name="tabID">The ID of the Tab</param>
        ''' <param name="portalID">The ID of the Portal</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetTabPermissionsCollectionByTabID(ByVal tabID As Integer, ByVal portalID As Integer) As TabPermissionCollection
            Return GetTabPermissions(tabID, portalID)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UpdateTabPermission updates a Tab Permission in the Database
        ''' </summary>
        ''' <param name="objTabPermission">The Tab Permission to update</param>
        ''' <history>
        ''' 	[cnurse]	01/15/2008   Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub UpdateTabPermission(ByVal objTabPermission As TabPermissionInfo)
            provider.UpdateTabPermission(objTabPermission.TabPermissionID, objTabPermission.TabID, objTabPermission.PermissionID, objTabPermission.RoleID, objTabPermission.AllowAccess, objTabPermission.UserID)
            ClearPermissionCache(objTabPermission.TabID)
        End Sub

#End Region

#Region "Obsolete Methods"

        <Obsolete("This method has been deprecated.  This should have been declared as Friend as it was never meant to be used outside of the core.")> _
        Public Function GetTabPermissionsByPortal(ByVal PortalID As Integer) As ArrayList
            Dim key As String = String.Format(DataCache.TabPermissionCacheKey, PortalID)

            Dim arrTabPermissions As ArrayList = CType(DataCache.GetCache(key), ArrayList)

            If arrTabPermissions Is Nothing Then
                'tabPermission caching settings
                Dim timeOut As Int32 = DataCache.TabPermissionCacheTimeOut * Convert.ToInt32(Host.PerformanceSetting)

                arrTabPermissions = CBO.FillCollection((DataProvider.Instance().GetTabPermissionsByPortal(PortalID)), GetType(TabPermissionInfo))

                'Cache tabs
                If timeOut > 0 Then
                    DataCache.SetCache(key, arrTabPermissions, TimeSpan.FromMinutes(timeOut))
                End If
            End If
            Return arrTabPermissions
        End Function

        <Obsolete("This method has been deprecated.  Please use GetTabPermissionsCollectionByTabID(TabId, PortalId)")> _
        Public Function GetTabPermissionsByTabID(ByVal TabID As Integer) As ArrayList
            Return CBO.FillCollection((DataProvider.Instance().GetTabPermissionsByTabID(TabID, -1)), GetType(TabPermissionInfo))
        End Function

        <Obsolete("This method has been deprecated.  GetTabPermissions(TabPermissionCollection, String) ")> _
        Public Function GetTabPermissionsByTabID(ByVal arrTabPermissions As ArrayList, ByVal TabID As Integer, ByVal PermissionKey As String) As String
            Dim strRoles As String = ";"
            Dim strUsers As String = ";"
            Dim i As Integer
            For i = 0 To arrTabPermissions.Count - 1
                Dim objTabPermission As Security.Permissions.TabPermissionInfo = CType(arrTabPermissions(i), Security.Permissions.TabPermissionInfo)
                If objTabPermission.TabID = TabID AndAlso objTabPermission.AllowAccess = True AndAlso objTabPermission.PermissionKey = PermissionKey Then
                    If Null.IsNull(objTabPermission.UserID) Then
                        strRoles += objTabPermission.RoleName + ";"
                    Else
                        strUsers += "[" + objTabPermission.UserID.ToString + "];"
                    End If
                End If
            Next
            Return strRoles + strUsers
        End Function

        <Obsolete("This method has been deprecated.  Please use GetTabPermissionsCollectionByTabID(TabId, PortalId)")> _
        Public Function GetTabPermissionsByTabID(ByVal arrTabPermissions As ArrayList, ByVal TabID As Integer) As TabPermissionCollection
            Dim p As New Security.Permissions.TabPermissionCollection
            Dim i As Integer
            For i = 0 To arrTabPermissions.Count - 1
                Dim objTabPermission As TabPermissionInfo = CType(arrTabPermissions(i), TabPermissionInfo)
                If objTabPermission.TabID = TabID Then
                    p.Add(objTabPermission)
                End If
            Next
            Return p
        End Function

        <Obsolete("This method has been deprecated.  Please use GetTabPermissionsCollectionByTabID(TabId, PortalId)")> _
        Public Function GetTabPermissionsCollectionByTabID(ByVal TabID As Integer) As Security.Permissions.TabPermissionCollection
            Return New TabPermissionCollection(CBO.FillCollection((DataProvider.Instance().GetTabPermissionsByTabID(TabID, -1)), GetType(TabPermissionInfo)))
        End Function

        <Obsolete("This method has been deprecated.  Please use GetTabPermissionsCollectionByTabID(TabId, PortalId)")> _
        Public Function GetTabPermissionsCollectionByTabID(ByVal arrTabPermissions As ArrayList, ByVal TabID As Integer) As Security.Permissions.TabPermissionCollection
            Return New TabPermissionCollection(arrTabPermissions, TabID)
        End Function

        <Obsolete("This method has been replaced in DotNetNuke 5.0 by TabPermissionCollection.ToString(String)")> _
        Public Function GetTabPermissions(ByVal tabPermissions As TabPermissionCollection, ByVal permissionKey As String) As String
            Return tabPermissions.ToString(permissionKey)
        End Function

#End Region

    End Class


End Namespace
