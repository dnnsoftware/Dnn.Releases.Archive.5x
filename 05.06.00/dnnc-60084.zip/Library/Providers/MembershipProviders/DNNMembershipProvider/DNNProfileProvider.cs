//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Data;
using DotNetNuke.Common.Utilities;
using DotNetNuke.ComponentModel;
using DotNetNuke.Entities.Profile;
using DotNetNuke.Entities.Users;
using DotNetNuke.Security.Membership.Data;
using System.Web;

namespace DotNetNuke.Security.Profile
{
	public class DNNProfileProvider : ProfileProvider
	{
		private DotNetNuke.Security.Membership.Data.DataProvider dataProvider;
		public DNNProfileProvider()
		{
			dataProvider = DotNetNuke.Security.Membership.Data.DataProvider.Instance();
			if (dataProvider == null) {
				string defaultprovider = DotNetNuke.Data.DataProvider.Instance().DefaultProviderName;
				string dataProviderNamespace = "DotNetNuke.Security.Membership.Data";
				if (defaultprovider == "SqlDataProvider") {
					dataProvider = new SqlDataProvider();
				} else {
					string providerType = dataProviderNamespace + "." + defaultprovider;
					dataProvider = (DataProvider)Framework.Reflection.CreateObject(providerType, providerType, true);
				}
				ComponentFactory.RegisterComponentInstance<DataProvider>(dataProvider);
			}
		}
		public override bool CanEditProviderProperties {
			get { return true; }
		}
		public override void GetUserProfile(ref UserInfo user)
		{
			int portalId;
			int definitionId;
			ProfilePropertyDefinition profProperty;
			ProfilePropertyDefinitionCollection properties;
			if (user.IsSuperUser) {
				portalId = Common.Globals.glbSuperUserAppName;
			} else {
				portalId = user.PortalID;
			}
			properties = ProfileController.GetPropertyDefinitionsByPortal(portalId, true);
			if (user.UserID > Null.NullInteger) {
				IDataReader dr = dataProvider.GetUserProfile(user.UserID);
				try {
					while (dr.Read()) {
						if (!string.Equals(dr.GetName(0), "ProfileID", StringComparison.InvariantCultureIgnoreCase)) {
							break;
						}
						definitionId = Convert.ToInt32(dr["PropertyDefinitionId"]);
						profProperty = properties.GetById(definitionId);
						if (profProperty != null) {
							profProperty.PropertyValue = Convert.ToString(dr["PropertyValue"]);
							profProperty.Visibility = (UserVisibilityMode)dr["Visibility"];
						}
					}
				} finally {
					CBO.CloseDataReader(dr, true);
				}
			}
			user.Profile.ProfileProperties.Clear();
			foreach (ProfilePropertyDefinition property in properties)
			{
				profProperty = property;
				if (string.IsNullOrEmpty(profProperty.PropertyValue) && !string.IsNullOrEmpty(profProperty.DefaultValue)) {
					profProperty.PropertyValue = profProperty.DefaultValue;
				}
				user.Profile.ProfileProperties.Add(profProperty);
			}
			user.Profile.ClearIsDirty();
		}
		public override void UpdateUserProfile(UserInfo user)
		{
			ProfilePropertyDefinitionCollection properties = user.Profile.ProfileProperties;
			foreach (ProfilePropertyDefinition profProperty in properties) {
				if ((profProperty.PropertyValue != null) && (profProperty.IsDirty)) {
					PortalSecurity objSecurity = new PortalSecurity();
					string propertyValue = objSecurity.InputFilter(profProperty.PropertyValue, PortalSecurity.FilterFlag.NoScripting);
					dataProvider.UpdateProfileProperty(Null.NullInteger, user.UserID, profProperty.PropertyDefinitionId, propertyValue, (int)profProperty.Visibility, DateTime.Now);
					Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
					objEventLog.AddLog(user, Entities.Portals.PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, "", "USERPROFILE_UPDATED");
				}
			}
		}
	}
}
