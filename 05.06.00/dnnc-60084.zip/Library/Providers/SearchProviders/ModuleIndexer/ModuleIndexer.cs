//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections;
using DotNetNuke.Entities.Modules;
namespace DotNetNuke.Services.Search
{
	public class ModuleIndexer : IndexingProvider
	{
		public override SearchItemInfoCollection GetSearchIndexItems(int PortalID)
		{
			SearchItemInfoCollection SearchItems = new SearchItemInfoCollection();
			SearchContentModuleInfoCollection SearchCollection = GetModuleList(PortalID);
			foreach (SearchContentModuleInfo ScModInfo in SearchCollection) {
				try {
					SearchItemInfoCollection myCollection;
					myCollection = ScModInfo.ModControllerType.GetSearchItems(ScModInfo.ModInfo);
					if (myCollection != null) {
					    foreach (SearchItemInfo searchItem in myCollection)
					    {
					        searchItem.TabId = ScModInfo.ModInfo.TabID;
					    } 

						SearchItems.AddRange(myCollection);
					}
				} catch (Exception ex) {
					DotNetNuke.Services.Exceptions.Exceptions.LogException(ex);
				}
			}
			return SearchItems;
		}
		protected SearchContentModuleInfoCollection GetModuleList(int PortalID)
		{
			SearchContentModuleInfoCollection Results = new SearchContentModuleInfoCollection();
			ModuleController objModules = new ModuleController();
			ArrayList arrModules = objModules.GetSearchModules(PortalID);
			Hashtable businessControllers = new Hashtable();
			Hashtable htModules = new Hashtable();
			foreach (ModuleInfo objModule in arrModules) {
				if (!htModules.ContainsKey(objModule.ModuleID)) {
					try {
						object objController = businessControllers[objModule.DesktopModule.BusinessControllerClass];
						if (!String.IsNullOrEmpty(objModule.DesktopModule.BusinessControllerClass)) {
							if (objController == null) {
								objController = Framework.Reflection.CreateObject(objModule.DesktopModule.BusinessControllerClass, objModule.DesktopModule.BusinessControllerClass);
								businessControllers.Add(objModule.DesktopModule.BusinessControllerClass, objController);
							}
							if (objController is ISearchable) {
								SearchContentModuleInfo ContentInfo = new SearchContentModuleInfo();
								ContentInfo.ModControllerType = (ISearchable)objController;
								ContentInfo.ModInfo = objModule;
								Results.Add(ContentInfo);
							}
						}
					} catch (Exception ex) {
						try {
							string strMessage = string.Format("Error Creating BusinessControllerClass '{0}' of module({1}) id=({2}) in tab({3}) and portal({4}) ", objModule.DesktopModule.BusinessControllerClass, objModule.DesktopModule.ModuleName, objModule.ModuleID, objModule.TabID, objModule.PortalID);
							throw new Exception(strMessage, ex);
						} catch (Exception ex1) {
							DotNetNuke.Services.Exceptions.Exceptions.LogException(ex1);
						}
					} finally {
						htModules.Add(objModule.ModuleID, objModule.ModuleID);
					}
				}
			}
			return Results;
		}
	}
}
