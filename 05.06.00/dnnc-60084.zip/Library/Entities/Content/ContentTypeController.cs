﻿using System.Linq;
using DotNetNuke.Common;
using DotNetNuke.Common.Utilities;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using DotNetNuke.Entities.Content.Common;
using DotNetNuke.Entities.Content.Data;

namespace DotNetNuke.Entities.Content
{
    public class ContentTypeController : IContentTypeController
    {

        #region "Private Members"


        private IDataService _DataService;
        private string _CacheKey = "ContentTypes";

        private int _CacheTimeOut = 20;
        #endregion

        #region "Constructors"

        public ContentTypeController()
            : this(Util.GetDataService())
        {
        }

        public ContentTypeController(IDataService dataService)
        {
            _DataService = dataService;
        }

        #endregion

        #region "Private Methods"

        private object GetContentTypesCallBack(CacheItemArgs cacheItemArgs)
        {
            return CBO.FillQueryable<ContentType>(_DataService.GetContentTypes());
        }

        #endregion

        #region "Public Methods"

        public int AddContentType(ContentType contentType)
        {
            //Argument Contract
			Requires.NotNull("contentType", contentType);
			Requires.PropertyNotNullOrEmpty("contentType", "ContentType", contentType.Type);

            contentType.ContentTypeId = _DataService.AddContentType(contentType);

            //Refresh cached collection of types
            DataCache.RemoveCache(_CacheKey);

            return contentType.ContentTypeId;
        }

        public void ClearContentTypeCache()
        {
            DataCache.RemoveCache(_CacheKey);
        }

        public void DeleteContentType(ContentType contentType)
        {
            //Argument Contract
			Requires.NotNull("contentType", contentType);
			Requires.PropertyNotNegative("contentType", "ContentTypeId", contentType.ContentTypeId);

            _DataService.DeleteContentType(contentType);

            //Refresh cached collection of types
            DataCache.RemoveCache(_CacheKey);
        }

        public IQueryable<ContentType> GetContentTypes()
        {
            return CBO.GetCachedObject<IQueryable<ContentType>>(new CacheItemArgs(_CacheKey, _CacheTimeOut), GetContentTypesCallBack);
        }

        public void UpdateContentType(ContentType contentType)
        {
            //Argument Contract
			Requires.NotNull("contentType", contentType);
			Requires.PropertyNotNegative("contentType", "ContentTypeId", contentType.ContentTypeId);
			Requires.PropertyNotNullOrEmpty("contentType", "ContentType", contentType.Type);

            _DataService.UpdateContentType(contentType);

            //Refresh cached collection of types
            DataCache.RemoveCache(_CacheKey);
        }

        #endregion

    }

}
