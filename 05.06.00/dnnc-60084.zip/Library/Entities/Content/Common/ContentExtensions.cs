﻿using System.Collections.Generic;
using System.Linq;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System.Runtime.CompilerServices;
using System.Text;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Content.Taxonomy;
using System.Collections.Specialized;
using DotNetNuke.Entities.Content.Common;

namespace DotNetNuke.Entities.Content
{

    public static class ContentExtensions
	{

		#region "Term Extensions"

		static internal List<Term> GetChildTerms(this Term Term, int termId, int vocabularyId)
		{
			ITermController ctl = DotNetNuke.Entities.Content.Common.Util.GetTermController();

			IQueryable<Term> terms = from term in ctl.GetTermsByVocabulary(vocabularyId)
									 where term.ParentTermId == termId
									 select term;

			return terms.ToList();
		}

		static internal Vocabulary GetVocabulary(this Term term, int vocabularyId)
		{
			IVocabularyController ctl = DotNetNuke.Entities.Content.Common.Util.GetVocabularyController();

			return (from v in ctl.GetVocabularies()
					where v.VocabularyId == vocabularyId
					select v)
					.SingleOrDefault();
		}

		public static string ToDelimittedString(this List<Term> terms, string delimitter)
		{
			StringBuilder sb = new StringBuilder();
			if (terms != null)
			{
				foreach (Term _Term in (from term in terms orderby term.Name ascending select term))
				{
					if (sb.Length > 0)
					{
						sb.Append(delimitter);
					}
					sb.Append(_Term.Name);
				}
			}
			return sb.ToString();
		}

		public static string ToDelimittedString(this List<Term> terms, string format, string delimitter)
		{
			StringBuilder sb = new StringBuilder();
			if (terms != null)
			{
				foreach (Term _Term in (from term in terms orderby term.Name ascending select term))
				{
					if (sb.Length > 0)
					{
						sb.Append(delimitter);
					}
					sb.Append(string.Format(format, _Term.Name));
				}
			}
			return sb.ToString();
		}

		#endregion

		#region "Vocabulary Extensions"

		static internal ScopeType GetScopeType(this Vocabulary voc, int scopeTypeId)
		{
			IScopeTypeController ctl = DotNetNuke.Entities.Content.Common.Util.GetScopeTypeController();

			return ctl.GetScopeTypes().Where(s => s.ScopeTypeId == scopeTypeId).SingleOrDefault();
		}

		static internal List<Term> GetTerms(this Vocabulary voc, int vocabularyId)
		{
			ITermController ctl = DotNetNuke.Entities.Content.Common.Util.GetTermController();

			return ctl.GetTermsByVocabulary(vocabularyId).ToList();
		}

		#endregion

		#region "ContentItem Extensions"
		internal static NameValueCollection GetMetaData(this ContentItem item, int contentItemId)
		{
			IContentController ctl = Util.GetContentController();

			NameValueCollection _MetaData;
			if (contentItemId == Null.NullInteger)
			{
				_MetaData = new NameValueCollection();
			}
			else
			{
				_MetaData = ctl.GetMetaData(contentItemId);
			}

			return _MetaData;
		}
		internal static List<Term> GetTerms(this ContentItem item, int contentItemId)
		{
			ITermController ctl = DotNetNuke.Entities.Content.Common.Util.GetTermController();

			List<Term> _Terms = null;
			if (contentItemId == Null.NullInteger)
			{
				_Terms = new List<Term>();
			}
			else
			{
				_Terms = ctl.GetTermsByContent(contentItemId).ToList();
			}

			return _Terms;
		}
		#endregion
	}

}
