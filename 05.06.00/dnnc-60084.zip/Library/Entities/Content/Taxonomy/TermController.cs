﻿using System.Linq;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//
using System.Web.Caching;
using DotNetNuke.Common;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Content.Common;
using DotNetNuke.Entities.Content.Data;
using DotNetNuke.Entities.Users;

namespace DotNetNuke.Entities.Content.Taxonomy
{
    public class TermController : ITermController
    {

        #region "Private Members"

        private string _CacheKey = "Terms_{0}";
        private CacheItemPriority _CachePriority = CacheItemPriority.Normal;

        private int _CacheTimeOut = 20;

        private IDataService _DataService;
        #endregion

        #region "Constructors"

        public TermController()
            : this(Util.GetDataService())
        {
        }

        public TermController(IDataService dataService)
        {
            _DataService = dataService;
        }

        #endregion

        #region "Private Methods"

        private object GetTermsCallBack(CacheItemArgs cacheItemArgs)
        {
            int vocabularyId = (int)cacheItemArgs.ParamList[0];
            return CBO.FillQueryable<Term>(_DataService.GetTermsByVocabulary(vocabularyId));
        }

        #endregion

        #region "Public Methods"

        public int AddTerm(Term term)
        {
            //Argument Contract
			Requires.NotNull("term", term);
			Requires.PropertyNotNegative("term", "VocabularyId", term.VocabularyId);
			Requires.PropertyNotNullOrEmpty("term", "Name", term.Name);

            if ((term.IsHeirarchical))
            {
                term.TermId = _DataService.AddHeirarchicalTerm(term, UserController.GetCurrentUserInfo().UserID);
            }
            else
            {
                term.TermId = _DataService.AddSimpleTerm(term, UserController.GetCurrentUserInfo().UserID);
            }

            //Clear Cache
            DataCache.RemoveCache(string.Format(_CacheKey, term.VocabularyId));

            return term.TermId;
        }

        public void AddTermToContent(Term term, ContentItem contentItem)
        {
            //Argument Contract
			Requires.NotNull("term", term);
			Requires.NotNull("contentItem", contentItem);

            _DataService.AddTermToContent(term, contentItem);
        }

        public void DeleteTerm(Term term)
        {
            //Argument Contract
			Requires.NotNull("term", term);
			Requires.PropertyNotNegative("term", "TermId", term.TermId);

            if ((term.IsHeirarchical))
            {
                _DataService.DeleteHeirarchicalTerm(term);
            }
            else
            {
                _DataService.DeleteSimpleTerm(term);
            }

            //Clear Cache
            DataCache.RemoveCache(string.Format(_CacheKey, term.VocabularyId));
        }

        public Term GetTerm(int termId)
        {
            //Argument Contract
			Requires.NotNegative("termId", termId);

            return CBO.FillObject<Term>(_DataService.GetTerm(termId));
        }

        public IQueryable<Term> GetTermsByContent(int contentItemId)
        {
            //Argument Contract
			Requires.NotNegative("contentItemId", contentItemId);

            return CBO.FillQueryable<Term>(_DataService.GetTermsByContent(contentItemId));
        }

        public IQueryable<Term> GetTermsByVocabulary(int vocabularyId)
        {
            //Argument Contract
			Requires.NotNegative("vocabularyId", vocabularyId);

            return CBO.GetCachedObject<IQueryable<Term>>(new CacheItemArgs(string.Format(_CacheKey, vocabularyId), _CacheTimeOut, _CachePriority, vocabularyId), GetTermsCallBack);
        }

        public void RemoveTermsFromContent(ContentItem contentItem)
        {
            //Argument Contract
			Requires.NotNull("contentItem", contentItem);

            _DataService.RemoveTermsFromContent(contentItem);
        }

        public void UpdateTerm(Term term)
        {
            //Argument Contract
			Requires.NotNull("term", term);
			Requires.PropertyNotNegative("term", "TermId", term.TermId);
			Requires.PropertyNotNegative("term", "Vocabulary.VocabularyId", term.VocabularyId);
			Requires.PropertyNotNullOrEmpty("term", "Name", term.Name);

            if ((term.IsHeirarchical))
            {
				//Requires.PropertyNotNull("term", "ParentTermId", term.ParentTermId)
                _DataService.UpdateHeirarchicalTerm(term, UserController.GetCurrentUserInfo().UserID);
            }
            else
            {
                _DataService.UpdateSimpleTerm(term, UserController.GetCurrentUserInfo().UserID);
            }

            //Clear Cache
            DataCache.RemoveCache(string.Format(_CacheKey, term.VocabularyId));
        }

        #endregion

    }

}
