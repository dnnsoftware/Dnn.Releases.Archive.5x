//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using DotNetNuke.Services.Tokens;
namespace DotNetNuke.Entities.Users
{
	public class MembershipPropertyAccess : IPropertyAccess
	{
		UserInfo objUser;
		bool isSecure;
		public MembershipPropertyAccess(UserInfo User)
		{
			objUser = User;
		}
		public string GetProperty(string strPropertyName, string strFormat, System.Globalization.CultureInfo formatProvider, Entities.Users.UserInfo AccessingUser, Scope CurrentScope, ref bool PropertyNotFound)
		{
			UserMembership objMembership = objUser.Membership;
			bool UserQueriesHimself = (objUser.UserID == AccessingUser.UserID && objUser.UserID != -1);
			if (CurrentScope < Scope.DefaultSettings || (CurrentScope == Scope.DefaultSettings && !UserQueriesHimself) || ((CurrentScope != Scope.SystemMessages || objUser.IsSuperUser) && strPropertyName.ToLower().StartsWith("password")))
			{
				PropertyNotFound = true;
				return PropertyAccess.ContentLocked;
			}
			else
			{
				string OutputFormat = string.Empty;
				if (strFormat == string.Empty)
					OutputFormat = "g";
				switch (strPropertyName.ToLower())
				{
					case "approved":
						return (PropertyAccess.Boolean2LocalizedYesNo(objMembership.Approved, formatProvider));
					case "createdondate":
						return (objMembership.CreatedDate.ToString(OutputFormat, formatProvider));
					case "isonline":
						return (PropertyAccess.Boolean2LocalizedYesNo(objMembership.IsOnLine, formatProvider));
					case "lastactivitydate":
						return (objMembership.LastActivityDate.ToString(OutputFormat, formatProvider));
					case "lastlockoutdate":
						return (objMembership.LastLockoutDate.ToString(OutputFormat, formatProvider));
					case "lastlogindate":
						return (objMembership.LastLoginDate.ToString(OutputFormat, formatProvider));
					case "lastpasswordchangedate":
						return (objMembership.LastPasswordChangeDate.ToString(OutputFormat, formatProvider));
					case "lockedout":
						return (PropertyAccess.Boolean2LocalizedYesNo(objMembership.LockedOut, formatProvider));
					case "objecthydrated":
						return (PropertyAccess.Boolean2LocalizedYesNo(true, formatProvider));
					case "password":
						return PropertyAccess.FormatString(objMembership.Password, strFormat);
					case "passwordanswer":
						return PropertyAccess.FormatString(objMembership.PasswordAnswer, strFormat);
					case "passwordquestion":
						return PropertyAccess.FormatString(objMembership.PasswordQuestion, strFormat);
					case "updatepassword":
						return (PropertyAccess.Boolean2LocalizedYesNo(objMembership.UpdatePassword, formatProvider));
					case "username":
						return (PropertyAccess.FormatString(objUser.Username, strFormat));
					case "email":
						return (PropertyAccess.FormatString(objUser.Email, strFormat));
				}
			}
			return PropertyAccess.GetObjectProperty(objMembership, strPropertyName, strFormat, formatProvider, ref PropertyNotFound);
		}
		public CacheLevel Cacheability
		{
			get { return CacheLevel.notCacheable; }
		}
	}
}
