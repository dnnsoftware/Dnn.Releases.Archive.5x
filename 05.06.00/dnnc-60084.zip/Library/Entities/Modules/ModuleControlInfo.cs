//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Security;
namespace DotNetNuke.Entities.Modules
{
	[Serializable()]
	public class ModuleControlInfo : ControlInfo, IXmlSerializable, IHydratable
	{
		private int _ModuleControlID = Null.NullInteger;
		private int _ModuleDefID = Null.NullInteger;
		private string _ControlTitle;
		private SecurityAccessLevel _ControlType = SecurityAccessLevel.Anonymous;
		private string _IconFile;
		private string _HelpURL;
		private int _ViewOrder;
		public int ModuleControlID {
			get { return _ModuleControlID; }
			set { _ModuleControlID= value; }
		}
		public int ModuleDefID {
			get { return _ModuleDefID; }
			set { _ModuleDefID= value; }
		}
		public string ControlTitle {
			get { return _ControlTitle; }
			set { _ControlTitle= value; }
		}
		public SecurityAccessLevel ControlType {
			get { return _ControlType; }
			set { _ControlType= value; }
		}
		public string IconFile {
			get { return _IconFile; }
			set { _IconFile= value; }
		}
		public string HelpURL {
			get { return _HelpURL; }
			set { _HelpURL= value; }
		}
		public int ViewOrder {
			get { return _ViewOrder; }
			set { _ViewOrder= value; }
		}
		public void Fill(System.Data.IDataReader dr)
		{
			ModuleControlID = Null.SetNullInteger(dr["ModuleControlID"]);
			FillInternal(dr);
			ModuleDefID = Null.SetNullInteger(dr["ModuleDefID"]);
			ControlTitle = Null.SetNullString(dr["ControlTitle"]);
			IconFile = Null.SetNullString(dr["IconFile"]);
			HelpURL = Null.SetNullString(dr["HelpUrl"]);
			ControlType = (SecurityAccessLevel)Enum.Parse(typeof(SecurityAccessLevel), Null.SetNullString(dr["ControlType"]));
			ViewOrder = Null.SetNullInteger(dr["ViewOrder"]);
			base.FillInternal(dr);
		}
		public int KeyID {
			get { return ModuleControlID; }
			set { ModuleControlID = value; }
		}
		public XmlSchema GetSchema()
		{
			return null;
		}
		public void ReadXml(XmlReader reader)
		{
			while (reader.Read()) {
				if (reader.NodeType == XmlNodeType.EndElement) {
					break;
				} else if (reader.NodeType == XmlNodeType.Whitespace) {
					continue;
				} else {
					ReadXmlInternal(reader);
					switch (reader.Name) {
						case "controlTitle":
							ControlTitle = reader.ReadElementContentAsString();
							break;
						case "controlType":
							ControlType = (SecurityAccessLevel)Enum.Parse(typeof(SecurityAccessLevel), reader.ReadElementContentAsString());
							break;
						case "iconFile":
							IconFile = reader.ReadElementContentAsString();
							break;
						case "helpUrl":
							HelpURL = reader.ReadElementContentAsString();
							break;
						case "viewOrder":
							string elementvalue = reader.ReadElementContentAsString();
							if (!string.IsNullOrEmpty(elementvalue)) {
								ViewOrder = int.Parse(elementvalue);
							}
							break;
					}
				}
			}
		}
		public void WriteXml(XmlWriter writer)
		{
			writer.WriteStartElement("moduleControl");
			WriteXmlInternal(writer);
			writer.WriteElementString("controlTitle", ControlTitle);
			writer.WriteElementString("controlType", ControlType.ToString());
			writer.WriteElementString("iconFile", IconFile);
			writer.WriteElementString("helpUrl", HelpURL);
			if (ViewOrder > Null.NullInteger) {
				writer.WriteElementString("viewOrder", ViewOrder.ToString());
			}
			writer.WriteEndElement();
		}
	}
}
