//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Web.UI;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Users;
using DotNetNuke.Framework;
using DotNetNuke.UI.Modules;
using System;
using DotNetNuke.Security.Permissions;
namespace DotNetNuke.Entities.Modules
{
	public class PortalModuleBase : UserControlBase, IModuleControl
	{
		private string _helpfile;
		private string _localResourceFile;
		private ModuleInstanceContext _moduleContext;
		public Control Control
		{
			get { return this; }
		}
		public string ControlPath
		{
			get { return this.TemplateSourceDirectory + "/"; }
		}
		public string ControlName
		{
			get { return this.GetType().Name.Replace("_", "."); }
		}
		public string LocalResourceFile
		{
			get
			{
				string fileRoot;
				if (string.IsNullOrEmpty(_localResourceFile))
				{
					fileRoot = Path.Combine(this.ControlPath, Services.Localization.Localization.LocalResourceDirectory + "/" + this.ID);
				}
				else
				{
					fileRoot = _localResourceFile;
				}
				return fileRoot;
			}
			set { _localResourceFile = value; }
		}
		public ModuleInstanceContext ModuleContext
		{
			get
			{
				if (_moduleContext == null)
				{
					_moduleContext = new ModuleInstanceContext(this);
				}
				return _moduleContext;
			}
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public ModuleActionCollection Actions
		{
			get { return ModuleContext.Actions; }
			set { this.ModuleContext.Actions = value; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Control ContainerControl
		{
			get { return DotNetNuke.Common.Globals.FindControlRecursive(this, "ctr" + ModuleId.ToString()); }
		}
		public bool EditMode
		{
			get { return this.ModuleContext.EditMode; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public string EditUrl()
		{
			return this.ModuleContext.EditUrl();
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public string EditUrl(string ControlKey)
		{
			return this.ModuleContext.EditUrl(ControlKey);
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public string EditUrl(string KeyName, string KeyValue)
		{
			return this.ModuleContext.EditUrl(KeyName, KeyValue);
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public string EditUrl(string KeyName, string KeyValue, string ControlKey)
		{
			return this.ModuleContext.EditUrl(KeyName, KeyValue, ControlKey);
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public string EditUrl(string KeyName, string KeyValue, string ControlKey, params string[] AdditionalParameters)
		{
			return this.ModuleContext.EditUrl(KeyName, KeyValue, ControlKey, AdditionalParameters);
		}
		public string HelpURL
		{
			get { return this.ModuleContext.HelpURL; }
			set { this.ModuleContext.HelpURL = value; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public bool IsEditable
		{
			get { return this.ModuleContext.IsEditable; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public ModuleInfo ModuleConfiguration
		{
			get { return this.ModuleContext.Configuration; }
			set { this.ModuleContext.Configuration = value; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int PortalId
		{
			get { return this.ModuleContext.PortalId; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int TabId
		{
			get { return this.ModuleContext.TabId; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int TabModuleId
		{
			get { return this.ModuleContext.TabModuleId; }
			set { this.ModuleContext.TabModuleId = value; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int ModuleId
		{
			get { return this.ModuleContext.ModuleId; }
			set { this.ModuleContext.ModuleId = value; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public UserInfo UserInfo
		{
			get { return PortalSettings.UserInfo; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int UserId
		{
			get { return PortalSettings.UserId; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public PortalAliasInfo PortalAlias
		{
			get { return PortalSettings.PortalAlias; }
		}
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Hashtable Settings
		{
			get { return this.ModuleContext.Settings; }
		}
		protected void AddActionHandler(ActionEventHandler e)
		{
			DotNetNuke.UI.Skins.Skin ParentSkin = DotNetNuke.UI.Skins.Skin.GetParentSkin(this);
			if (ParentSkin != null)
			{
				ParentSkin.RegisterModuleActionEvent(this.ModuleId, e);
			}
		}
		public int GetNextActionID()
		{
			return this.ModuleContext.GetNextActionID();
		}

		#region "Obsolete methods"

		// CONVERSION: Remove obsoleted methods (FYI some core modules use these, such as Links)
		/// -----------------------------------------------------------------------------
		/// <summary>
		/// The CacheDirectory property is used to return the location of the "Cache"
		/// Directory for the Module
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <history>
		///   [cnurse] 04/28/2005  Created
		/// </history>
		/// -----------------------------------------------------------------------------
		/// 
		[Obsolete("This property is deprecated.  Plaese use ModuleController.CacheDirectory()")]
		public string CacheDirectory
		{
			get { return PortalController.GetCurrentPortalSettings().HomeDirectoryMapPath + "Cache"; }
		}

		/// -----------------------------------------------------------------------------
		/// <summary>
		/// The CacheFileName property is used to store the FileName for this Module's
		/// Cache
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <history>
		///   [cnurse] 04/28/2005  Created
		/// </history>
		/// -----------------------------------------------------------------------------
		[Obsolete("This property is deprecated.  Please use ModuleController.CacheFileName(TabModuleID)")]
		public string CacheFileName
		{
			get
			{
				string strCacheKey = "TabModule:";
				strCacheKey += TabModuleId.ToString() + ":";
                strCacheKey += System.Threading.Thread.CurrentThread.CurrentUICulture.ToString();
				return PortalController.GetCurrentPortalSettings().HomeDirectoryMapPath + "Cache" + "\\" + Common.Globals.CleanFileName(strCacheKey) + ".resources";
			}
		}

		[Obsolete("This property is deprecated.  Please use ModuleController.CacheFileName(TabModuleID)")]
		public string GetCacheFileName(int tabModuleId)
		{
			string strCacheKey = "TabModule:";
			strCacheKey += tabModuleId.ToString() + ":";
            strCacheKey += System.Threading.Thread.CurrentThread.CurrentUICulture.ToString();
			return PortalController.GetCurrentPortalSettings().HomeDirectoryMapPath + "Cache" + "\\" + Common.Globals.CleanFileName(strCacheKey) + ".resources";
		}

		[Obsolete("This property is deprecated.  Please use ModuleController.CacheKey(TabModuleID)")]
		public string CacheKey
		{
			get
			{
				string strCacheKey = "TabModule:";
				strCacheKey += TabModuleId.ToString() + ":";
                strCacheKey += System.Threading.Thread.CurrentThread.CurrentUICulture.ToString();
				return strCacheKey;
			}
		}

		[Obsolete("This property is deprecated.  Please use ModuleController.CacheKey(TabModuleID)")]
		public string GetCacheKey(int tabModuleId)
		{

			string strCacheKey = "TabModule:";
			strCacheKey += tabModuleId.ToString() + ":";
            strCacheKey += System.Threading.Thread.CurrentThread.CurrentUICulture.ToString();
			return strCacheKey;
		}

		[Obsolete("Deprecated in DNN 5.0. Please use ModulePermissionController.HasModulePermission(ModuleConfiguration.ModulePermissions, PermissionKey) ")]
		public bool HasModulePermission(string PermissionKey)
		{
			return ModulePermissionController.HasModulePermission(this.ModuleConfiguration.ModulePermissions, PermissionKey);
		}

		// CONVERSION: Obsolete pre 5.0 => Remove in 5.0
		[ObsoleteAttribute("The HelpFile() property was deprecated in version 2.2. Help files are now stored in the /App_LocalResources folder beneath the module with the following resource key naming convention: ModuleHelp.Text")]
		public string HelpFile
		{
			get { return _helpfile; }
			set { _helpfile = value; }
		}

		[Obsolete("ModulePath was renamed to ControlPath and moved to IModuleControl in version 5.0")]
		public string ModulePath
		{
			get { return this.ControlPath; }
		}

		[Obsolete("This method is deprecated.  Plaese use ModuleController.SynchronizeModule(ModuleId)")]
		public void SynchronizeModule()
		{
			ModuleController.SynchronizeModule(ModuleId);
		}

		#endregion
	}
}
