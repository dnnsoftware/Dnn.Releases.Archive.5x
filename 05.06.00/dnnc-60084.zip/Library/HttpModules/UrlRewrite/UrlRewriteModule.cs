//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Web;
using DotNetNuke.Common;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Host;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Tabs;
namespace DotNetNuke.HttpModules
{
    public class UrlRewriteModule : IHttpModule
    {
        private string FormatDomain(string URL, string ReplaceDomain, string WithDomain)
        {
            if (!String.IsNullOrEmpty(ReplaceDomain) && !String.IsNullOrEmpty(WithDomain))
            {
                if (URL.IndexOf(ReplaceDomain) != -1)
                {
                    URL = URL.Replace(ReplaceDomain, WithDomain);
                }
            }
            return URL;
        }
        private void RewriteUrl(HttpApplication app)
        {
            HttpRequest Request = app.Request;
            HttpResponse Response = app.Response;
            string requestedPath = app.Request.Url.AbsoluteUri;
            app.Context.Items.Add("UrlRewrite:OriginalUrl", app.Request.Url.AbsoluteUri);
            string sendTo = "";
            string strQueryString = "";
            if ((!String.IsNullOrEmpty(app.Request.Url.Query)))
            {
                strQueryString = Request.QueryString.ToString();
                requestedPath = requestedPath.Replace(app.Request.Url.Query, "");
            }
            Config.RewriterRuleCollection rules = Config.RewriterConfiguration.GetConfig().Rules;
            int intMatch = -1;
            for (int intRule = 0; intRule <= rules.Count - 1; intRule++)
            {
                string strLookFor = "^" + RewriterUtils.ResolveUrl(app.Context.Request.ApplicationPath, rules[intRule].LookFor) + "$";
                Match objMatch = Regex.Match(requestedPath, strLookFor, RegexOptions.IgnoreCase);
                if ((objMatch.Success))
                {
                    sendTo = RewriterUtils.ResolveUrl(app.Context.Request.ApplicationPath, Regex.Replace(requestedPath, strLookFor, rules[intRule].SendTo, RegexOptions.IgnoreCase));
                    string strParameters = objMatch.Groups[2].Value;
                    if ((strParameters.Trim().Length > 0))
                    {
                        strParameters = strParameters.Replace("\\", "/");
                        string[] arrParameters = strParameters.Split('/');
                        string strParameterDelimiter;
                        string strParameterName;
                        string strParameterValue;
                        for (int intParameter = 0; intParameter < arrParameters.Length; intParameter++)
                        {
                            if (arrParameters[intParameter].IndexOf(".aspx", StringComparison.InvariantCultureIgnoreCase) == -1)
                            {
                                strParameterName = arrParameters[intParameter].Trim();
                                if (strParameterName.Length > 0)
                                {
                                    if (sendTo.IndexOf("?" + strParameterName + "=", StringComparison.InvariantCultureIgnoreCase) == -1 && sendTo.IndexOf("&" + strParameterName + "=", StringComparison.InvariantCultureIgnoreCase) == -1)
                                    {
                                        if (sendTo.IndexOf("?") != -1)
                                        {
                                            strParameterDelimiter = "&";
                                        }
                                        else
                                        {
                                            strParameterDelimiter = "?";
                                        }
                                        sendTo = sendTo + strParameterDelimiter + strParameterName;
                                        strParameterValue = "";
                                        if (intParameter < arrParameters.Length - 1)
                                        {
                                            intParameter += 1;
                                            if (!String.IsNullOrEmpty(arrParameters[intParameter].Trim()))
                                            {
                                                strParameterValue = arrParameters[intParameter].Trim();
                                            }
                                        }
                                        if (strParameterValue.Length > 0)
                                        {
                                            sendTo = sendTo + "=" + strParameterValue;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    intMatch = intRule;
                    break;
                }
            }
            if (!String.IsNullOrEmpty(strQueryString))
            {
                string[] arrParameters = strQueryString.Split('&');
                string strParameterName;
                for (int intParameter = 0; intParameter <= arrParameters.Length - 1; intParameter++)
                {
                    strParameterName = arrParameters[intParameter];
                    if (strParameterName.IndexOf("=") != -1)
                    {
                        strParameterName = strParameterName.Substring(0, strParameterName.IndexOf("="));
                    }
                    if (sendTo.IndexOf("?" + strParameterName + "=", StringComparison.InvariantCultureIgnoreCase) == -1 && sendTo.IndexOf("&" + strParameterName + "=", StringComparison.InvariantCultureIgnoreCase) == -1)
                    {
                        if (sendTo.IndexOf("?") != -1)
                        {
                            sendTo = sendTo + "&" + arrParameters[intParameter];
                        }
                        else
                        {
                            sendTo = sendTo + "?" + arrParameters[intParameter];
                        }
                    }
                }
            }
            if (intMatch != -1)
            {
                if (rules[intMatch].SendTo.StartsWith("~"))
                {
                    RewriterUtils.RewriteUrl(app.Context, sendTo);
                }
                else
                {
                    Response.Redirect(sendTo, true);
                }
            }
            else
            {
                string domain = "";
                string url;
                if (Globals.UsePortNumber() && ((app.Request.Url.Port != 80 && !app.Request.IsSecureConnection) || (app.Request.Url.Port != 443 && app.Request.IsSecureConnection)))
                    url = app.Request.Url.Host + ":" + app.Request.Url.Port.ToString() + app.Request.Url.LocalPath;
                else
                    url = app.Request.Url.Host + app.Request.Url.LocalPath;

                string[] splitUrl = url.Split(Convert.ToChar("/"));
                string myAlias = "";
                if ((splitUrl.Length > 0))
                {
                    foreach (string urlPart in splitUrl)
                    {
                        if ((String.IsNullOrEmpty(myAlias)))
                        {
                            myAlias = urlPart;
                        }
                        else
                        {
                            myAlias = myAlias + "/" + urlPart;
                        }
                        PortalAliasInfo objPortalAlias = PortalAliasController.GetPortalAliasInfo(myAlias);
                        if (objPortalAlias != null)
                        {
                            int portalID = objPortalAlias.PortalID;
                            string tabPath = url;
                            if (tabPath.StartsWith(myAlias))
                            {
                                tabPath = url.Remove(0, myAlias.Length);
                            }
                            if ((tabPath == "/" + Common.Globals.glbDefaultPage.ToLower()))
                            {
                                return;
                            }
                            int tabID = TabController.GetTabByTabPath(portalID, tabPath.Replace("/", "//").Replace(".aspx", ""), Null.NullString);
                            if ((tabID != Null.NullInteger))
                            {
                                if ((!String.IsNullOrEmpty(app.Request.Url.Query)))
                                {
                                    RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?TabID=" + tabID.ToString() + "&" + app.Request.Url.Query.TrimStart('?'));
                                }
                                else
                                {
                                    RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?TabID=" + tabID.ToString());
                                }
                                return;
                            }
                            tabPath = tabPath.ToLower();
                            if ((tabPath.IndexOf('?') != -1))
                            {
                                tabPath = tabPath.Substring(0, tabPath.IndexOf('?'));
                            }
                            if ((tabPath == "/login.aspx"))
                            {
                                PortalInfo portal = new PortalController().GetPortal(portalID);
                                if (portal.LoginTabId > Null.NullInteger && Common.Globals.ValidateLoginTabID(portal.LoginTabId))
                                {
                                    if ((!String.IsNullOrEmpty(app.Request.Url.Query)))
                                    {
                                        RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?TabID=" + portal.LoginTabId.ToString() + app.Request.Url.Query.TrimStart('?'));
                                    }
                                    else
                                    {
                                        RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?TabID=" + portal.LoginTabId.ToString());
                                    }
                                }
                                else
                                {
                                    if ((!String.IsNullOrEmpty(app.Request.Url.Query)))
                                    {
                                        RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?portalid=" + portalID.ToString() + "&ctl=login&" + app.Request.Url.Query.TrimStart('?'));
                                    }
                                    else
                                    {
                                        RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?portalid=" + portalID.ToString() + "&ctl=login");
                                    }
                                }
                                return;
                            }
                            if ((tabPath == "/register.aspx"))
                            {
                                if ((!String.IsNullOrEmpty(app.Request.Url.Query)))
                                {
                                    RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?portalid=" + portalID.ToString() + "&ctl=Register&" + app.Request.Url.Query.TrimStart('?'));
                                }
                                else
                                {
                                    RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?portalid=" + portalID.ToString() + "&ctl=Register");
                                }
                                return;
                            }
                            if ((tabPath == "/terms.aspx"))
                            {
                                if ((!String.IsNullOrEmpty(app.Request.Url.Query)))
                                {
                                    RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?portalid=" + portalID.ToString() + "&ctl=Terms&" + app.Request.Url.Query.TrimStart('?'));
                                }
                                else
                                {
                                    RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?portalid=" + portalID.ToString() + "&ctl=Terms");
                                }
                                return;
                            }
                            if ((tabPath == "/privacy.aspx"))
                            {
                                if ((!String.IsNullOrEmpty(app.Request.Url.Query)))
                                {
                                    RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?portalid=" + portalID.ToString() + "&ctl=Privacy&" + app.Request.Url.Query.TrimStart('?'));
                                }
                                else
                                {
                                    RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?portalid=" + portalID.ToString() + "&ctl=Privacy");
                                }
                                return;
                            }
                            tabPath = tabPath.Replace("/", "//");
                            tabPath = tabPath.Replace(".aspx", "");
                            TabController objTabController = new TabController();
                            TabCollection objTabs;
                            if (tabPath.StartsWith("//host"))
                            {
                                objTabs = objTabController.GetTabsByPortal(Null.NullInteger);
                            }
                            else
                            {
                                objTabs = objTabController.GetTabsByPortal(portalID);
                            }
                            foreach (KeyValuePair<int, TabInfo> kvp in objTabs)
                            {
                                if ((kvp.Value.IsDeleted == false && kvp.Value.TabPath.ToLower() == tabPath))
                                {
                                    if ((!String.IsNullOrEmpty(app.Request.Url.Query)))
                                    {
                                        RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?portalid=" + portalID.ToString() + "&" + app.Request.Url.Query.TrimStart('?'));
                                    }
                                    else
                                    {
                                        RewriterUtils.RewriteUrl(app.Context, "~/" + Common.Globals.glbDefaultPage + "?TabID=" + kvp.Value.TabID.ToString());
                                    }
                                    return;
                                }
                            }
                        }
                        else
                        {
                        }
                    }
                }
                else
                {
                    return;
                }
            }
        }
        public string ModuleName
        {
            get { return "UrlRewriteModule"; }
        }
        public void Init(HttpApplication application)
        {
            application.BeginRequest += this.OnBeginRequest;
        }
        public void OnBeginRequest(object s, EventArgs e)
        {
            HttpApplication app = (HttpApplication)s;
            HttpServerUtility Server = app.Server;
            HttpRequest Request = app.Request;
            HttpResponse Response = app.Response;
            string requestedPath = app.Request.Url.AbsoluteUri;
            if (Request.Url.LocalPath.EndsWith("scriptresource.axd", StringComparison.InvariantCultureIgnoreCase)
                || Request.Url.LocalPath.EndsWith("webresource.axd", StringComparison.InvariantCultureIgnoreCase)
                || Request.Url.LocalPath.EndsWith("gif", StringComparison.InvariantCultureIgnoreCase)
                || Request.Url.LocalPath.EndsWith("jpg", StringComparison.InvariantCultureIgnoreCase)
                || Request.Url.LocalPath.EndsWith("css", StringComparison.InvariantCultureIgnoreCase)
                || Request.Url.LocalPath.EndsWith("js", StringComparison.InvariantCultureIgnoreCase)
            )
            {
                return;
            }
            Initialize.Init(app);
            if (Request.Url.LocalPath.EndsWith("install.aspx", StringComparison.InvariantCultureIgnoreCase)
                || Request.Url.LocalPath.EndsWith("installwizard.aspx", StringComparison.InvariantCultureIgnoreCase)
                || Request.Url.LocalPath.EndsWith("captcha.aspx", StringComparison.InvariantCultureIgnoreCase)
            )
            {
                return;
            }
            string strURL = Request.Url.AbsolutePath;
            string strDoubleDecodeURL = Server.UrlDecode(Server.UrlDecode(Request.RawUrl));
            if (Regex.Match(strURL, "[\\\\/]\\.\\.[\\\\/]").Success || Regex.Match(strDoubleDecodeURL, "[\\\\/]\\.\\.[\\\\/]").Success)
            {
                throw new HttpException(404, "Not Found");
            }
            try
            {
                if ((Request.Path.IndexOf("\\") >= 0 || System.IO.Path.GetFullPath(Request.PhysicalPath) != Request.PhysicalPath))
                {
                    throw new HttpException(404, "Not Found");
                }
            }
            catch (Exception ex)
            {
            }
            RewriteUrl(app);
            int TabId;
            int PortalId;
            string DomainName = null;
            string PortalAlias = null;
            PortalAliasInfo objPortalAliasInfo = null;
            try
            {
                if (!Int32.TryParse(Request.QueryString["tabid"], out TabId))
                {
                    TabId = Null.NullInteger;
                }
                if (!Int32.TryParse(Request.QueryString["portalid"], out PortalId))
                {
                    PortalId = Null.NullInteger;
                }
            }
            catch (Exception ex)
            {
                throw new HttpException(404, "Not Found");
            }
            try
            {
                if (Request.QueryString["alias"] != null)
                {
                    // check if the alias is valid
                    string childAlias = Request.QueryString["alias"];
                    if (!Globals.UsePortNumber())
                        childAlias = childAlias.Replace(":" + Request.Url.Port.ToString(), "");

                    if (PortalAliasController.GetPortalAliasInfo(childAlias) != null)
                    {
                        if (childAlias.IndexOf(DomainName, StringComparison.OrdinalIgnoreCase) == -1)
                        {
                            Response.Redirect(Common.Globals.GetPortalDomainName(childAlias, Request, true), true);
                        }
                        else
                        {
                            PortalAlias = childAlias;
                        }
                    }
                }
                DomainName = Common.Globals.GetDomainName(Request, true);
                if (PortalAlias == null)
                {
                    if (PortalId != -1)
                    {
                        PortalAlias = PortalAliasController.GetPortalAliasByPortal(PortalId, DomainName);
                    }
                }
                if (PortalAlias == null)
                {
                    if (TabId != -1)
                    {
                        PortalAlias = PortalAliasController.GetPortalAliasByTab(TabId, DomainName);
                        if (String.IsNullOrEmpty(PortalAlias))
                        {
                            objPortalAliasInfo = PortalAliasController.GetPortalAliasInfo(DomainName);
                            if (objPortalAliasInfo != null)
                            {
                                if (app.Request.Url.AbsoluteUri.StartsWith("https://", StringComparison.InvariantCultureIgnoreCase))
                                {
                                    strURL = "https://" + objPortalAliasInfo.HTTPAlias.Replace("*.", "");
                                }
                                else
                                {
                                    strURL = "http://" + objPortalAliasInfo.HTTPAlias.Replace("*.", "");
                                }
                                if (strURL.IndexOf(DomainName, StringComparison.InvariantCultureIgnoreCase) == -1)
                                {
                                    strURL += app.Request.Url.PathAndQuery;
                                }
                                Response.Redirect(strURL, true);
                            }
                        }
                    }
                }
                if (String.IsNullOrEmpty(PortalAlias))
                {
                    PortalAlias = DomainName;
                }
                objPortalAliasInfo = PortalAliasController.GetPortalAliasInfo(PortalAlias);
                if (objPortalAliasInfo != null)
                {
                    PortalId = objPortalAliasInfo.PortalID;
                }
                if (PortalId == -1)
                {

                    PortalId = Host.HostPortalID;
                    if (PortalId > Null.NullInteger)
                    {
                        PortalAliasController objPortalAliasController = new PortalAliasController();
                        if (new PortalController().GetPortals().Count == 1)
                        {
                            objPortalAliasInfo = new PortalAliasInfo();
                            objPortalAliasInfo.PortalID = PortalId;
                            objPortalAliasInfo.HTTPAlias = PortalAlias;
                            objPortalAliasController.AddPortalAlias(objPortalAliasInfo);
                        }
                        if (app.Request.Url.AbsoluteUri.StartsWith("https://", StringComparison.InvariantCultureIgnoreCase))
                        {
                            strURL = "https://" + objPortalAliasInfo.HTTPAlias.Replace("*.", "");
                        }
                        else
                        {
                            strURL = "http://" + objPortalAliasInfo.HTTPAlias.Replace("*.", "");
                        }

                        Response.Redirect(app.Request.Url.ToString(), true);

                    }

                }
            }
            catch (Exception ex)
            {
                strURL = "~/ErrorPage.aspx?status=500&error=" + Server.UrlEncode(ex.Message);
                HttpContext.Current.Response.Clear();
                HttpContext.Current.Server.Transfer(strURL);
            }
            if (PortalId != -1)
            {
                PortalSettings _portalSettings = new PortalSettings(TabId, objPortalAliasInfo);
                app.Context.Items.Add("PortalSettings", _portalSettings);
                if (!String.IsNullOrEmpty(_portalSettings.ActiveTab.Url) && Request.QueryString["ctl"] == null && Request.QueryString["fileticket"] == null)
                {
                    string redirectUrl = _portalSettings.ActiveTab.FullUrl;
                    if (_portalSettings.ActiveTab.PermanentRedirect)
                    {
                        Response.StatusCode = 301;
                        Response.AppendHeader("Location", redirectUrl);
                    }
                    else
                    {
                        Response.Redirect(redirectUrl, true);
                    }
                }
                if (Request.Url.AbsolutePath.EndsWith(".aspx", StringComparison.InvariantCultureIgnoreCase))
                {
                    strURL = "";
                    if (_portalSettings.SSLEnabled)
                    {
                        if (_portalSettings.ActiveTab.IsSecure == true && Request.IsSecureConnection == false)
                        {
                            strURL = requestedPath.Replace("http://", "https://");
                            strURL = FormatDomain(strURL, _portalSettings.STDURL, _portalSettings.SSLURL);
                        }
                    }
                    if (_portalSettings.SSLEnforced)
                    {
                        if (_portalSettings.ActiveTab.IsSecure == false && Request.IsSecureConnection == true)
                        {
                            if (Request.QueryString["ssl"] == null)
                            {
                                strURL = requestedPath.Replace("https://", "http://");
                                strURL = FormatDomain(strURL, _portalSettings.SSLURL, _portalSettings.STDURL);
                            }
                        }
                    }
                    if (!String.IsNullOrEmpty(strURL))
                    {
                        if (strURL.StartsWith("https://", StringComparison.InvariantCultureIgnoreCase))
                        {
                            Response.Redirect(strURL, true);
                        }
                        else
                        {
                            Response.Clear();
                            Response.AddHeader("Refresh", "0;URL=" + strURL);
                            Response.Write("<html><head><title></title>");
                            Response.Write("<!-- <script language=\"javascript\">window.location.replace(\"" + strURL + "\")</script> -->");
                            Response.Write("</head><body></body></html>");
                            Response.End();
                        }
                    }
                }
            }
            else
            {
                strURL = "~/ErrorPage.aspx?status=404&error=" + DomainName;
                HttpContext.Current.Response.Clear();
                HttpContext.Current.Server.Transfer(strURL);
            }

            if (app.Context.Items["FirstRequest"] != null)
            {
                app.Context.Items.Remove("FirstRequest");

                //Process any messages in the EventQueue for the Application_Start_FirstRequest event
                DotNetNuke.Services.EventQueue.EventQueueController.ProcessMessages("Application_Start_FirstRequest");
            }
        }
        public void Dispose()
        {
        }
    }
}
