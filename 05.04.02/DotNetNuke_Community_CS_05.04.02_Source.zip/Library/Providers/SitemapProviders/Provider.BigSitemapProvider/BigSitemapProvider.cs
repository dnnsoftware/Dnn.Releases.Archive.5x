
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Xml.Linq;
using DotNetNuke.Services.Sitemap;

namespace DotNetNuke.Sitemap
{

	public class BigSitemapProvider : SitemapProvider
	{


		public override System.Collections.Generic.List<SitemapUrl> GetUrls(int portalId, DotNetNuke.Entities.Portals.PortalSettings ps, string version)
		{
			List<SitemapUrl> urls = new List<SitemapUrl>();
			for (int i = 0; i <= 50; i++) {
				urls.Add(GetPageUrl(i));
			}

			return urls;
		}



		private SitemapUrl GetPageUrl(int index)
		{
			SitemapUrl pageUrl = new SitemapUrl();
			pageUrl.Url = string.Format("http://mysite/page_{0}.aspx", index);
			pageUrl.Priority = 0.5F;
			pageUrl.LastModified = DateTime.Now;
			pageUrl.ChangeFrequency = SitemapChangeFrequency.Daily;

			return pageUrl;
		}
	}
}
