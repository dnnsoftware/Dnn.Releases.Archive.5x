//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Globalization;
using DotNetNuke.UI.Utilities;
namespace DotNetNuke.Common.Utilities
{
	public class Calendar
	{
		public static string InvokePopupCal(System.Web.UI.WebControls.TextBox Field)
		{
			char[] TrimChars = {
				',',
				' '
			};
			string MonthNameString = "";
			foreach (string Month in DateTimeFormatInfo.CurrentInfo.MonthNames) {
				MonthNameString += Month + ",";
			}
			MonthNameString = MonthNameString.TrimEnd(TrimChars);
			string DayNameString = "";
			foreach (string Day in DateTimeFormatInfo.CurrentInfo.AbbreviatedDayNames) {
				DayNameString += Day + ",";
			}
			DayNameString = DayNameString.TrimEnd(TrimChars);
			string FormatString = DateTimeFormatInfo.CurrentInfo.ShortDatePattern.ToString();
			if (!ClientAPI.IsClientScriptBlockRegistered(Field.Page, "PopupCalendar.js")) {
				ClientAPI.RegisterClientScriptBlock(Field.Page, "PopupCalendar.js", "<script type=\"text/javascript\" src=\"" + UI.Utilities.ClientAPI.ScriptPath + "PopupCalendar.js\"></script>");
			}
			string strToday = DotNetNuke.UI.Utilities.ClientAPI.GetSafeJSString(Services.Localization.Localization.GetString("Today"));
			string strClose = DotNetNuke.UI.Utilities.ClientAPI.GetSafeJSString(Services.Localization.Localization.GetString("Close"));
			string strCalendar = DotNetNuke.UI.Utilities.ClientAPI.GetSafeJSString(Services.Localization.Localization.GetString("Calendar"));
			return "javascript:popupCal('Cal','" + Field.ClientID + "','" + FormatString + "','" + MonthNameString + "','" + DayNameString + "','" + strToday + "','" + strClose + "','" + strCalendar + "'," + (int)DateTimeFormatInfo.CurrentInfo.FirstDayOfWeek + ");";
		}
	}
}
