//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using DotNetNuke.Entities.Host;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Security;
namespace DotNetNuke.Common.Utilities
{
	public class UrlUtils
	{
		public static string DecryptParameter(string Value)
		{
			PortalSettings _portalSettings = PortalController.GetCurrentPortalSettings();
			return DecryptParameter(Value, _portalSettings.GUID.ToString());
		}
		public static string DecryptParameter(string value, string encryptionKey)
		{
			PortalSecurity objSecurity = new PortalSecurity();
			value = value.Replace("_", "/");
			value = value.Replace("-", "+");
			value = value.Replace("%3d", "=");
			return objSecurity.Decrypt(encryptionKey, value);
		}
		public static string EncryptParameter(string Value)
		{
			PortalSettings _portalSettings = PortalController.GetCurrentPortalSettings();
			return EncryptParameter(Value, _portalSettings.GUID.ToString());
		}
		public static string EncryptParameter(string Value, string encryptionKey)
		{
			PortalSecurity objSecurity = new PortalSecurity();
			string strParameter = objSecurity.Encrypt(encryptionKey, Value);
			strParameter = strParameter.Replace("/", "_");
			strParameter = strParameter.Replace("+", "-");
			strParameter = strParameter.Replace("=", "%3d");
			return strParameter;
		}
		public static string GetParameterName(string Pair)
		{
			string[] arrNameValue = Pair.Split(Convert.ToChar("="));
			return arrNameValue[0];
		}
		public static string GetParameterValue(string Pair)
		{
			string[] arrNameValue = Pair.Split('=');
			if (arrNameValue.Length > 1) {
				return arrNameValue[1];
			} else {
				return "";
			}
		}
		public static string[] GetQSParamsForNavigateURL()
		{
			string returnValue = "";
			NameValueCollection coll = HttpContext.Current.Request.QueryString;
			string[] arrKeys;
			string[] arrValues;
			arrKeys = coll.AllKeys;
			for (int i = 0; i <= arrKeys.GetUpperBound(0); i++) {
				if (arrKeys[i] != null) {
					switch (arrKeys[i].ToLower()) {
						case "tabid":
						case "ctl":
						case "language":
							break;
						default:
							if ((arrKeys[i].ToLower() == "portalid") && DotNetNuke.Common.Globals.GetPortalSettings().ActiveTab.IsSuperTab) {
							} else {
								arrValues = coll.GetValues(i);
								for (int j = 0; j <= arrValues.GetUpperBound(0); j++) {
									if (!String.IsNullOrEmpty(returnValue))
										returnValue += "&";
									returnValue += arrKeys[i] + "=" + arrValues[j];
								}
							}
							break;
					}
				}
			}
			return returnValue.Split('&');
		}
		public static void OpenNewWindow(Page page, Type type, string url)
		{
			page.ClientScript.RegisterStartupScript(type, "DotNetNuke.NewWindow", string.Format("<script>window.open('{0}','new')</script>", url));
		}
		public static string ReplaceQSParam(string strURL, string strParam, string strNewValue)
		{
			if (Host.UseFriendlyUrls) {
				return Regex.Replace(strURL, "(.*)(" + strParam + "/)([^/]+)(/.*)", "$1$2" + strNewValue + "$4", RegexOptions.IgnoreCase);
			} else {
				return Regex.Replace(strURL, "(.*)(&|\\?)(" + strParam + "=)([^&\\?]+)(.*)", "$1$2$3" + strNewValue + "$5", RegexOptions.IgnoreCase);
			}
		}
		public static string StripQSParam(string strURL, string strParam)
		{
			if (Host.UseFriendlyUrls) {
				return Regex.Replace(strURL, "(.*)(" + strParam + "/[^/]+/)(.*)", "$1$3", RegexOptions.IgnoreCase);
			} else {
				return Regex.Replace(strURL, "(.*)(&|\\?)(" + strParam + "=)([^&\\?]+)([&\\?])?(.*)", "$1$2$6", RegexOptions.IgnoreCase).Replace( "(.*)([&\\?]$)", "$1");
			}
		}
		public static string EncodeParameter(string value)
		{
			byte[] arrBytes = System.Text.Encoding.UTF8.GetBytes(value);
			value = System.Convert.ToBase64String(arrBytes);
			value = value.Replace("+", "-").Replace("/", "_").Replace("=", "$");
			return value;
		}
		public static string DecodeParameter(string value)
		{
			value = value.Replace("-", "+").Replace("_", "/").Replace("$", "=");
			byte[] arrBytes = Convert.FromBase64String(value);
			return System.Text.Encoding.UTF8.GetString(arrBytes);
		}
	}
}
