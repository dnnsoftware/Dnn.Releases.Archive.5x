//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections.Generic;
using System.Data;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Data;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Users;
namespace DotNetNuke.Security.Permissions
{
	[Serializable()]
	public class DesktopModulePermissionController
	{
		private static DataProvider provider = DataProvider.Instance();
		private static void ClearPermissionCache()
		{
			DataCache.ClearDesktopModulePermissionsCache();
		}
		private static Dictionary<int, DesktopModulePermissionCollection> FillDesktopModulePermissionDictionary(IDataReader dr)
		{
			Dictionary<int, DesktopModulePermissionCollection> dic = new Dictionary<int, DesktopModulePermissionCollection>();
			try {
				DesktopModulePermissionInfo obj;
				while (dr.Read()) {
					obj = CBO.FillObject<DesktopModulePermissionInfo>(dr, false);
					if (dic.ContainsKey(obj.PortalDesktopModuleID)) {
						dic[obj.PortalDesktopModuleID].Add(obj);
					} else {
						DesktopModulePermissionCollection collection = new DesktopModulePermissionCollection();
						collection.Add(obj);
						dic.Add(obj.PortalDesktopModuleID, collection);
					}
				}
			} catch (Exception exc) {
				DotNetNuke.Services.Exceptions.Exceptions.LogException(exc);
			} finally {
				CBO.CloseDataReader(dr, true);
			}
			return dic;
		}
		private static Dictionary<int, DesktopModulePermissionCollection> GetDesktopModulePermissions()
		{
			return CBO.GetCachedObject<Dictionary<int, DesktopModulePermissionCollection>>(new CacheItemArgs(DataCache.DesktopModulePermissionCacheKey, DataCache.DesktopModulePermissionCachePriority), GetDesktopModulePermissionsCallBack);
		}
		private static object GetDesktopModulePermissionsCallBack(CacheItemArgs cacheItemArgs)
		{
			return FillDesktopModulePermissionDictionary(provider.GetDesktopModulePermissions());
		}
		public static int AddDesktopModulePermission(DesktopModulePermissionInfo objDesktopModulePermission)
		{
			int Id = provider.AddDesktopModulePermission(objDesktopModulePermission.PortalDesktopModuleID, objDesktopModulePermission.PermissionID, objDesktopModulePermission.RoleID, objDesktopModulePermission.AllowAccess, objDesktopModulePermission.UserID, UserController.GetCurrentUserInfo().UserID);
			Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
			objEventLog.AddLog(objDesktopModulePermission, PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, "", DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.DESKTOPMODULEPERMISSION_CREATED);
			ClearPermissionCache();
			return Id;
		}
		public static void DeleteDesktopModulePermission(int DesktopModulePermissionID)
		{
			provider.DeleteDesktopModulePermission(DesktopModulePermissionID);
			Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
			objEventLog.AddLog("DesktopModulePermissionID", DesktopModulePermissionID.ToString(), PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.DESKTOPMODULEPERMISSION_DELETED);
			ClearPermissionCache();
		}
		public static void DeleteDesktopModulePermissionsByPortalDesktopModuleID(int portalDesktopModuleID)
		{
			provider.DeleteDesktopModulePermissionsByPortalDesktopModuleID(portalDesktopModuleID);
			Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
			objEventLog.AddLog("PortalDesktopModuleID", portalDesktopModuleID.ToString(), PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.DESKTOPMODULE_DELETED);
			ClearPermissionCache();
		}
		public static void DeleteDesktopModulePermissionsByUserID(UserInfo objUser)
		{
			provider.DeleteDesktopModulePermissionsByUserID(objUser.UserID);
			Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
			objEventLog.AddLog("UserID", objUser.UserID.ToString(), PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.DESKTOPMODULE_DELETED);
			ClearPermissionCache();
		}
		public static DesktopModulePermissionInfo GetDesktopModulePermission(int DesktopModulePermissionID)
		{
			return CBO.FillObject<DesktopModulePermissionInfo>(provider.GetDesktopModulePermission(DesktopModulePermissionID), true);
		}
		public static DesktopModulePermissionCollection GetDesktopModulePermissions(int portalDesktopModuleID)
		{
			bool bFound = false;
			Dictionary<int, DesktopModulePermissionCollection> dicDesktopModulePermissions = GetDesktopModulePermissions();
			DesktopModulePermissionCollection DesktopModulePermissions = null;
			bFound = dicDesktopModulePermissions.TryGetValue(portalDesktopModuleID, out DesktopModulePermissions);
			if (!bFound) {
				DesktopModulePermissions = new DesktopModulePermissionCollection(CBO.FillCollection(provider.GetDesktopModulePermissionsByPortalDesktopModuleID(portalDesktopModuleID), typeof(DesktopModulePermissionInfo)), portalDesktopModuleID);
			}
			return DesktopModulePermissions;
		}
		public static bool HasDesktopModulePermission(DesktopModulePermissionCollection objDesktopModulePermissions, string permissionKey)
		{
			return PortalSecurity.IsInRoles(objDesktopModulePermissions.ToString(permissionKey));
		}
		public static void UpdateDesktopModulePermission(DesktopModulePermissionInfo objDesktopModulePermission)
		{
			provider.UpdateDesktopModulePermission(objDesktopModulePermission.DesktopModulePermissionID, objDesktopModulePermission.PortalDesktopModuleID, objDesktopModulePermission.PermissionID, objDesktopModulePermission.RoleID, objDesktopModulePermission.AllowAccess, objDesktopModulePermission.UserID, UserController.GetCurrentUserInfo().UserID);
			Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
			objEventLog.AddLog(objDesktopModulePermission, PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, "", DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.DESKTOPMODULEPERMISSION_UPDATED);
			ClearPermissionCache();
		}
	}
}
