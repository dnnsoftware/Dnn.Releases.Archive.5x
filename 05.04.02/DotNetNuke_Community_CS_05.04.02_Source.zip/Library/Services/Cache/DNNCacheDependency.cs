//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
namespace DotNetNuke.Services.Cache
{
	public class DNNCacheDependency : IDisposable
	{
		private string[] _fileNames = null;
		private string[] _cacheKeys = null;
		private DateTime _utcStart = DateTime.MaxValue;
		private DNNCacheDependency _cacheDependency = null;
		private System.Web.Caching.CacheDependency _systemCacheDependency = null;
		public DNNCacheDependency(System.Web.Caching.CacheDependency systemCacheDependency)
		{
			_systemCacheDependency = systemCacheDependency;
		}
		public DNNCacheDependency(string filename)
		{
			_fileNames = new string[] { filename };
		}
		public DNNCacheDependency(string[] filenames)
		{
			_fileNames = filenames;
		}
		public DNNCacheDependency(string[] filenames, DateTime start)
		{
			_utcStart = start.ToUniversalTime();
			_fileNames = filenames;
		}
		public DNNCacheDependency(string[] filenames, string[] cachekeys)
		{
			_fileNames = filenames;
			_cacheKeys = cachekeys;
		}
		public DNNCacheDependency(string filename, DateTime start)
		{
			_utcStart = start.ToUniversalTime();
			if (filename != null) {
				_fileNames = new string[] { filename };
			}
		}
		public DNNCacheDependency(string[] filenames, string[] cachekeys, DateTime start)
		{
			_utcStart = start.ToUniversalTime();
			_fileNames = filenames;
			_cacheKeys = cachekeys;
		}
		public DNNCacheDependency(string[] filenames, string[] cachekeys, DNNCacheDependency dependency)
		{
			_fileNames = filenames;
			_cacheKeys = cachekeys;
			_cacheDependency = dependency;
		}
		public DNNCacheDependency(string[] filenames, string[] cachekeys, DNNCacheDependency dependency, DateTime start)
		{
			_utcStart = start.ToUniversalTime();
			_fileNames = filenames;
			_cacheKeys = cachekeys;
			_cacheDependency = dependency;
		}
		public string[] CacheKeys {
			get { return _cacheKeys; }
		}
		public string[] FileNames {
			get { return _fileNames; }
		}
		public bool HasChanged {
			get { return SystemCacheDependency.HasChanged; }
		}
		public DNNCacheDependency CacheDependency {
			get { return _cacheDependency; }
		}
		public DateTime StartTime {
			get { return _utcStart; }
		}
		public System.Web.Caching.CacheDependency SystemCacheDependency {
			get {
				try {
					if (_systemCacheDependency == null) {
						if (_cacheDependency == null) {
							_systemCacheDependency = new System.Web.Caching.CacheDependency(_fileNames, _cacheKeys, _utcStart);
						} else {
							_systemCacheDependency = new System.Web.Caching.CacheDependency(_fileNames, _cacheKeys, _cacheDependency.SystemCacheDependency, _utcStart);
						}
					}
					return _systemCacheDependency;
				} catch (Exception ex) {
					throw ex;
				}
			}
		}
		public DateTime UtcLastModified {
			get { return SystemCacheDependency.UtcLastModified; }
		}

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		protected virtual void Dispose(bool disposing)
		{
			if ((disposing)) {
				if (_cacheDependency != null)
					_cacheDependency.Dispose(disposing);
				if (_systemCacheDependency != null)
					_systemCacheDependency.Dispose();
				_fileNames = null;
				_cacheKeys = null;
				_cacheDependency = null;
				_systemCacheDependency = null;
			}
		}
	}
}
