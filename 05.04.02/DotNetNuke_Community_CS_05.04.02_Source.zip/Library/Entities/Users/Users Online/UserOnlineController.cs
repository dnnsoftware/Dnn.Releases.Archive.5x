//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections;
using System.Web;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Security.Membership;
namespace DotNetNuke.Entities.Users
{
	public class UserOnlineController
	{
		private static MembershipProvider memberProvider = MembershipProvider.Instance();
		public void ClearUserList()
		{
			string key = "OnlineUserList";
			DataCache.RemoveCache(key);
		}
		public int GetOnlineTimeWindow()
		{
			return Host.Host.UsersOnlineTimeWindow;
		}
		public Hashtable GetUserList()
		{
			string key = "OnlineUserList";
			Hashtable userList = (Hashtable)DataCache.GetCache(key);
			if ((userList == null)) {
				userList = new Hashtable();
				DataCache.SetCache(key, userList);
			}
			return userList;
		}
		public bool IsEnabled()
		{
			return Host.Host.EnableUsersOnline;
		}
		public bool IsUserOnline(UserInfo user)
		{
			bool isOnline = false;
			if (IsEnabled()) {
				isOnline = memberProvider.IsUserOnline(user);
			}
			return isOnline;
		}
		public void SetUserList(Hashtable userList)
		{
			string key = "OnlineUserList";
			DataCache.SetCache(key, userList);
		}
		private void TrackAnonymousUser(HttpContext context)
		{
			string cookieName = "DotNetNukeAnonymous";
			PortalSettings portalSettings = (PortalSettings)context.Items["PortalSettings"];
			if (portalSettings == null) {
				return;
			}
			AnonymousUserInfo user;
			Hashtable userList = GetUserList();
			string userID;
			HttpCookie cookie = context.Request.Cookies[cookieName];
			if ((cookie == null)) {
				userID = Guid.NewGuid().ToString();
				cookie = new HttpCookie(cookieName);
				cookie.Value = userID;
				cookie.Expires = DateTime.Now.AddMinutes(20);
				context.Response.Cookies.Add(cookie);
				user = new AnonymousUserInfo();
				user.UserID = userID;
				user.PortalID = portalSettings.PortalId;
				user.TabID = portalSettings.ActiveTab.TabID;
				user.CreationDate = DateTime.Now;
				user.LastActiveDate = DateTime.Now;
				if (!(userList.Contains(userID))) {
					userList[userID] = user;
				}
			} else {
				if ((cookie.Value == null)) {
					context.Response.Cookies[cookieName].Expires = new System.DateTime(1999, 10, 12);
					return;
				}
				userID = cookie.Value;
				if ((userList[userID] == null)) {
					userList[userID] = new AnonymousUserInfo();
					((AnonymousUserInfo)userList[userID]).CreationDate = DateTime.Now;
				}
				user = (AnonymousUserInfo)userList[userID];
				user.UserID = userID;
				user.PortalID = portalSettings.PortalId;
				user.TabID = portalSettings.ActiveTab.TabID;
				user.LastActiveDate = DateTime.Now;
				cookie = new HttpCookie(cookieName);
				cookie.Value = userID;
				cookie.Expires = DateTime.Now.AddMinutes(20);
				context.Response.Cookies.Add(cookie);
			}
		}
		private void TrackAuthenticatedUser(HttpContext context)
		{
			PortalSettings portalSettings = (PortalSettings)context.Items["PortalSettings"];
			if (portalSettings == null) {
				return;
			}
			UserInfo objUserInfo = UserController.GetCurrentUserInfo();
			Hashtable userList = GetUserList();
			OnlineUserInfo user = new OnlineUserInfo();
			if (objUserInfo.UserID > 0) {
				user.UserID = objUserInfo.UserID;
			}
			user.PortalID = portalSettings.PortalId;
			user.TabID = portalSettings.ActiveTab.TabID;
			user.LastActiveDate = DateTime.Now;
			if ((userList[objUserInfo.UserID.ToString()] == null)) {
				user.CreationDate = user.LastActiveDate;
			}
			userList[objUserInfo.UserID.ToString()] = user;
			SetUserList(userList);
		}
		public void TrackUsers()
		{
			HttpContext context = HttpContext.Current;
			if (!(context.Items["CheckedUsersOnlineCookie"] == null)) {
				return;
			} else {
				context.Items["CheckedUsersOnlineCookie"] = "true";
			}
			if ((context.Request.IsAuthenticated)) {
				TrackAuthenticatedUser(context);
			} else {
				if ((context.Request.Browser.Cookies)) {
					TrackAnonymousUser(context);
				}
			}
		}
		public void UpdateUsersOnline()
		{
			Hashtable userList = GetUserList();
			Hashtable listToProcess = (Hashtable)userList.Clone();
			ClearUserList();
			try {
				memberProvider.UpdateUsersOnline(listToProcess);
			} catch (Exception ex) {
			}
			memberProvider.DeleteUsersOnline(GetOnlineTimeWindow());
		}
	}
}
