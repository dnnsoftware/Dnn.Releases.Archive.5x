//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Web;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Profile;
using DotNetNuke.Services.Tokens;
namespace DotNetNuke.Entities.Users
{
	public class ProfilePropertyAccess : IPropertyAccess
	{
		UserInfo objUser;
		string strAdministratorRoleName;
		public ProfilePropertyAccess(UserInfo user)
		{
			this.objUser = user;
		}
		public string GetProperty(string strPropertyName, string strFormat, System.Globalization.CultureInfo formatProvider, Entities.Users.UserInfo AccessingUser, Scope currentScope, ref bool PropertyNotFound)
		{
			if (currentScope >= Scope.DefaultSettings && !(objUser == null || objUser.Profile == null)) {
				UserProfile objProfile = objUser.Profile;
				foreach (ProfilePropertyDefinition prop in objProfile.ProfileProperties) {
					if (prop.PropertyName.ToLower() == strPropertyName.ToLower()) {
						if (CheckAccessLevel(prop.Visibility, AccessingUser)) {
							return GetRichValue(prop, strFormat, formatProvider);
						} else {
							PropertyNotFound = true;
							return PropertyAccess.ContentLocked;
						}
						//break;
					}
				}
			}
			PropertyNotFound = true;
			return string.Empty;
		}
		public static string GetRichValue(ProfilePropertyDefinition prop, string strFormat, System.Globalization.CultureInfo formatProvider)
		{
			string result = "";
			if (!String.IsNullOrEmpty(prop.PropertyValue) || DisplayDataType(prop).ToLower() == "image")
			{
				switch (DisplayDataType(prop).ToLower()) {
					case "truefalse":
						result = PropertyAccess.Boolean2LocalizedYesNo(Convert.ToBoolean(prop.PropertyValue), formatProvider);
						break;
					case "date":
					case "datetime":
						if (strFormat == string.Empty)
							strFormat = "g";
						result = DateTime.Parse(prop.PropertyValue).ToString(strFormat, formatProvider);
						break;
					case "integer":
						if (strFormat == string.Empty)
							strFormat = "g";
						result = int.Parse(prop.PropertyValue).ToString(strFormat, formatProvider);
						break;
					case "page":
						Entities.Tabs.TabController TabCtrl = new Entities.Tabs.TabController();
						int tabid;
						if (int.TryParse(prop.PropertyValue, out tabid)) {
							Entities.Tabs.TabInfo Tab = TabCtrl.GetTab(tabid, Null.NullInteger, false);
							if (Tab != null) {
								result = string.Format("<a href='{0}'>{1}</a>", DotNetNuke.Common.Globals.NavigateURL(tabid), Tab.LocalizedTabName);
							}
						}
						break;
					case "image":
                        //File is stored as a FileID
                        int fileID;
                        if (Int32.TryParse(prop.PropertyValue, out fileID) && fileID > 0)
						{
                            result = DotNetNuke.Common.Globals.LinkClick(String.Format("fileid={0}", fileID), Null.NullInteger, Null.NullInteger);
                        }
						else
						{
							result = DotNetNuke.Common.Globals.ResolveUrl("~/images/spacer.gif");
                        }
						break;
					case "richtext":
						result = PropertyAccess.FormatString(HttpUtility.HtmlDecode(prop.PropertyValue), strFormat);
						break;
					default:
						result = PropertyAccess.FormatString(prop.PropertyValue, strFormat);
						break;
				}
			}
			return result;
		}
		private static string DisplayDataType(Entities.Profile.ProfilePropertyDefinition definition)
		{
			string CacheKey = string.Format("DisplayDataType:{0}", definition.DataType);
			string strDataType = Convert.ToString(DataCache.GetCache(CacheKey)) + "";
			if (strDataType == string.Empty) {
				Common.Lists.ListController objListController = new Common.Lists.ListController();
				strDataType = objListController.GetListEntryInfo(definition.DataType).Value;
				DataCache.SetCache(CacheKey, strDataType);
			}
			return strDataType;
		}
		private bool CheckAccessLevel(UserVisibilityMode VisibilityMode, Entities.Users.UserInfo AccessingUser)
		{
			if (String.IsNullOrEmpty(strAdministratorRoleName) && !AccessingUser.IsSuperUser) {
				DotNetNuke.Entities.Portals.PortalInfo ps = new DotNetNuke.Entities.Portals.PortalController().GetPortal(objUser.PortalID);
				strAdministratorRoleName = ps.AdministratorRoleName;
			}
			return VisibilityMode == UserVisibilityMode.AllUsers || (VisibilityMode == UserVisibilityMode.MembersOnly && AccessingUser != null) || (AccessingUser.IsSuperUser || objUser.UserID == AccessingUser.UserID || AccessingUser.IsInRole(strAdministratorRoleName));
		}
		public CacheLevel Cacheability {
			get { return CacheLevel.notCacheable; }
		}
	}
}
