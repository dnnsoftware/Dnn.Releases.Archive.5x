//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Modules;
namespace DotNetNuke.Entities.Host
{
	public class ServerInfo : IHydratable
	{
		private string _IISAppName;
		private int _ServerID;
		private string _ServerName;
		private string _Url;
		private bool _Enabled;
		private DateTime _CreatedDate;
		private DateTime _LastActivityDate;
		public ServerInfo() : this(DateTime.Now, DateTime.Now)
		{
		}
		public ServerInfo(DateTime created, DateTime lastactivity)
		{
			_IISAppName = DotNetNuke.Common.Globals.IISAppName;
			_ServerName = DotNetNuke.Common.Globals.ServerName;
			_CreatedDate = created;
			_LastActivityDate = lastactivity;
		}
		public int ServerID {
			get { return _ServerID; }
			set { _ServerID = value; }
		}
		public string IISAppName {
			get { return _IISAppName; }
			set { _IISAppName = value; }
		}
		public string ServerName {
			get { return _ServerName; }
			set { _ServerName = value; }
		}
		public string Url {
			get { return _Url; }
			set { _Url = value; }
		}
		public bool Enabled {
			get { return _Enabled; }
			set { _Enabled = value; }
		}
		public System.DateTime CreatedDate {
			get { return _CreatedDate; }
			set { _CreatedDate = value; }
		}
		public System.DateTime LastActivityDate {
			get { return _LastActivityDate; }
			set { _LastActivityDate = value; }
		}
		public void Fill(System.Data.IDataReader dr)
		{
			ServerID = Null.SetNullInteger(dr["ServerID"]);
			IISAppName = Null.SetNullString(dr["IISAppName"]);
			ServerName = Null.SetNullString(dr["ServerName"]);
			Url = Null.SetNullString(dr["URL"]);
			Enabled = Null.SetNullBoolean(dr["Enabled"]);
			CreatedDate = Null.SetNullDateTime(dr["CreatedDate"]);
			LastActivityDate = Null.SetNullDateTime(dr["LastActivityDate"]);
		}
		public int KeyID {
			get { return ServerID; }
			set { ServerID = value; }
		}
	}
}
