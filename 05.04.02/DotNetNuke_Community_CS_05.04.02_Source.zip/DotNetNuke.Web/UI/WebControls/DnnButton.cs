
using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Management;
using System.Linq;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System.Web.UI;
using System.ComponentModel;

namespace DotNetNuke.Web.UI.WebControls
{
	public class DnnButton : System.Web.UI.WebControls.Button, ILocalizable
	{
		#region "Private Members"

		private bool _Localize = true;
		private string _LocalResourceFile;

		#endregion

		#region "Constructors"
		public DnnButton()
		{
			CssClass = "CommandButton";
			DisabledCssClass = "CommandButtonDisabled";
		}
		#endregion

		#region "Public Properties"
		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public new string ConfirmMessage
		{
			get { return ViewState["ConfirmMessage"] == null ? string.Empty : ViewState["ConfirmMessage"].ToString(); }
			set { ViewState["ConfirmMessage"] = value; }
		}

		[Bindable(true)]
		[Category("Appearance")]
		[DefaultValue("")]
		[Localizable(true)]
		public string DisabledCssClass
		{
			get { return ViewState["DisabledCssClass"] == null ? string.Empty : ViewState["DisabledCssClass"].ToString(); }
			set { ViewState["DisabledCssClass"] = value; }
		}
		#endregion

		#region "Protected Methods"
		protected override void OnPreRender(System.EventArgs e)
		{
			base.OnPreRender(e);

			if ((!Enabled))
			{
				CssClass = DisabledCssClass;
			}

			if ((!string.IsNullOrEmpty(ConfirmMessage)))
			{
				string msg = ConfirmMessage;
				if ((Localize))
				{
					msg = Utilities.GetLocalizedStringFromParent(ConfirmMessage, this);
				}
				//must be done before render
				OnClientClick = Utilities.GetOnClientClickConfirm(this, msg);
			}
		}

		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			LocalizeStrings();
			base.Render(writer);
		}
		#endregion

		#region "ILocalizable Implementation"
		public bool Localize
		{
			get { return _Localize; }
			set { _Localize = value; }
		}

		public string LocalResourceFile
		{
			get { return _LocalResourceFile; }
			set { _LocalResourceFile = value; }
		}

		public virtual void LocalizeStrings()
		{
			if ((Localize))
			{
				if ((!string.IsNullOrEmpty(ToolTip)))
				{
					ToolTip = Utilities.GetLocalizedStringFromParent(ToolTip, this);
				}

				if ((!string.IsNullOrEmpty(Text)))
				{
					Text = Utilities.GetLocalizedStringFromParent(Text, this);

					if ((string.IsNullOrEmpty(ToolTip)))
					{
						ToolTip = Utilities.GetLocalizedStringFromParent(Text + ".ToolTip", this);
					}
				}
			}
		}
		#endregion

	}
}
