﻿using System;
using System.Web.UI;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using DotNetNuke.Common;
using DotNetNuke.Common.Utilities;
using DotNetNuke.UI.Modules;
using DotNetNuke.Web.Validators;
using WebFormsMvp;
using DotNetNuke.Services.Localization;

namespace DotNetNuke.Web.Mvp
{

	public abstract class ModulePresenter<TView, TModel> : Presenter<TView>
		where TView : class, IModuleView<TModel>
		where TModel : class, new()
	{

		#region "Private Members"

		private bool _IsEditable;
		private bool _IsPostBack;
		private bool _IsSuperUser;
		private string _LocalResourceFile;
		private ModuleInstanceContext _ModuleContext;
		private int _ModuleId;
		private int _PortalId;
		private int _TabId;
		private int _UserId;

		private Validator _Validator;
		#endregion

		#region "Constructors"

		public ModulePresenter(TView view)
			: base(view)
		{

			//Try and cast view to Control to get common control properties
			Control control = view as Control;
			if (control != null && control.Page != null)
			{
				_IsPostBack = control.Page.IsPostBack;
			}

			//Try and cast view to IModuleControl to get the Context
			IModuleControl moduleControl = view as IModuleControl;
			if (moduleControl != null)
			{
				_LocalResourceFile = moduleControl.LocalResourceFile;
				_ModuleContext = moduleControl.ModuleContext;
				LoadFromContext();
			}
			_Validator = new Validator(new DataAnnotationsObjectValidator());

			//Try and cast view to IInitializeView to tie up Initialization Event
			view.Initialize += InitializeInternal;

			view.Load += LoadInternal;
		}

		#endregion

		#region "Protected Properties"

		protected internal virtual bool AllowAnonymousAccess
		{
			get { return true; }
		}

		protected internal virtual bool IsUserAuthorized
		{
			get { return true; }
		}

		#endregion

		#region "Public Properties"

		public bool IsEditable
		{
			get { return _IsEditable; }
			set { _IsEditable = value; }
		}

		public bool IsPostBack
		{
			get { return _IsPostBack; }
			set { _IsPostBack = value; }
		}

		public bool IsSuperUser
		{
			get { return _IsSuperUser; }
			set { _IsSuperUser = value; }
		}

		public string LocalResourceFile
		{
			get
			{
				return _LocalResourceFile;
			}
			set
			{
				_LocalResourceFile = value;
			}
		}

		public ModuleInstanceContext ModuleContext
		{
			get { return _ModuleContext; }
			set { _ModuleContext = value; }
		}

		public int ModuleId
		{
			get { return _ModuleId; }
			set { _ModuleId = value; }
		}

		public int PortalId
		{
			get { return _PortalId; }
			set { _PortalId = value; }
		}

		public int TabId
		{
			get { return _TabId; }
			set { _TabId = value; }
		}

		public int UserId
		{
			get { return _UserId; }
			set { _UserId = value; }
		}

		public Validator Validator
		{
			get { return _Validator; }
			set { _Validator = Validator; }
		}

		#endregion

		#region "Event Handlers"

		private void InitializeInternal(object sender, EventArgs e)
		{
			OnInit();
		}

		private void LoadInternal(object sender, EventArgs e)
		{
			if (CheckAuthPolicy())
			{
				OnLoad();
			}
		}

		#endregion

		#region "Protected Methods"

		protected internal virtual bool CheckAuthPolicy()
		{
			if ((UserId == Null.NullInteger && !AllowAnonymousAccess))
			{
				OnNoCurrentUser();
				return false;
			}

			if ((!IsUserAuthorized))
			{
				OnUnauthorizedUser();
				return false;
			}

			return true;
		}

		protected virtual void LoadFromContext()
		{
			if (ModuleContext != null)
			{
				IsEditable = ModuleContext.IsEditable;
				IsSuperUser = ModuleContext.PortalSettings.UserInfo.IsSuperUser;
				ModuleId = ModuleContext.ModuleId;
				PortalId = ModuleContext.PortalId;
				TabId = ModuleContext.TabId;
				UserId = ModuleContext.PortalSettings.UserInfo.UserID;
			}
		}

		protected virtual string LocalizeString(string key)
		{
			string localizedString = null;
			if (!string.IsNullOrEmpty(key) && !string.IsNullOrEmpty(LocalResourceFile))
			{
				localizedString = Localization.GetString(key, LocalResourceFile);
			}
			else
			{
				localizedString = Null.NullString;
			}
			return localizedString;
		}

		protected virtual void OnInit()
		{
		}


		protected virtual void OnLoad()
		{
		}

		protected virtual void OnNoCurrentUser()
		{
			RedirectToLogin();
		}
		protected virtual void OnUnauthorizedUser()
		{
			RedirectToAccessDenied();
		}
		protected void RedirectToAccessDenied()
		{
			Response.Redirect(Globals.AccessDeniedURL(), true);
		}
		protected void RedirectToLogin()
		{
			Response.Redirect(Globals.LoginURL(Request.RawUrl, false), true);
		}

		protected void ProcessModuleLoadException(Exception ex)
		{
			View.ProcessModuleLoadException(ex);
		}
		protected void ShowMessage(string messageHeaderKey, string messageKey, DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType messageType)
		{
			if (!string.IsNullOrEmpty(messageKey))
			{
				string header = Null.NullString;
				if (!string.IsNullOrEmpty(messageHeaderKey))
				{
					header = LocalizeString(messageKey);
				}
				View.ShowMessage(header, LocalizeString(messageKey), messageType);
			}
		}

		protected void ShowMessage(string messageKey, DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType messageType)
		{
			if (!String.IsNullOrEmpty(messageKey))
			{
				View.ShowMessage(Null.NullString, LocalizeString(messageKey), messageType);
			}
		}

		#endregion

		#region "Public Methods"

		public override void ReleaseView()
		{
		}

		public virtual void RestoreState(StateBag stateBag)
		{
			AttributeBasedViewStateSerializer.DeSerialize(this, stateBag);
		}

		public virtual void SaveState(StateBag stateBag)
		{
			AttributeBasedViewStateSerializer.Serialize(this, stateBag);
		}

		#endregion
	}

}

