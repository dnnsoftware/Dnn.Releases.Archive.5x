﻿using System;
using System.Globalization;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using DotNetNuke.UI.Modules;
using WebFormsMvp.Web;
using WebFormsMvp;

namespace DotNetNuke.Web.Mvp
{
	public abstract class ModuleView<TModel> : ModuleUserControlBase, IModuleView<TModel> where TModel : class, new()
	{

		#region "Private Members"


		private bool _AutoDataBind;
		private TModel _Model;
		#endregion

		#region "Constructors"

		protected ModuleView()
		{
			AutoDataBind = true;
		}

		#endregion

		#region "Public Properties"

		public bool AutoDataBind {
			get { return _AutoDataBind; }
			set { _AutoDataBind = value; }
		}

		#endregion

		#region "Protected Methods"

		protected T DataItem<T>() where T : class, new()
		{
			T _T = Page.GetDataItem() as T;
			if (_T == null) {
				_T = new T();
			}
			return _T;
		}

		protected T DataValue<T>()
		{
			return (T)Page.GetDataItem();
		}

		protected string DataValue<T>(string format)
		{
			return string.Format(CultureInfo.CurrentCulture, format, DataValue<T>());
		}

		protected override void LoadViewState(object savedState)
		{
			//Call the base class to load any View State
			base.LoadViewState(savedState);

			AttributeBasedViewStateSerializer.DeSerialize(Model, ViewState);
		}

		protected override void OnInit(System.EventArgs e)
		{
			PageViewHost.Register(this, Context);

			base.OnInit(e);

			Page.InitComplete += Page_InitComplete;
			Page.PreRenderComplete += Page_PreRenderComplete;
			Page.Load += Page_Load;
		}

		protected override object SaveViewState()
		{
			AttributeBasedViewStateSerializer.Serialize(Model, ViewState);

			//Call the base class to save the View State
			return base.SaveViewState();
		}

		#endregion

			#region "IModuleView(Of TModel) Implementation"

		public event EventHandler Initialize;

		public void ProcessModuleLoadException(Exception ex)
		{
			DotNetNuke.Services.Exceptions.Exceptions.ProcessModuleLoadException(this, ex);
		}

		public void ShowMessage(string messageHeader, string message, DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType messageType)
		{
			DotNetNuke.UI.Skins.Skin.AddModuleMessage(this, messageHeader, message, messageType);
		}

		#endregion

		#region "IView(Of TModel) Implementation"

		public event EventHandler Load;

		public TModel Model {
			get {
				if ((_Model == null)) {
					throw new InvalidOperationException("The Model property is currently null, however it should have been automatically initialized by the presenter. This most likely indicates that no presenter was bound to the control. Check your presenter bindings.");
				}
				return _Model;
			}
			set { _Model = value; }
		}

		#endregion

		#region "Event Handlers"

		private void Page_InitComplete(object sender, System.EventArgs e)
		{
			//Raise Initialize Event to run any initialization code
			if (Initialize != null) {
				Initialize(this, EventArgs.Empty);
			}
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Load != null) {
				Load(this, e);
			}
		}

		private void Page_PreRenderComplete(object sender, EventArgs e)
		{
			//This event is raised after any async page tasks have completed, so it
			//is safe to data-bind
			if ((AutoDataBind))
				DataBind();
		}

		#endregion

	}
}

