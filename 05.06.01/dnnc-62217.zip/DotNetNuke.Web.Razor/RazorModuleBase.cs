﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System.Web.Compilation;
using DotNetNuke.UI.Modules;
using System.Web.UI;
using System.Globalization;
using System.IO;

using DotNetNuke.Services.Exceptions;
using DotNetNuke.Web.Razor.Helpers;
using System.Web.WebPages;
using System.Web;

namespace DotNetNuke.Web.Razor
{
	public class RazorModuleBase : ModuleUserControlBase
	{
		protected HttpContextBase HttpContext {
			get { return new HttpContextWrapper(System.Web.HttpContext.Current); }
		}

		private object CreateWebPageInstance()
		{
			Type type = BuildManager.GetCompiledType(RazorScriptFile);
			object instance = null;

			if (type != null) {
				instance = Activator.CreateInstance(type);
			}

			return instance;
		}

		private void InitHelpers(DotNetNukeWebPage webPage)
		{
			webPage.Dnn = new DnnHelper(ModuleContext);
			webPage.Html = new HtmlHelper(ModuleContext, LocalResourceFile);
			webPage.Url = new UrlHelper(ModuleContext);
		}

		protected virtual string RazorScriptFile {
			get {
				string scriptFolder = this.AppRelativeTemplateSourceDirectory;
				string fileRoot = Path.GetFileNameWithoutExtension(this.AppRelativeVirtualPath);
				string scriptFile = scriptFolder + "_" + fileRoot + ".cshtml";

				if (!File.Exists(Server.MapPath(scriptFile))) {
					//Try VB (vbhtml)
					scriptFile = scriptFolder + "_" + fileRoot + ".vbhtml";
				}

				if (!File.Exists(Server.MapPath(scriptFile))) {
					//Return ""
					scriptFile = "";
				}
				return scriptFile;
			}
		}

		protected override void OnPreRender(System.EventArgs e)
		{
			base.OnPreRender(e);

			try {

				if (!string.IsNullOrEmpty(RazorScriptFile)) {
					object instance = CreateWebPageInstance();
					if (instance == null) {
						throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, "The webpage found at '{0}' was not created.", RazorScriptFile));
					}

					DotNetNukeWebPage webPage = instance as DotNetNukeWebPage;

					if (webPage == null) {
						throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, "The webpage at '{0}' must derive from DotNetNukeWebPage.", RazorScriptFile));
					}

					webPage.Context = HttpContext;
					webPage.VirtualPath = VirtualPathUtility.GetDirectory(RazorScriptFile);
					InitHelpers(webPage);

					StringWriter writer = new StringWriter();
					webPage.ExecutePageHierarchy(new WebPageContext(HttpContext, webPage, null), writer, webPage);

					Controls.Add(new LiteralControl(Server.HtmlDecode(writer.ToString())));
				}
			} catch (Exception ex) {
				Exceptions.ProcessModuleLoadException(this, ex);
			}


		}

	}
}