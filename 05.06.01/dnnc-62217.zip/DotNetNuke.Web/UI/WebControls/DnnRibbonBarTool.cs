using System;
using System.Collections.Generic;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//
using System.Threading;
using System.Web.UI;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Tabs;
using DotNetNuke.Security.Permissions;
using Microsoft.VisualBasic;

namespace DotNetNuke.Web.UI.WebControls
{

	[ParseChildren(true)]
	public class DnnRibbonBarTool : System.Web.UI.Control, IDnnRibbonBarTool
	{

		#region "Properties"

		private RibbonBarToolInfo _ToolInfo = new RibbonBarToolInfo();
		public virtual RibbonBarToolInfo ToolInfo
		{
			get
			{
				if ((ViewState["ToolInfo"] == null))
				{
					ViewState.Add("ToolInfo", new RibbonBarToolInfo());
				}
				return (RibbonBarToolInfo)ViewState["ToolInfo"];
			}
			set { ViewState["ToolInfo"] = value; }
		}

		public virtual string ToolName
		{
			get { return ToolInfo.ToolName; }
			set
			{
				if ((AllTools.ContainsKey(value)))
				{
					ToolInfo = AllTools[value];
				}
				else
				{
					throw new NotSupportedException("Tool not found [" + value + "]");
				}
			}
		}

		public virtual string NavigateUrl
		{
			get { return Utilities.GetViewStateAsString(ViewState["NavigateUrl"], Null.NullString); }
			set { ViewState["NavigateUrl"] = value; }
		}

		public virtual string ToolCssClass
		{
			get { return Utilities.GetViewStateAsString(ViewState["ToolCssClass"], Null.NullString); }
			set { ViewState["ToolCssClass"] = value; }
		}

		public virtual string ImageUrl
		{
			get { return Utilities.GetViewStateAsString(ViewState["ImageUrl"], Null.NullString); }
			set { ViewState["ImageUrl"] = value; }
		}

		public virtual string Text
		{
			get { return Utilities.GetViewStateAsString(ViewState["Text"], Null.NullString); }
			set { ViewState["Text"] = value; }
		}

		public virtual string ToolTip
		{
			get { return Utilities.GetViewStateAsString(ViewState["ToolTip"], Null.NullString); }
			set { ViewState["ToolTip"] = value; }
		}

		private DnnImageTextButton _DnnLinkButton = null;
		protected virtual DnnImageTextButton DnnLinkButton
		{
			get
			{
				if ((_DnnLinkButton == null))
				{
					_DnnLinkButton = new DnnImageTextButton();
					_DnnLinkButton.ID = this.ID + "_CPCommandBtn";
				}
				return _DnnLinkButton;
			}
		}

		private DnnImageTextLink _DnnLink = null;
		protected virtual DnnImageTextLink DnnLink
		{
			get
			{
				if ((_DnnLink == null))
				{
					_DnnLink = new DnnImageTextLink();
				}
				return _DnnLink;
			}
		}

		private IDictionary<string, RibbonBarToolInfo> _AllTools;
		protected virtual IDictionary<string, RibbonBarToolInfo> AllTools
		{
			get
			{
				if (((_AllTools == null)))
				{
					_AllTools = new Dictionary<string, RibbonBarToolInfo>();

					//Framework
					_AllTools.Add("PageSettings", new RibbonBarToolInfo("PageSettings", false, false, "", "", ""));
					_AllTools.Add("CopyPage", new RibbonBarToolInfo("CopyPage", false, false, "", "", ""));
					_AllTools.Add("DeletePage", new RibbonBarToolInfo("DeletePage", false, true, "", "", ""));
					_AllTools.Add("ImportPage", new RibbonBarToolInfo("ImportPage", false, false, "", "", ""));
					_AllTools.Add("ExportPage", new RibbonBarToolInfo("ExportPage", false, false, "", "", ""));
					_AllTools.Add("NewPage", new RibbonBarToolInfo("NewPage", false, false, "", "", ""));
					_AllTools.Add("CopyPermissionsToChildren", new RibbonBarToolInfo("CopyPermissionsToChildren", false, true, "", "", ""));
					_AllTools.Add("CopyDesignToChildren", new RibbonBarToolInfo("CopyDesignToChildren", false, true, "", "", ""));
					_AllTools.Add("Help", new RibbonBarToolInfo("Help", false, false, "_Blank", "", ""));

					//Modules on Tabs
					_AllTools.Add("Console", new RibbonBarToolInfo("Console", false, false, "", "Console", ""));
					_AllTools.Add("HostConsole", new RibbonBarToolInfo("HostConsole", true, false, "", "Console", ""));
					_AllTools.Add("Dashboard", new RibbonBarToolInfo("Dashboard", true, false, "", "Dashboard", ""));
					_AllTools.Add("Extensions", new RibbonBarToolInfo("Extensions", false, false, "", "Extensions", ""));
					_AllTools.Add("HostExtensions", new RibbonBarToolInfo("HostExtensions", true, false, "", "Extensions", ""));
					_AllTools.Add("FileManager", new RibbonBarToolInfo("FileManager", false, false, "", "File Manager", ""));
					_AllTools.Add("UploadFile", new RibbonBarToolInfo("UploadFile", false, false, "", "File Manager", "Edit"));
					_AllTools.Add("HostFileManager", new RibbonBarToolInfo("HostFileManager", true, false, "", "File Manager", ""));
					_AllTools.Add("HostUploadFile", new RibbonBarToolInfo("HostUploadFile", true, false, "", "File Manager", "Edit"));
					_AllTools.Add("GoogleAnalytics", new RibbonBarToolInfo("GoogleAnalytics", false, false, "", "GoogleAnalytics", ""));
					_AllTools.Add("HostSettings", new RibbonBarToolInfo("HostSettings", true, false, "", "Host Settings", ""));
					_AllTools.Add("Languages", new RibbonBarToolInfo("Languages", false, false, "", "Languages", ""));
					_AllTools.Add("Lists", new RibbonBarToolInfo("Lists", true, false, "", "Lists", ""));
					_AllTools.Add("EventLog", new RibbonBarToolInfo("EventLog", false, false, "", "Log Viewer", ""));
					_AllTools.Add("Marketplace", new RibbonBarToolInfo("Marketplace", true, false, "", "Marketplace", ""));
					_AllTools.Add("Newsletters", new RibbonBarToolInfo("Newsletters", false, false, "", "Newsletters", ""));
					_AllTools.Add("Sites", new RibbonBarToolInfo("Sites", true, false, "", "Portals", ""));
					_AllTools.Add("RecycleBin", new RibbonBarToolInfo("RecycleBin", false, false, "", "Recycle Bin", ""));
					_AllTools.Add("Scheduler", new RibbonBarToolInfo("Scheduler", true, false, "", "Scheduler", ""));
					_AllTools.Add("SearchAdmin", new RibbonBarToolInfo("SearchAdmin", true, false, "", "Search Admin", ""));
					_AllTools.Add("UserRoles", new RibbonBarToolInfo("UserRoles", false, false, "", "Security Roles", ""));
                    _AllTools.Add("NewRole", new RibbonBarToolInfo("NewRole", false, false, "", "Security Roles", "Edit"));
					_AllTools.Add("SiteLog", new RibbonBarToolInfo("SiteLog", false, false, "", "Site Log", ""));
					_AllTools.Add("SiteSettings", new RibbonBarToolInfo("SiteSettings", false, false, "", "Site Settings", ""));
					_AllTools.Add("SiteWizard", new RibbonBarToolInfo("SiteWizard", false, false, "", "Site Wizard", ""));
					_AllTools.Add("Skins", new RibbonBarToolInfo("Skins", false, false, "", "Skins", ""));
					_AllTools.Add("SQL", new RibbonBarToolInfo("SQL", true, false, "", "SQL", ""));
					_AllTools.Add("ManagePages", new RibbonBarToolInfo("ManagePages", false, false, "", "Tabs", ""));
					_AllTools.Add("Users", new RibbonBarToolInfo("Users", false, false, "", "User Accounts", ""));
					_AllTools.Add("NewUser", new RibbonBarToolInfo("NewUser", false, false, "", "User Accounts", "Edit"));
					_AllTools.Add("SuperUsers", new RibbonBarToolInfo("SuperUsers", true, false, "", "User Accounts", ""));
					_AllTools.Add("Vendors", new RibbonBarToolInfo("Vendors", false, false, "", "Vendors", ""));
					_AllTools.Add("HostVendors", new RibbonBarToolInfo("HostVendors", true, false, "", "Vendors", ""));
					_AllTools.Add("WhatsNew", new RibbonBarToolInfo("WhatsNew", true, false, "", "WhatsNew", ""));
				}

				return _AllTools;
			}
		}

		private DotNetNuke.Entities.Portals.PortalSettings PortalSettings
		{
			get { return DotNetNuke.Entities.Portals.PortalSettings.Current; }
		}

		#endregion

		#region "Events"

		protected override void CreateChildControls()
		{
			Controls.Clear();
			Controls.Add(DnnLinkButton);
			Controls.Add(DnnLink);
		}

		protected override void OnInit(System.EventArgs e)
		{
			EnsureChildControls();
			DnnLinkButton.Click += this.ControlPanelTool_OnClick;
		}

		protected override void OnPreRender(System.EventArgs e)
		{
			ProcessTool();
			Visible = (DnnLink.Visible == true || DnnLinkButton.Visible == true);
			base.OnPreRender(e);
		}

		public virtual void ControlPanelTool_OnClick(object sender, EventArgs e)
		{
			switch (ToolInfo.ToolName)
			{
				case "DeletePage":
					if ((HasToolPermissions("DeletePage")))
					{
						string url = DotNetNuke.Common.Globals.NavigateURL(PortalSettings.ActiveTab.TabID, "Tab", "action=delete");
						Page.Response.Redirect(url, true);
					}
					break;
				case "CopyPermissionsToChildren":
					if ((HasToolPermissions("CopyPermissionsToChildren")))
					{
						TabController.CopyPermissionsToChildren(PortalSettings.ActiveTab, PortalSettings.ActiveTab.TabPermissions);
						Page.Response.Redirect(Page.Request.RawUrl);
					}
					break;
				case "CopyDesignToChildren":
					if ((HasToolPermissions("CopyDesignToChildren")))
					{
						TabController.CopyDesignToChildren(PortalSettings.ActiveTab, PortalSettings.ActiveTab.SkinSrc, PortalSettings.ActiveTab.ContainerSrc);
						Page.Response.Redirect(Page.Request.RawUrl);
					}
					break;
			}
		}

		#endregion

		#region "Methods"

		protected virtual void ProcessTool()
		{
			DnnLink.Visible = false;
			DnnLinkButton.Visible = false;

			if ((!string.IsNullOrEmpty(ToolInfo.ToolName)))
			{
				if ((ToolInfo.UseButton))
				{
					DnnLinkButton.Visible = HasToolPermissions(ToolInfo.ToolName);
					DnnLinkButton.Enabled = EnableTool();
					DnnLinkButton.Localize = false;

					DnnLinkButton.ImageUrl = GetImageUrl();
					DnnLinkButton.CssClass = ToolCssClass;
					DnnLinkButton.DisabledCssClass = ToolCssClass + " rgIconDisabled";

					DnnLinkButton.Text = GetText();
					DnnLinkButton.ToolTip = GetToolTip();

					DnnLinkButton.ConfirmMessage = GetButtonConfirmMessage();
				}
				else
				{
					DnnLink.Visible = HasToolPermissions(ToolInfo.ToolName);
					DnnLink.Enabled = EnableTool();
					DnnLink.Localize = false;

					if ((DnnLink.Enabled))
					{
						DnnLink.NavigateUrl = BuildToolUrl();

						//can't find the page, disable it?
						if ((string.IsNullOrEmpty(DnnLink.NavigateUrl)))
						{
							DnnLink.Enabled = false;
						}
					}

					DnnLink.ImageUrl = GetImageUrl();
					DnnLink.CssClass = ToolCssClass;
					DnnLink.DisabledCssClass = ToolCssClass + " rgIconDisabled";

					DnnLink.Text = GetText();
					DnnLink.ToolTip = GetToolTip();
					DnnLink.Target = ToolInfo.LinkWindowTarget;
				}
			}
		}

		protected virtual bool EnableTool()
		{
			bool returnValue = true;

			switch (ToolInfo.ToolName)
			{
				case "DeletePage":
					if ((TabController.IsSpecialTab(TabController.CurrentPage.TabID, PortalSettings)))
					{
						returnValue = false;
					}
					break;
				case "CopyDesignToChildren":
				case "CopyPermissionsToChildren":
					returnValue = ActiveTabHasChildren();
					if ((returnValue == true && ToolInfo.ToolName == "CopyPermissionsToChildren"))
					{
						if ((PortalSettings.ActiveTab.IsSuperTab))
						{
							returnValue = false;
						}
					}
					break;
				//Case "Help"
				//	returnValue = Not String.IsNullOrEmpty(DotNetNuke.Entities.Host.Host.HelpURL)
				//Case Else
				//	If (AllTools.ContainsKey(toolName)) Then
				//		Dim friendlyName As String = AllTools(toolName).ModuleFriendlyName

				//		If (Not String.IsNullOrEmpty(friendlyName)) Then
				//			returnValue = True
				//			Dim moduleInfo As DotNetNuke.Entities.Modules.ModuleInfo = Nothing

				//			If (IsHostTool(toolName)) Then
				//				moduleInfo = GetInstalledModule(Null.NullInteger, friendlyName)
				//			Else
				//				moduleInfo = GetInstalledModule(PortalSettings.PortalId, friendlyName)
				//			End If

				//			If moduleInfo Is Nothing Then
				//				returnValue = False
				//			End If
				//		End If
				//	End If
			}

			return returnValue;
		}

		protected virtual bool HasToolPermissions(string toolName)
		{
			bool isHostTool = false;
			if ((ToolInfo.ToolName == toolName))
			{
				isHostTool = ToolInfo.IsHostTool;
			}
			else if ((AllTools.ContainsKey(toolName)))
			{
				isHostTool = AllTools[toolName].IsHostTool;
			}

			if ((isHostTool && !DotNetNuke.Entities.Users.UserController.GetCurrentUserInfo().IsSuperUser))
			{
				return false;
			}

			bool returnValue = true;
			switch (toolName)
			{
				case "PageSettings":
				case "CopyDesignToChildren":
				case "CopyPermissionsToChildren":
					returnValue = TabPermissionController.CanManagePage();

					if ((returnValue == true && toolName == "CopyPermissionsToChildren"))
					{
						if ((!DotNetNuke.Security.PortalSecurity.IsInRole("Administrators")))
						{
							returnValue = false;
						}
					}
					break;
				case "CopyPage":
					returnValue = TabPermissionController.CanCopyPage();
					break;
				case "DeletePage":
					returnValue = (TabPermissionController.CanDeletePage());
					break;
				case "ImportPage":
					returnValue = TabPermissionController.CanImportPage();
					break;
				case "ExportPage":
					returnValue = TabPermissionController.CanExportPage();
					break;
				case "NewPage":
					returnValue = TabPermissionController.CanAddPage();
					break;
				case "Help":
					returnValue = !string.IsNullOrEmpty(DotNetNuke.Entities.Host.Host.HelpURL);
					break;
				default:
					//if it has a module definition, look it up and check permissions
					//if it doesn't exist, assume no permission
					string friendlyName = "";
					if ((ToolInfo.ToolName == toolName))
					{
						friendlyName = ToolInfo.ModuleFriendlyName;
					}
					else if ((AllTools.ContainsKey(toolName)))
					{
						friendlyName = AllTools[toolName].ModuleFriendlyName;
					}

					if ((!string.IsNullOrEmpty(friendlyName)))
					{
						returnValue = false;
						DotNetNuke.Entities.Modules.ModuleInfo moduleInfo = null;

						if ((isHostTool))
						{
							moduleInfo = GetInstalledModule(Null.NullInteger, friendlyName);
						}
						else
						{
							moduleInfo = GetInstalledModule(PortalSettings.PortalId, friendlyName);
						}

						if ((moduleInfo != null))
						{
							returnValue = ModulePermissionController.CanViewModule(moduleInfo);

							//If (toolName = "UploadFile") Then
							//	If (Not DotNetNuke.Security.PortalSecurity.IsInRole("Administrators")) Then
							//		returnValue = False
							//	End If
							//End If
						}
					}
					break;
			}

			return returnValue;
		}

		protected virtual string BuildToolUrl()
		{
			if ((ToolInfo.IsHostTool && !DotNetNuke.Entities.Users.UserController.GetCurrentUserInfo().IsSuperUser))
			{
				return "javascript:void(0);";
			}

			if ((!string.IsNullOrEmpty(NavigateUrl)))
			{
				return NavigateUrl;
			}

			string returnValue = "javascript:void(0);";
			switch (ToolInfo.ToolName)
			{
				case "PageSettings":
					returnValue = DotNetNuke.Common.Globals.NavigateURL(PortalSettings.ActiveTab.TabID, "Tab", "action=edit");
					break; // TODO: might not be correct. Was : Exit Select

					break;
				case "CopyPage":
					returnValue = DotNetNuke.Common.Globals.NavigateURL(PortalSettings.ActiveTab.TabID, "Tab", "action=copy");
					break; // TODO: might not be correct. Was : Exit Select

					break;
				case "DeletePage":
					returnValue = DotNetNuke.Common.Globals.NavigateURL(PortalSettings.ActiveTab.TabID, "Tab", "action=delete");
					break; // TODO: might not be correct. Was : Exit Select

					break;
				case "ImportPage":
					returnValue = DotNetNuke.Common.Globals.NavigateURL(PortalSettings.ActiveTab.TabID, "ImportTab");
					break; // TODO: might not be correct. Was : Exit Select

					break;
				case "ExportPage":
					returnValue = DotNetNuke.Common.Globals.NavigateURL(PortalSettings.ActiveTab.TabID, "ExportTab");
					break; // TODO: might not be correct. Was : Exit Select

					break;
				case "NewPage":
					returnValue = DotNetNuke.Common.Globals.NavigateURL("Tab");
					break; // TODO: might not be correct. Was : Exit Select

					break;
				case "Help":
					if (!string.IsNullOrEmpty(DotNetNuke.Entities.Host.Host.HelpURL))
					{
						returnValue = DotNetNuke.Common.Globals.FormatHelpUrl(DotNetNuke.Entities.Host.Host.HelpURL, PortalSettings, "");
					}
					break; // TODO: might not be correct. Was : Exit Select

					break;
				default:
					//if it has a module definition, look it up and check permissions
					string friendlyName = ToolInfo.ModuleFriendlyName;
					string controlKey = ToolInfo.ControlKey;

					if ((!string.IsNullOrEmpty(friendlyName)))
					{
						List<string> additionalParams = new List<string>();
						if ((ToolInfo.ToolName == "UploadFile" | ToolInfo.ToolName == "HostUploadFile"))
						{
							additionalParams.Add("ftype=File");
							additionalParams.Add("rtab=" + PortalSettings.ActiveTab.TabID.ToString());
						}

						if ((ToolInfo.IsHostTool))
						{
							returnValue = GetTabURL(Null.NullInteger, friendlyName, controlKey, additionalParams);
						}
						else
						{
							returnValue = GetTabURL(PortalSettings.PortalId, friendlyName, controlKey, additionalParams);
						}
					}
					break; // TODO: might not be correct. Was : Exit Select

					break;
			}

			return returnValue;
		}

		protected virtual string GetText()
		{
			if ((string.IsNullOrEmpty(Text)))
			{
				return GetString(string.Format("Tool.{0}.Text", ToolInfo.ToolName));
			}
			else
			{
				return Text;
			}
		}

		protected virtual string GetToolTip()
		{
			if ((ToolInfo.ToolName == "DeletePage"))
			{
				if ((TabController.IsSpecialTab(TabController.CurrentPage.TabID, PortalSettings)))
				{
					return GetString("Tool.DeletePage.Special.ToolTip");
				}
			}

			if ((string.IsNullOrEmpty(Text)))
			{
				string tip = GetString(string.Format("Tool.{0}.ToolTip", ToolInfo.ToolName));
				if ((string.IsNullOrEmpty(tip)))
				{
					tip = GetString(string.Format("Tool.{0}.Text", ToolInfo.ToolName));
				}
				return tip;
			}
			else
			{
				return ToolTip;
			}
		}

		protected virtual string GetImageUrl()
		{
			if ((!string.IsNullOrEmpty(ImageUrl)))
			{
				return ImageUrl;
			}

			return Page.ResolveUrl(string.Format("~/admin/controlpanel/ribbonimages/{0}.gif", ToolInfo.ToolName));
		}

		protected virtual string GetTabURL(int portalID, string friendlyName, string controlKey, List<string> additionalParams)
		{
			string strURL = string.Empty;

			if (((additionalParams == null)))
			{
				additionalParams = new List<string>();
			}

			DotNetNuke.Entities.Modules.ModuleController moduleCtrl = new DotNetNuke.Entities.Modules.ModuleController();
			DotNetNuke.Entities.Modules.ModuleInfo moduleInfo = moduleCtrl.GetModuleByDefinition(portalID, friendlyName);

			if (((moduleInfo != null)))
			{
				bool isHostPage = (portalID == Null.NullInteger);
				if ((!string.IsNullOrEmpty(controlKey)))
				{
					additionalParams.Insert(0, "mid=" + moduleInfo.ModuleID.ToString());
				}

			    string currentCulture = Thread.CurrentThread.CurrentCulture.Name;
				strURL = DotNetNuke.Common.Globals.NavigateURL(moduleInfo.TabID, isHostPage, PortalSettings, controlKey, currentCulture, additionalParams.ToArray());
				//If (portalID = Null.NullInteger) Then
				//	If (String.IsNullOrEmpty(controlKey)) Then
				//		strURL = NavigateURL(moduleInfo.TabID, True, PortalSettings, "", additionalParams.ToArray())
				//	Else
				//		additionalParams.Add("mid=" + moduleInfo.ModuleID.ToString())
				//		strURL = NavigateURL(moduleInfo.TabID, True, PortalSettings, controlKey, additionalParams.ToArray())
				//	End If
				//Else
				//	If (String.IsNullOrEmpty(controlKey)) Then
				//		strURL = NavigateURL(moduleInfo.TabID)
				//	Else
				//		additionalParams.Add("mid=" + moduleInfo.ModuleID.ToString())
				//		strURL = NavigateURL(moduleInfo.TabID, controlKey, additionalParams.ToArray())
				//	End If
				//End If
			}

			return strURL;
		}

		protected virtual bool ActiveTabHasChildren()
		{
			List<TabInfo> children = DotNetNuke.Entities.Tabs.TabController.GetTabsByParent(PortalSettings.ActiveTab.TabID, PortalSettings.ActiveTab.PortalID);

			if (((children == null) || children.Count < 1))
			{
				return false;
			}

			return true;
		}

		protected virtual string GetButtonConfirmMessage()
		{
			if ((ToolInfo.ToolName == "DeletePage"))
			{
				return GetString("Tool.DeletePage.Confirm");
			}
			else if ((ToolInfo.ToolName == "CopyPermissionsToChildren"))
			{
				if ((DotNetNuke.Security.PortalSecurity.IsInRole("Administrators")))
				{
					return GetString("Tool.CopyPermissionsToChildren.Confirm");
				}
				else
				{
					return GetString("Tool.CopyPermissionsToChildrenPageEditor.Confirm");
				}
			}
			else if ((ToolInfo.ToolName == "CopyDesignToChildren"))
			{
				if ((DotNetNuke.Security.PortalSecurity.IsInRole("Administrators")))
				{
					return GetString("Tool.CopyDesignToChildren.Confirm");
				}
				else
				{
					return GetString("Tool.CopyDesignToChildrenPageEditor.Confirm");
				}
			}

			return string.Empty;
		}

		protected virtual string GetString(string key)
		{
			return Utilities.GetLocalizedStringFromParent(key, this);
		}

		private DotNetNuke.Entities.Modules.ModuleInfo GetInstalledModule(int portalID, string friendlyName)
		{
			DotNetNuke.Entities.Modules.ModuleController moduleCtrl = new DotNetNuke.Entities.Modules.ModuleController();
			return moduleCtrl.GetModuleByDefinition(portalID, friendlyName);
		}

		#endregion

	}

}
