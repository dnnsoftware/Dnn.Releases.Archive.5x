//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Web;
using System.Xml;
using System.Xml.Serialization;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Data;
using DotNetNuke.Entities.Modules.Definitions;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Tabs;
using DotNetNuke.Entities.Users;
using DotNetNuke.Security.Permissions;
using DotNetNuke.Security.Roles;
using DotNetNuke.Services.EventQueue;
using DotNetNuke.Entities.Content;
using DotNetNuke.Entities.Content.Taxonomy;
using DotNetNuke.Services.Localization;
using DotNetNuke.Services.OutputCache;
using DotNetNuke.Services.ModuleCache;
using DotNetNuke.Services.Log.EventLog;
using DotNetNuke.Common;
using DotNetNuke.Services.Exceptions;

namespace DotNetNuke.Entities.Modules
{
    public class ModuleController
    {
        private static DataProvider dataProvider = DataProvider.Instance();
        #region "Private Methods"

        private void AddModuleInternal(ModuleInfo objModule)
        {
            Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
            // add module
            if (Null.IsNull(objModule.ModuleID))
            {
                IContentTypeController typeController = new ContentTypeController();
                ContentType contentType = (from t in typeController.GetContentTypes()
                                           where t.Type == "Module"
                                           select t).SingleOrDefault();

                IContentController contentController = new ContentController();
                objModule.Content = objModule.ModuleTitle;
                objModule.ContentTypeId = contentType.ContentTypeId;
                objModule.Indexed = false;
                int contentItemID = contentController.AddContentItem(objModule);

                //Add Module
                objModule.ModuleID = dataProvider.AddModule(contentItemID, objModule.PortalID, objModule.ModuleDefID, objModule.AllTabs, objModule.StartDate, objModule.EndDate, objModule.InheritViewPermissions, objModule.IsDeleted, UserController.GetCurrentUserInfo().UserID);

                //Now we have the ModuleID - update the contentItem
                contentController.UpdateContentItem(objModule);

                objEventLog.AddLog(objModule, PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, "", Services.Log.EventLog.EventLogController.EventLogType.MODULE_CREATED);

                // set module permissions
                ModulePermissionController.SaveModulePermissions(objModule);
            }

            //Save ModuleSettings
            UpdateModuleSettings(objModule);
        }

        /// <summary>
        /// Adds a Module permission to the ModuleInfo parameter.
        /// </summary>
        /// <param name="objModule">The module to add a permission for</param>
        /// <param name="portalId"></param>
        /// <param name="roleName"></param>
        /// <param name="permission"></param>
        /// <param name="permissionKey"></param>
        /// <remarks></remarks>
        /// <history>
        ///    [vnguyen]   06/10/2010   Created
        /// </history>
        private void AddModulePermission(ref ModuleInfo objModule, int portalId, string roleName, PermissionInfo permission, string permissionKey)
        {
            RoleInfo role = default(RoleInfo);
            ModulePermissionInfo modulePermission = default(ModulePermissionInfo);
            ModulePermissionInfo perm = default(ModulePermissionInfo);

            perm = objModule.ModulePermissions.Where(tp => tp.RoleName == roleName && tp.PermissionKey == permissionKey).SingleOrDefault();
            if (permission != null && perm == null)
            {
                perm = objModule.ModulePermissions.Where(tp => tp.RoleName == roleName && tp.PermissionKey == permissionKey).SingleOrDefault();
                modulePermission = new ModulePermissionInfo(permission);
                role = new RoleController().GetRoleByName(portalId, roleName);
                if (role != null)
                {
                    modulePermission.RoleID = role.RoleID;
                    modulePermission.AllowAccess = true;

                    objModule.ModulePermissions.Add(modulePermission);
                }
            }
        }


        /// -----------------------------------------------------------------------------
        /// <summary>
        /// Localizes a Module
        /// </summary>
        /// <param name="sourceModule"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        /// <history>
        ///    [vnguyen]   06/10/2010   Modified: Removed Copying of permissions, Adding only View and Edit permissions
        /// </history>
        /// -----------------------------------------------------------------------------
        private int LocalizeModuleInternal(ModuleInfo sourceModule)
        {
            int moduleId = Null.NullInteger;

            if (sourceModule != null)
            {
                // clone the module object ( to avoid creating an object reference to the data cache )
                ModuleInfo newModule = sourceModule.Clone();
                newModule.ModuleID = Null.NullInteger;
                //reset the module id

                string translatorRoles = PortalController.GetPortalSetting(string.Format("DefaultTranslatorRoles-{0}", sourceModule.CultureCode), sourceModule.PortalID, "");

                //Add the default translators for this language, view and edit permissions
                PermissionController permissionCtrl = new PermissionController();
                ArrayList viewPermissionsList = permissionCtrl.GetPermissionByCodeAndKey("SYSTEM_MODULE_DEFINITION", "VIEW");
                ArrayList editPermissionsList = permissionCtrl.GetPermissionByCodeAndKey("SYSTEM_MODULE_DEFINITION", "EDIT");
                PermissionInfo viewPermisison = null;
                PermissionInfo editPermisison = null;

                //View
                if (viewPermissionsList != null && viewPermissionsList.Count > 0)
                {
                    viewPermisison = (PermissionInfo)viewPermissionsList[0];
                }

                //Edit
                if (editPermissionsList != null && editPermissionsList.Count > 0)
                {
                    editPermisison = (PermissionInfo)editPermissionsList[0];
                }

                if (viewPermisison != null || editPermisison != null)
                {
                    foreach (string translatorRole in translatorRoles.Split(';'))
                    {
                        AddModulePermission(ref newModule, sourceModule.PortalID, translatorRole, viewPermisison, "VIEW");
                        AddModulePermission(ref newModule, sourceModule.PortalID, translatorRole, editPermisison, "EDIT");
                    }
                }

                //Add Module
                AddModuleInternal(newModule);

                // update tabmodule
                dataProvider.UpdateTabModule(newModule.TabModuleID, newModule.TabID, newModule.ModuleID, newModule.ModuleTitle, newModule.Header, newModule.Footer, newModule.ModuleOrder, newModule.PaneName, newModule.CacheTime, newModule.CacheMethod,
                newModule.Alignment, newModule.Color, newModule.Border, newModule.IconFile, (int)newModule.Visibility, newModule.ContainerSrc, newModule.DisplayTitle, newModule.DisplayPrint, newModule.DisplaySyndicate, newModule.IsWebSlice,
                newModule.WebSliceTitle, newModule.WebSliceExpiryDate, newModule.WebSliceTTL, newModule.VersionGuid, newModule.DefaultLanguageGuid, newModule.LocalizedVersionGuid, newModule.CultureCode, UserController.GetCurrentUserInfo().UserID);

                if (!string.IsNullOrEmpty(newModule.DesktopModule.BusinessControllerClass))
                {
                    try
                    {
                        object objObject = Framework.Reflection.CreateObject(newModule.DesktopModule.BusinessControllerClass, newModule.DesktopModule.BusinessControllerClass);
                        IPortable portableModule = objObject as IPortable;
                        if (portableModule != null)
                        {
                            string Content = portableModule.ExportModule(sourceModule.ModuleID);
                            if (!string.IsNullOrEmpty(Content))
                            {
                                portableModule.ImportModule(newModule.ModuleID, Content, newModule.DesktopModule.Version, UserController.GetCurrentUserInfo().UserID);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Exceptions.LogException(ex);
                    }
                }

                moduleId = newModule.ModuleID;

                //Clear Caches
                ClearCache(newModule.TabID);
                ClearCache(sourceModule.TabID);
            }

            return moduleId;
        }

        private void UpdateModuleSettings(ModuleInfo updatedModule)
        {
            string sKey = null;
            foreach (string sKey_loopVariable in updatedModule.ModuleSettings.Keys)
            {
                sKey = sKey_loopVariable;
                UpdateModuleSettingInternal(updatedModule.ModuleID, sKey, Convert.ToString(updatedModule.ModuleSettings[sKey]), false);
            }
            UpdateTabModuleVersionsByModuleID(updatedModule.ModuleID);
        }

        public void UpdateModuleSettingInternal(int ModuleId, string SettingName, string SettingValue, bool updateVersion)
        {
            Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
            Services.Log.EventLog.LogInfo objEventLogInfo = new Services.Log.EventLog.LogInfo();
            objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("ModuleId", ModuleId.ToString()));
            objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("SettingName", SettingName.ToString()));
            objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("SettingValue", SettingValue.ToString()));

            IDataReader dr = null;
            try
            {
                dr = dataProvider.GetModuleSetting(ModuleId, SettingName);
                if (dr.Read())
                {
                    dataProvider.UpdateModuleSetting(ModuleId, SettingName, SettingValue, UserController.GetCurrentUserInfo().UserID);
                    objEventLogInfo.LogTypeKey = EventLogController.EventLogType.MODULE_SETTING_UPDATED.ToString();
                    objEventLog.AddLog(objEventLogInfo);
                }
                else
                {
                    dataProvider.AddModuleSetting(ModuleId, SettingName, SettingValue, UserController.GetCurrentUserInfo().UserID);
                    objEventLogInfo.LogTypeKey = EventLogController.EventLogType.MODULE_SETTING_CREATED.ToString();
                    objEventLog.AddLog(objEventLogInfo);
                }

                if (updateVersion)
                {
                    UpdateTabModuleVersionsByModuleID(ModuleId);
                }

            }
            catch (Exception ex)
            {
                Exceptions.LogException(ex);
            }
            finally
            {
                // Ensure DataReader is closed
                CBO.CloseDataReader(dr, true);
            }

            DataCache.RemoveCache("GetModuleSettings" + ModuleId.ToString());

        }


        private void UpdateTabModuleSettings(ModuleInfo updatedTabModule)
        {
            foreach (string sKey in updatedTabModule.TabModuleSettings.Keys)
            {
                UpdateTabModuleSetting(updatedTabModule.TabModuleID, sKey, Convert.ToString(updatedTabModule.TabModuleSettings[sKey]));
            }
        }

        private void UpdateTabModuleVersion(int tabModuleId)
        {
            dataProvider.UpdateTabModuleVersion(tabModuleId, Guid.NewGuid());
        }

        /// <summary>
        /// Updates version guids of all tabModules link to the particular moduleID
        /// </summary>
        /// <param name="moduleID"></param>
        /// <remarks></remarks>
        private void UpdateTabModuleVersionsByModuleID(int moduleID)
        {
            // Update the version guid of each TabModule linked to the updated module
            foreach (ModuleInfo modInfo in GetAllTabsModulesByModuleID(moduleID))
            {
                ClearCache(modInfo.TabID);
            }
            dataProvider.UpdateTabModuleVersionByModule(moduleID);
        }

        #endregion
        private static void AddContent(XmlNode nodeModule, ModuleInfo objModule)
        {
            XmlAttribute xmlattr;
            if (!String.IsNullOrEmpty(objModule.DesktopModule.BusinessControllerClass) && objModule.DesktopModule.IsPortable)
            {
                try
                {
                    object objObject = Framework.Reflection.CreateObject(objModule.DesktopModule.BusinessControllerClass, objModule.DesktopModule.BusinessControllerClass);
                    if (objObject is IPortable)
                    {
                        string Content = Convert.ToString(((IPortable)objObject).ExportModule(objModule.ModuleID));
                        if (!String.IsNullOrEmpty(Content))
                        {
                            XmlNode newnode = nodeModule.OwnerDocument.CreateElement("content");
                            xmlattr = nodeModule.OwnerDocument.CreateAttribute("type");
                            xmlattr.Value = DotNetNuke.Common.Globals.CleanName(objModule.DesktopModule.ModuleName);
                            newnode.Attributes.Append(xmlattr);
                            xmlattr = nodeModule.OwnerDocument.CreateAttribute("version");
                            xmlattr.Value = objModule.DesktopModule.Version;
                            newnode.Attributes.Append(xmlattr);
                            Content = HttpContext.Current.Server.HtmlEncode(Content);
                            newnode.InnerXml = XmlUtils.XMLEncode(Content);
                            nodeModule.AppendChild(newnode);
                        }
                    }
                }
                catch
                {
                }
            }
        }
        private static bool CheckIsInstance(int templateModuleID, Hashtable hModules)
        {
            bool IsInstance = false;
            if (templateModuleID > 0)
            {
                if (hModules[templateModuleID] != null)
                {
                    IsInstance = true;
                }
            }
            return IsInstance;
        }

        private static ModuleInfo DeserializeModule(XmlNode nodeModule, XmlNode nodePane, int PortalId, int TabId, int ModuleDefId)
        {
            ModuleInfo objModule = new ModuleInfo();
            objModule.PortalID = PortalId;
            objModule.TabID = TabId;
            objModule.ModuleOrder = -1;
            objModule.ModuleTitle = XmlUtils.GetNodeValue(nodeModule.CreateNavigator(), "title");
            objModule.PaneName = XmlUtils.GetNodeValue(nodePane.CreateNavigator(), "name");
            objModule.ModuleDefID = ModuleDefId;
            objModule.CacheTime = XmlUtils.GetNodeValueInt(nodeModule, "cachetime");
            objModule.CacheMethod = XmlUtils.GetNodeValue(nodeModule.CreateNavigator(), "cachemethod");
            objModule.Alignment = XmlUtils.GetNodeValue(nodeModule.CreateNavigator(), "alignment");
            objModule.IconFile = DotNetNuke.Common.Globals.ImportFile(PortalId, XmlUtils.GetNodeValue(nodeModule.CreateNavigator(), "iconfile"));
            objModule.AllTabs = XmlUtils.GetNodeValueBoolean(nodeModule, "alltabs");
            switch (XmlUtils.GetNodeValue(nodeModule.CreateNavigator(), "visibility"))
            {
                case "Maximized":
                    objModule.Visibility = VisibilityState.Maximized;
                    break;
                case "Minimized":
                    objModule.Visibility = VisibilityState.Minimized;
                    break;
                case "None":
                    objModule.Visibility = VisibilityState.None;
                    break;
            }
            objModule.Color = XmlUtils.GetNodeValue(nodeModule, "color", "");
            objModule.Border = XmlUtils.GetNodeValue(nodeModule, "border", "");
            objModule.Header = XmlUtils.GetNodeValue(nodeModule, "header", "");
            objModule.Footer = XmlUtils.GetNodeValue(nodeModule, "footer", "");
            objModule.InheritViewPermissions = XmlUtils.GetNodeValueBoolean(nodeModule, "inheritviewpermissions", false);
            objModule.StartDate = XmlUtils.GetNodeValueDate(nodeModule, "startdate", Null.NullDate);
            objModule.EndDate = XmlUtils.GetNodeValueDate(nodeModule, "enddate", Null.NullDate);
            if (!String.IsNullOrEmpty(XmlUtils.GetNodeValue(nodeModule, "containersrc", "")))
            {
                objModule.ContainerSrc = XmlUtils.GetNodeValue(nodeModule, "containersrc", "");
            }
            objModule.DisplayTitle = XmlUtils.GetNodeValueBoolean(nodeModule, "displaytitle", true);
            objModule.DisplayPrint = XmlUtils.GetNodeValueBoolean(nodeModule, "displayprint", true);
            objModule.DisplaySyndicate = XmlUtils.GetNodeValueBoolean(nodeModule, "displaysyndicate", false);
            objModule.IsWebSlice = XmlUtils.GetNodeValueBoolean(nodeModule, "iswebslice", false);
            if (objModule.IsWebSlice)
            {
                objModule.WebSliceTitle = XmlUtils.GetNodeValue(nodeModule, "webslicetitle", objModule.ModuleTitle);
                objModule.WebSliceExpiryDate = XmlUtils.GetNodeValueDate(nodeModule, "websliceexpirydate", objModule.EndDate);
                objModule.WebSliceTTL = XmlUtils.GetNodeValueInt(nodeModule, "webslicettl", objModule.CacheTime / 60);
            }
            return objModule;
        }
        private static void DeserializeModulePermissions(XmlNodeList nodeModulePermissions, int PortalId, int TabId, ModuleInfo objModule)
        {
            RoleController objRoleController = new RoleController();
            PermissionController objPermissionController = new PermissionController();
            PermissionInfo objPermission;
            int PermissionID;
            ArrayList arrPermissions;
            int i;
            foreach (XmlNode node in nodeModulePermissions)
            {
                string PermissionKey = XmlUtils.GetNodeValue(node.CreateNavigator(), "permissionkey");
                string PermissionCode = XmlUtils.GetNodeValue(node.CreateNavigator(), "permissioncode");
                string RoleName = XmlUtils.GetNodeValue(node.CreateNavigator(), "rolename");
                bool AllowAccess = XmlUtils.GetNodeValueBoolean(node, "allowaccess");
                int RoleID = int.MinValue;
                switch (RoleName)
                {
                    case DotNetNuke.Common.Globals.glbRoleAllUsersName:
                        RoleID = Convert.ToInt32(DotNetNuke.Common.Globals.glbRoleAllUsers);
                        break;
                    case Common.Globals.glbRoleUnauthUserName:
                        RoleID = Convert.ToInt32(DotNetNuke.Common.Globals.glbRoleUnauthUser);
                        break;
                    default:
                        RoleInfo objRole = objRoleController.GetRoleByName(PortalId, RoleName);
                        if (objRole != null)
                        {
                            RoleID = objRole.RoleID;
                        }
                        break;
                }
                if (RoleID != int.MinValue)
                {
                    PermissionID = -1;
                    arrPermissions = objPermissionController.GetPermissionByCodeAndKey(PermissionCode, PermissionKey);
                    for (i = 0; i <= arrPermissions.Count - 1; i++)
                    {
                        objPermission = (PermissionInfo)arrPermissions[i];
                        PermissionID = objPermission.PermissionID;
                    }
                    if (PermissionID != -1)
                    {
                        ModulePermissionInfo objModulePermission = new ModulePermissionInfo();
                        objModulePermission.ModuleID = objModule.ModuleID;
                        objModulePermission.PermissionID = PermissionID;
                        objModulePermission.RoleID = RoleID;
                        objModulePermission.AllowAccess = Convert.ToBoolean(XmlUtils.GetNodeValue(node.CreateNavigator(), "allowaccess"));
                        objModule.ModulePermissions.Add(objModulePermission);
                    }
                }
            }
        }
        private static bool FindModule(XmlNode nodeModule, int TabId, PortalTemplateModuleAction mergeTabs)
        {
            ModuleController objModules = new ModuleController();
            Dictionary<int, ModuleInfo> dicModules = objModules.GetTabModules(TabId);
            ModuleInfo objModule;
            bool moduleFound = false;
            string modTitle = XmlUtils.GetNodeValue(nodeModule.CreateNavigator(), "title");
            if (mergeTabs == PortalTemplateModuleAction.Merge)
            {
                foreach (KeyValuePair<int, ModuleInfo> kvp in dicModules)
                {
                    objModule = kvp.Value;
                    if (modTitle == objModule.ModuleTitle)
                    {
                        moduleFound = true;
                        break;
                    }
                }
            }
            return moduleFound;
        }
        private static void GetModuleContent(XmlNode nodeModule, int ModuleId, int TabId, int PortalId)
        {
            ModuleController objModules = new ModuleController();
            ModuleInfo objModule = objModules.GetModule(ModuleId, TabId, true);
            string strVersion = nodeModule.SelectSingleNode("content").Attributes["version"].Value;
            string strType = nodeModule.SelectSingleNode("content").Attributes["type"].Value;
            string strcontent = nodeModule.SelectSingleNode("content").InnerXml;
            strcontent = strcontent.Substring(9, strcontent.Length - 12);
            if (!String.IsNullOrEmpty(objModule.DesktopModule.BusinessControllerClass) && !String.IsNullOrEmpty(strcontent))
            {
                PortalInfo objportal;
                PortalController objportals = new PortalController();
                objportal = objportals.GetPortal(PortalId);
                if (objModule.DesktopModule.SupportedFeatures == Null.NullInteger)
                {
                    EventMessageProcessor.CreateImportModuleMessage(objModule, strcontent, strVersion, objportal.AdministratorId);
                }
                else
                {
                    strcontent = HttpContext.Current.Server.HtmlDecode(strcontent);
                    if (objModule.DesktopModule.IsPortable)
                    {
                        try
                        {
                            object objObject = Framework.Reflection.CreateObject(objModule.DesktopModule.BusinessControllerClass, objModule.DesktopModule.BusinessControllerClass);
                            if (objObject is IPortable)
                            {
                                ((IPortable)objObject).ImportModule(objModule.ModuleID, strcontent, strVersion, objportal.AdministratorId);
                            }
                        }
                        catch
                        {
                            EventMessageProcessor.CreateImportModuleMessage(objModule, strcontent, strVersion, objportal.AdministratorId);
                        }
                    }
                }
            }
        }
        private static object GetTabModulesCallBack(CacheItemArgs cacheItemArgs)
        {
            int tabID = (int)cacheItemArgs.ParamList[0];
            return CBO.FillDictionary<int, ModuleInfo>("ModuleID", dataProvider.GetTabModules(tabID), new Dictionary<int, ModuleInfo>());
        }
        private static ModuleDefinitionInfo GetModuleDefinition(XmlNode nodeModule)
        {
            ModuleDefinitionInfo objModuleDefinition = null;
            DesktopModuleInfo objDesktopModule = DesktopModuleController.GetDesktopModuleByModuleName(XmlUtils.GetNodeValue(nodeModule.CreateNavigator(), "definition"), Null.NullInteger);
            if (objDesktopModule != null)
            {
                string friendlyName = XmlUtils.GetNodeValue(nodeModule.CreateNavigator(), "moduledefinition");
                if (string.IsNullOrEmpty(friendlyName))
                {
                    foreach (ModuleDefinitionInfo md in ModuleDefinitionController.GetModuleDefinitionsByDesktopModuleID(objDesktopModule.DesktopModuleID).Values)
                    {
                        break;
                    }
                }
                else
                {
                    objModuleDefinition = ModuleDefinitionController.GetModuleDefinitionByFriendlyName(friendlyName, objDesktopModule.DesktopModuleID);
                }
            }
            return objModuleDefinition;
        }
        private static void DeserializeModuleSettings(XmlNodeList nodeModuleSettings, ModuleInfo objModule)
        {
            string sKey;
            string sValue;
            foreach (XmlNode oModuleSettingNode in nodeModuleSettings)
            {
                sKey = XmlUtils.GetNodeValue(oModuleSettingNode.CreateNavigator(), "settingname");
                sValue = XmlUtils.GetNodeValue(oModuleSettingNode.CreateNavigator(), "settingvalue");
                objModule.ModuleSettings[sKey] = sValue;
            }
        }
        private static void DeserializeTabModuleSettings(XmlNodeList nodeTabModuleSettings, ModuleInfo objModule)
        {
            string sKey;
            string sValue;
            ModuleController mc = new ModuleController();
            foreach (XmlNode oTabModuleSettingNode in nodeTabModuleSettings)
            {
                sKey = XmlUtils.GetNodeValue(oTabModuleSettingNode.CreateNavigator(), "settingname");
                sValue = XmlUtils.GetNodeValue(oTabModuleSettingNode.CreateNavigator(), "settingvalue");
                objModule.TabModuleSettings[sKey] = sValue;
            }
        }
        public static void DeserializeModule(XmlNode nodeModule, XmlNode nodePane, int PortalId, int TabId, PortalTemplateModuleAction mergeTabs, Hashtable hModules)
        {
            ModuleController objModules = new ModuleController();
            ModuleDefinitionInfo objModuleDefinition = GetModuleDefinition(nodeModule);
            ModuleInfo objModule;
            int intModuleId;
            int templateModuleID = XmlUtils.GetNodeValueInt(nodeModule, "moduleID");
            bool IsInstance = CheckIsInstance(templateModuleID, hModules);
            if (objModuleDefinition != null)
            {
                if (!FindModule(nodeModule, TabId, mergeTabs))
                {
                    objModule = DeserializeModule(nodeModule, nodePane, PortalId, TabId, objModuleDefinition.ModuleDefID);
                    XmlNodeList nodeModuleSettings = nodeModule.SelectNodes("modulesettings/modulesetting");
                    DeserializeModuleSettings(nodeModuleSettings, objModule);
                    XmlNodeList nodeTabModuleSettings = nodeModule.SelectNodes("tabmodulesettings/tabmodulesetting");
                    DeserializeTabModuleSettings(nodeTabModuleSettings, objModule);
                    if (!IsInstance)
                    {
                        intModuleId = objModules.AddModule(objModule);
                        if (templateModuleID > 0)
                        {
                            hModules.Add(templateModuleID, intModuleId);
                        }
                    }
                    else
                    {
                        objModule.ModuleID = Convert.ToInt32(hModules[templateModuleID]);
                        intModuleId = objModules.AddModule(objModule);
                    }
                    if (!String.IsNullOrEmpty(XmlUtils.GetNodeValue(nodeModule.CreateNavigator(), "content")) && !IsInstance)
                    {
                        GetModuleContent(nodeModule, intModuleId, TabId, PortalId);
                    }
                    if (!IsInstance)
                    {
                        XmlNodeList nodeModulePermissions = nodeModule.SelectNodes("modulepermissions/permission");
                        DeserializeModulePermissions(nodeModulePermissions, PortalId, TabId, objModule);
                        ModulePermissionController.SaveModulePermissions(objModule);
                    }
                }
            }
        }
        public static XmlNode SerializeModule(XmlDocument xmlModule, ModuleInfo objModule, bool includeContent)
        {
            XmlSerializer xserModules = new XmlSerializer(typeof(ModuleInfo));
            XmlNode nodeModule;
            XmlNode nodeDefinition;
            XmlNode newnode;
            ModuleController objmodules = new ModuleController();
            StringWriter sw = new StringWriter();
            xserModules.Serialize(sw, objModule);
            xmlModule.LoadXml(sw.GetStringBuilder().ToString());
            nodeModule = xmlModule.SelectSingleNode("module");
            nodeModule.Attributes.Remove(nodeModule.Attributes["xmlns:xsd"]);
            nodeModule.Attributes.Remove(nodeModule.Attributes["xmlns:xsi"]);
            nodeModule.RemoveChild(nodeModule.SelectSingleNode("portalid"));
            nodeModule.RemoveChild(nodeModule.SelectSingleNode("tabid"));
            nodeModule.RemoveChild(nodeModule.SelectSingleNode("tabmoduleid"));
            nodeModule.RemoveChild(nodeModule.SelectSingleNode("moduleorder"));
            nodeModule.RemoveChild(nodeModule.SelectSingleNode("panename"));
            nodeModule.RemoveChild(nodeModule.SelectSingleNode("isdeleted"));
            nodeModule.RemoveChild(nodeModule.SelectSingleNode("uniqueId"));
            nodeModule.RemoveChild(nodeModule.SelectSingleNode("versionGuid"));
            nodeModule.RemoveChild(nodeModule.SelectSingleNode("defaultLanguageGuid"));
            nodeModule.RemoveChild(nodeModule.SelectSingleNode("localizedVersionGuid"));
            nodeModule.RemoveChild(nodeModule.SelectSingleNode("cultureCode"));

            foreach (XmlNode nodePermission in nodeModule.SelectNodes("modulepermissions/permission"))
            {
                nodePermission.RemoveChild(nodePermission.SelectSingleNode("modulepermissionid"));
                nodePermission.RemoveChild(nodePermission.SelectSingleNode("permissionid"));
                nodePermission.RemoveChild(nodePermission.SelectSingleNode("moduleid"));
                nodePermission.RemoveChild(nodePermission.SelectSingleNode("roleid"));
                nodePermission.RemoveChild(nodePermission.SelectSingleNode("userid"));
                nodePermission.RemoveChild(nodePermission.SelectSingleNode("username"));
                nodePermission.RemoveChild(nodePermission.SelectSingleNode("displayname"));
            }
            if (includeContent)
            {
                AddContent(nodeModule, objModule);
            }
            XmlUtils.SerializeHashtable(objModule.ModuleSettings, xmlModule, nodeModule, "modulesetting", "settingname", "settingvalue");
            XmlUtils.SerializeHashtable(objModule.TabModuleSettings, xmlModule, nodeModule, "tabmodulesetting", "settingname", "settingvalue");
            newnode = xmlModule.CreateElement("definition");
            ModuleDefinitionInfo objModuleDef = ModuleDefinitionController.GetModuleDefinitionByID(objModule.ModuleDefID);
            newnode.InnerText = DesktopModuleController.GetDesktopModule(objModuleDef.DesktopModuleID, objModule.PortalID).ModuleName;
            nodeModule.AppendChild(newnode);
            nodeDefinition = xmlModule.CreateElement("moduledefinition");
            nodeDefinition.InnerText = objModuleDef.FriendlyName;
            nodeModule.AppendChild(nodeDefinition);
            return nodeModule;
        }
        public static void SynchronizeModule(int moduleID)
        {
            ModuleController objModules = new ModuleController();
            ArrayList arrModules = objModules.GetModuleTabs(moduleID);
            TabController tabController = new TabController();
            Hashtable tabSettings;
            foreach (ModuleInfo objModule in arrModules)
            {
                tabSettings = tabController.GetTabSettings(objModule.TabID);
                if (tabSettings["CacheProvider"] != null && tabSettings["CacheProvider"].ToString().Length > 0)
                {
                    OutputCachingProvider outputProvider = OutputCachingProvider.Instance(tabSettings["CacheProvider"].ToString());
                    if (outputProvider != null)
                    {
                        outputProvider.Remove(objModule.TabID);
                    }
                }

                ModuleCachingProvider moduleProvider = ModuleCachingProvider.Instance(objModule.GetEffectiveCacheMethod());
                if (moduleProvider != null)
                {
                    moduleProvider.Remove(objModule.TabModuleID);
                }

                //Synchronize module is called when a module needs to indicate that the content
                //has changed and the cache's should be refreshed.  So we can update the Version
                objModules.UpdateTabModuleVersion(objModule.TabModuleID);

                //We should also indicate that the Transalation Status has changed
                if (PortalController.GetPortalSettingAsBoolean("ContentLocalizationEnabled", objModule.PortalID, false))
                {
                    objModules.UpdateTranslationStatus(objModule, false);
                }
            }
        }
        public int AddModule(ModuleInfo objModule)
        {
            Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
            AddModuleInternal(objModule);

            ModuleInfo tmpModule = GetModule(objModule.ModuleID, objModule.TabID);
            if (tmpModule != null)
            {
                if (tmpModule.IsDeleted)
                {
                    RestoreModule(objModule);
                }
            }
            else
            {
                dataProvider.AddTabModule(objModule.TabID, objModule.ModuleID, objModule.ModuleTitle, objModule.Header,
                                          objModule.Footer, objModule.ModuleOrder, objModule.PaneName,
                                          objModule.CacheTime, objModule.CacheMethod, objModule.Alignment,
                                          objModule.Color,
                                          objModule.Border, objModule.IconFile, (int)objModule.Visibility,
                                          objModule.ContainerSrc,
                                          objModule.DisplayTitle, objModule.DisplayPrint, objModule.DisplaySyndicate,
                                          objModule.IsWebSlice, objModule.WebSliceTitle, objModule.WebSliceExpiryDate,
                                          objModule.WebSliceTTL, objModule.UniqueId, objModule.VersionGuid,
                                          objModule.DefaultLanguageGuid, objModule.LocalizedVersionGuid,
                                          objModule.CultureCode, UserController.GetCurrentUserInfo().UserID);

                Services.Log.EventLog.LogInfo objEventLogInfo = new Services.Log.EventLog.LogInfo();
                objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("TabId", objModule.TabID.ToString()));
                objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("ModuleID", objModule.ModuleID.ToString()));
                objEventLogInfo.LogTypeKey = DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.TABMODULE_CREATED.ToString();
                objEventLog.AddLog(objEventLogInfo);
                if (objModule.ModuleOrder == -1)
                {
                    UpdateModuleOrder(objModule.TabID, objModule.ModuleID, objModule.ModuleOrder, objModule.PaneName);
                }
                else
                {
                    UpdateTabModuleOrder(objModule.TabID);
                }
            }

            if (objModule.TabModuleID == -1)
            {
                if (tmpModule == null)
                    tmpModule = GetModule(objModule.ModuleID, objModule.TabID);
                objModule.TabModuleID = tmpModule.TabModuleID;
            }
            UpdateTabModuleSettings(objModule);
            ClearCache(objModule.TabID);
            return objModule.ModuleID;
        }

        public void ClearCache(int TabId)
        {
            DataCache.ClearModuleCache(TabId);
        }

        public void CopyModule(ModuleInfo sourceModule, TabInfo destinationTab, string toPaneName, bool includeSettings)
        {
            TabController tabCtrl = new TabController();
            PortalInfo _Portal = new PortalController().GetPortal(destinationTab.PortalID);

            //Clone Module
            ModuleInfo destinationModule = sourceModule.Clone();
            if (!String.IsNullOrEmpty(toPaneName))
            {
                destinationModule.PaneName = toPaneName;
            }

            destinationModule.TabID = destinationTab.TabID;

            //The new reference copy should have the same culture as the destination Tab
            destinationModule.UniqueId = Guid.NewGuid();
            destinationModule.CultureCode = destinationTab.CultureCode;
            destinationModule.VersionGuid = Guid.NewGuid();
            destinationModule.LocalizedVersionGuid = Guid.NewGuid();

            //Figure out the DefaultLanguage Guid
            if (!String.IsNullOrEmpty(sourceModule.CultureCode)
                    && sourceModule.CultureCode == _Portal.DefaultLanguage
                    && destinationModule.CultureCode != sourceModule.CultureCode
                    && !String.IsNullOrEmpty(destinationModule.CultureCode))
            {
                //Tab is localized so set Default language Guid reference
                destinationModule.DefaultLanguageGuid = sourceModule.UniqueId;
            }
            else if (sourceModule.AllTabs && sourceModule.CultureCode != _Portal.DefaultLanguage)
            {
                if (sourceModule.DefaultLanguageModule != null
                    && destinationTab.DefaultLanguageTab != null)
                {
                    ModuleInfo defaultLanguageModule = GetModule(sourceModule.DefaultLanguageModule.ModuleID,
                                                                 destinationTab.DefaultLanguageTab.TabID);

                    if (defaultLanguageModule != null)
                    {
                        destinationModule.DefaultLanguageGuid = defaultLanguageModule.UniqueId;
                    }
                }
            }

            //This will fail if the page already contains this module
            try
            {
                //Add a copy of the module to the bottom of the Pane for the new Tab
                dataProvider.AddTabModule(destinationModule.TabID, destinationModule.ModuleID,
                                          destinationModule.ModuleTitle,
                                          destinationModule.Header, destinationModule.Footer,
                                          destinationModule.ModuleOrder,
                                          destinationModule.PaneName, destinationModule.CacheTime,
                                          destinationModule.CacheMethod,
                                          destinationModule.Alignment, destinationModule.Color, destinationModule.Border,
                                          destinationModule.IconFile, (int) destinationModule.Visibility,
                                          destinationModule.ContainerSrc,
                                          destinationModule.DisplayTitle, destinationModule.DisplayPrint,
                                          destinationModule.DisplaySyndicate,
                                          destinationModule.IsWebSlice, destinationModule.WebSliceTitle,
                                          destinationModule.WebSliceExpiryDate,
                                          destinationModule.WebSliceTTL, destinationModule.UniqueId,
                                          destinationModule.VersionGuid,
                                          destinationModule.DefaultLanguageGuid, destinationModule.LocalizedVersionGuid,
                                          destinationModule.CultureCode, UserController.GetCurrentUserInfo().UserID);

                //Optionally copy the TabModuleSettings
                if (includeSettings)
                {
                    CopyTabModuleSettings(sourceModule, destinationModule);
                }
            }
            catch
            {
                // module already in the page, ignore error
            }

            ClearCache(sourceModule.TabID);
            ClearCache(destinationTab.TabID);

            //Optionally copy the TabModuleSettings
            if(includeSettings)
            {
                destinationModule = GetModule(destinationModule.ModuleID, destinationModule.TabID);
                CopyTabModuleSettings(sourceModule, destinationModule);
            }
        }

        public void CopyModules(TabInfo sourceTab, TabInfo destinationTab, bool asReference)
        {
            foreach (KeyValuePair<int, ModuleInfo> kvp in GetTabModules(sourceTab.TabID))
            {
                ModuleInfo sourceModule = kvp.Value;

                // if the module shows on all pages does not need to be copied since it will
                // be already added to this page
                if (!sourceModule.AllTabs && !sourceModule.IsDeleted)
                {
                    if (!asReference)
                    {
                        //Deep Copy
                        sourceModule.ModuleID = Null.NullInteger;
                        sourceModule.TabID = destinationTab.TabID;
                        AddModule(sourceModule);
                    }
                    else
                    {
                        //Shallow (Reference Copy)
                        CopyModule(sourceModule, destinationTab, Null.NullString, true);
                    }
                }
            }
        }

        public void CopyTabModuleSettings(ModuleInfo fromModule, ModuleInfo toModule)
        {
            Hashtable settings = GetTabModuleSettings(fromModule.TabModuleID);
            foreach (DictionaryEntry setting in settings)
            {
                UpdateTabModuleSetting(toModule.TabModuleID, Convert.ToString(setting.Key), Convert.ToString(setting.Value));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="updatedModule"></param>
        /// <remarks></remarks>
        /// <history>
        ///    [vnguyen]   20110-05-10   Modified: Added update tabmodule versionguids
        /// </history>
        public void CreateContentItem(ModuleInfo updatedModule)
        {
            IContentTypeController typeController = new ContentTypeController();
            ContentType contentType = (from t in typeController.GetContentTypes()
                                       where t.Type == "Module"
                                       select t).SingleOrDefault();
            //This module does not have a valid ContentItem
            //create ContentItem
            IContentController contentController = DotNetNuke.Entities.Content.Common.Util.GetContentController();
            updatedModule.Content = updatedModule.ModuleTitle;
            updatedModule.Indexed = false;
            updatedModule.ContentTypeId = contentType.ContentTypeId;
            updatedModule.ContentItemId = contentController.AddContentItem(updatedModule);
        }
        public void DeleteAllModules(int moduleId, int tabId, List<TabInfo> fromTabs)
        {
            DeleteAllModules(moduleId, tabId, fromTabs, true, false, false);
        }
        public void DeleteAllModules(int moduleId, int tabId, List<TabInfo> fromTabs, bool softDelete, bool includeCurrent, bool deleteBaseModule)
        {
            foreach (TabInfo objTab in fromTabs)
            {
                if (objTab.TabID != tabId || includeCurrent)
                {
                    DeleteTabModule(objTab.TabID, moduleId, softDelete);
                }
            }
            if (includeCurrent && deleteBaseModule && !softDelete)
            {
                DeleteModule(moduleId);
            }
            ClearCache(tabId);
        }
        public void DeleteModule(int ModuleId)
        {
            //Get the module
            ModuleInfo objModule = GetModule(ModuleId);
            dataProvider.DeleteModule(ModuleId);
            //Remove the Content Item
            if (objModule != null && objModule.ContentItemId > Null.NullInteger)
            {
                IContentController ctl = DotNetNuke.Entities.Content.Common.Util.GetContentController();
                ctl.DeleteContentItem(objModule);
            }

            //Log deletion
            Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
            objEventLog.AddLog("ModuleId", ModuleId.ToString(), PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.MODULE_DELETED);
            dataProvider.DeleteSearchItems(ModuleId);
        }
        public void DeleteTabModule(int tabId, int moduleId, bool softDelete)
        {
            ModuleInfo objModule = GetModule(moduleId, tabId, false);
            if (objModule != null)
            {
                dataProvider.DeleteTabModule(tabId, moduleId, softDelete);
                Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
                Services.Log.EventLog.LogInfo objEventLogInfo = new Services.Log.EventLog.LogInfo();
                objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("tabId", tabId.ToString()));
                objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("moduleId", moduleId.ToString()));
                objEventLogInfo.LogTypeKey = DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.TABMODULE_DELETED.ToString();
                objEventLog.AddLog(objEventLogInfo);
                UpdateTabModuleOrder(tabId);
                if (GetModule(moduleId, Null.NullInteger, true).TabID == Null.NullInteger)
                {
                    DeleteModule(moduleId);
                }
            }
            ClearCache(tabId);
        }

        public int DeLocalizeModule(ModuleInfo sourceModule)
        {
            int moduleId = Null.NullInteger;

            if (sourceModule != null && sourceModule.DefaultLanguageModule != null)
            {
                // clone the module object ( to avoid creating an object reference to the data cache )
                ModuleInfo newModule = sourceModule.Clone();

                //Get the Module ID of the default language instance
                newModule.ModuleID = sourceModule.DefaultLanguageModule.ModuleID;

                if (newModule.ModuleID != sourceModule.ModuleID)
                {
                    // update tabmodule
                    dataProvider.UpdateTabModule(newModule.TabModuleID, newModule.TabID, newModule.ModuleID, newModule.ModuleTitle, newModule.Header, newModule.Footer, newModule.ModuleOrder, newModule.PaneName, newModule.CacheTime, newModule.CacheMethod,
                    newModule.Alignment, newModule.Color, newModule.Border, newModule.IconFile, (int)newModule.Visibility, newModule.ContainerSrc, newModule.DisplayTitle, newModule.DisplayPrint, newModule.DisplaySyndicate, newModule.IsWebSlice,
                    newModule.WebSliceTitle, newModule.WebSliceExpiryDate, newModule.WebSliceTTL, newModule.VersionGuid, newModule.DefaultLanguageGuid, newModule.LocalizedVersionGuid, newModule.CultureCode, UserController.GetCurrentUserInfo().UserID);

                    //delete the deep copy "module info"
                    DeleteModule(sourceModule.ModuleID);
                }

                moduleId = newModule.ModuleID;

                //Clear Caches
                ClearCache(newModule.TabID);
                ClearCache(sourceModule.TabID);
            }

            return moduleId;
        }


        public ArrayList GetAllModules()
        {
            return CBO.FillCollection(dataProvider.GetAllModules(), typeof(ModuleInfo));
        }
        public ModuleInfo GetModule(int moduleID)
        {
            return GetModule(moduleID, Null.NullInteger, true);
        }
        public ModuleInfo GetModule(int moduleID, int tabID)
        {
            return GetModule(moduleID, tabID, false);
        }

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// get a Module object
        /// </summary>
        /// <param name="uniqueID"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        /// <history>
        ///    [vnguyen]   2010/05/11   Created
        /// </history>
        /// -----------------------------------------------------------------------------
        public ModuleInfo GetModuleByUniqueID(Guid uniqueID)
        {
            ModuleInfo modInfo = null;
            modInfo = CBO.FillObject<ModuleInfo>(dataProvider.GetModuleByUniqueID(uniqueID));
            return modInfo;
        }


        public ModuleInfo GetModule(int moduleID, int tabID, bool ignoreCache)
        {
            ModuleInfo modInfo = null;
            bool bFound = false;
            if (!ignoreCache)
            {
                Dictionary<int, ModuleInfo> dicModules = GetTabModules(tabID);
                bFound = dicModules.TryGetValue(moduleID, out modInfo);
            }
            if (ignoreCache || !bFound)
            {
                modInfo = CBO.FillObject<ModuleInfo>(dataProvider.GetModule(moduleID, tabID));
            }
            return modInfo;
        }
        public ArrayList GetModules(int portalID)
        {
            return CBO.FillCollection(dataProvider.GetModules(portalID), typeof(ModuleInfo));
        }
        public ArrayList GetAllTabsModules(int portalID, bool allTabs)
        {
            return CBO.FillCollection(dataProvider.GetAllTabsModules(portalID, allTabs), typeof(ModuleInfo));
        }

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// get TabModule objects that are linked to a particular ModuleID
        /// </summary>
        /// <param name="moduleID">ID of the module</param>
        /// <returns>ArrayList of TabModuleInfo objects</returns>
        /// <history>
        ///    [vnguyen]   2010-05-10   Created
        /// </history>
        /// -----------------------------------------------------------------------------
        public ArrayList GetAllTabsModulesByModuleID(int moduleID)
        {
            return CBO.FillCollection(dataProvider.GetAllTabsModulesByModuleID(moduleID), typeof(ModuleInfo));
        }


        public ModuleInfo GetModuleByDefinition(int portalID, string friendlyName)
        {
            ModuleInfo objModule = null;
            string key = string.Format(DataCache.ModuleCacheKey, portalID);
            Dictionary<string, ModuleInfo> modules = DataCache.GetCache<Dictionary<string, ModuleInfo>>(key);
            if (modules == null)
            {
                modules = new Dictionary<string, ModuleInfo>();
            }
            if (modules.ContainsKey(friendlyName))
            {
                objModule = modules[friendlyName];
            }
            else
            {
                Dictionary<string, ModuleInfo> clonemodules = new Dictionary<string, ModuleInfo>();
                foreach (ModuleInfo module in modules.Values)
                {
                    clonemodules[module.ModuleDefinition.FriendlyName] = module;
                }
                IDataReader dr = DataProvider.Instance().GetModuleByDefinition(portalID, friendlyName);
                try
                {
                    objModule = CBO.FillObject<ModuleInfo>(dr);
                }
                finally
                {
                    CBO.CloseDataReader(dr, true);
                }
                if (objModule != null)
                {
                    clonemodules[objModule.ModuleDefinition.FriendlyName] = objModule;
                    Int32 timeOut = DataCache.ModuleCacheTimeOut * Convert.ToInt32(Host.Host.PerformanceSetting);
                    if (timeOut > 0)
                    {
                        DataCache.SetCache(key, clonemodules, TimeSpan.FromMinutes(timeOut));
                    }
                }
            }
            return objModule;
        }
        public ArrayList GetModulesByDefinition(int portalID, string friendlyName)
        {
            return CBO.FillCollection(DataProvider.Instance().GetModuleByDefinition(portalID, friendlyName), typeof(ModuleInfo));
        }

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// Get a list of all TabModule references of a module instance
        /// </summary>
        /// <param name="ModuleID">ID of the Module</param>
        /// <returns>ArrayList of ModuleInfo</returns>
        /// <history>
        ///    [sleupold]   2007-09-24 documented
        /// </history>
        /// -----------------------------------------------------------------------------
        public ArrayList GetModuleTabs(int moduleID)
        {
            return CBO.FillCollection(dataProvider.GetModule(moduleID, Null.NullInteger), typeof(ModuleInfo));
        }


        public ArrayList GetSearchModules(int portalID)
        {
            return CBO.FillCollection(dataProvider.GetSearchModules(portalID), typeof(ModuleInfo));
        }

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// get a Module object
        /// </summary>
        /// <param name="tabModuleID">ID of the tabmodule</param>
        /// <returns>An ModuleInfo object</returns>
        /// <history>
        ///    [vnguyen]   04-07-2010
        /// </history>
        /// -----------------------------------------------------------------------------
        public ModuleInfo GetTabModule(int tabModuleID)
        {
            ModuleInfo modInfo = null;
            bool bFound = false;
            modInfo = CBO.FillObject<ModuleInfo>(dataProvider.GetTabModule(tabModuleID));
            return modInfo;
        }


        public Dictionary<int, ModuleInfo> GetTabModules(int tabID)
        {
            string cacheKey = string.Format(DataCache.TabModuleCacheKey, tabID.ToString());
            return CBO.GetCachedObject<Dictionary<int, ModuleInfo>>(new CacheItemArgs(cacheKey, DataCache.TabModuleCacheTimeOut, DataCache.TabModuleCachePriority, tabID), GetTabModulesCallBack);
        }

        public void LocalizeModule(ModuleInfo sourceModule, Locale locale)
        {
            ModuleInfo defaultModule = sourceModule.DefaultLanguageModule;
            if (defaultModule != null)
            {
                ArrayList tabModules = GetModuleTabs(defaultModule.ModuleID);
                if (tabModules.Count > 1)
                {
                    //default language version is a reference copy

                    //Localize first tabModule
                    int newModuleID = LocalizeModuleInternal(sourceModule);

                    //Update Reference Copies
                    foreach (ModuleInfo tm in tabModules)
                    {
                        if (tm.IsDefaultLanguage)
                        {
                            ModuleInfo localModule = null;
                            if (tm.LocalizedModules.TryGetValue(locale.Code, out localModule))
                            {
                                localModule.ModuleID = newModuleID;
                                UpdateModule(localModule);
                            }
                        }
                    }
                }
                else
                {
                    LocalizeModuleInternal(sourceModule);
                }
            }

        }

        public void MoveModule(int moduleId, int fromTabId, int toTabId, string toPaneName)
        {
            ModuleInfo objModule = GetModule(moduleId, fromTabId);
            dataProvider.MoveTabModule(fromTabId, moduleId, toTabId, toPaneName, UserController.GetCurrentUserInfo().UserID);
            UpdateTabModuleOrder(fromTabId);
            UpdateTabModuleOrder(toTabId);
        }
        public void RestoreModule(ModuleInfo objModule)
        {
            dataProvider.RestoreTabModule(objModule.TabID, objModule.ModuleID);
            ClearCache(objModule.TabID);
        }

        public void UpdateModule(ModuleInfo objModule)
        {
            //Update ContentItem If neccessary
            if (objModule.ContentItemId == Null.NullInteger && objModule.ModuleID != Null.NullInteger)
            {
                CreateContentItem(objModule);
            }
            dataProvider.UpdateModule(objModule.ModuleID, objModule.ContentItemId, objModule.AllTabs,
                                      objModule.StartDate, objModule.EndDate, objModule.InheritViewPermissions,
                                      objModule.IsDeleted, UserController.GetCurrentUserInfo().UserID);
            //Update Tags
            ITermController termController = DotNetNuke.Entities.Content.Common.Util.GetTermController();
            termController.RemoveTermsFromContent(objModule);
            foreach (Term _Term in objModule.Terms)
            {
                termController.AddTermToContent(_Term, objModule);
            }
            Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
            objEventLog.AddLog(objModule, PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, "", Services.Log.EventLog.EventLogController.EventLogType.MODULE_UPDATED);
            ModulePermissionController.SaveModulePermissions(objModule);
            UpdateModuleSettings(objModule);
            objModule.VersionGuid = Guid.NewGuid();
            objModule.LocalizedVersionGuid = Guid.NewGuid();

            if (!Null.IsNull(objModule.TabID))
            {
                //update tabmodule
                dataProvider.UpdateTabModule(objModule.TabModuleID, objModule.TabID, objModule.ModuleID,
                                             objModule.ModuleTitle,
                                             objModule.Header, objModule.Footer, objModule.ModuleOrder,
                                             objModule.PaneName,
                                             objModule.CacheTime, objModule.CacheMethod, objModule.Alignment,
                                             objModule.Color,
                                             objModule.Border, objModule.IconFile, (int) objModule.Visibility,
                                             objModule.ContainerSrc,
                                             objModule.DisplayTitle, objModule.DisplayPrint, objModule.DisplaySyndicate,
                                             objModule.IsWebSlice, objModule.WebSliceTitle, objModule.WebSliceExpiryDate,
                                             objModule.WebSliceTTL, objModule.VersionGuid, objModule.DefaultLanguageGuid,
                                             objModule.LocalizedVersionGuid, objModule.CultureCode,
                                             UserController.GetCurrentUserInfo().UserID);
                
                objEventLog.AddLog(objModule, PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, "", DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.TABMODULE_UPDATED);
                UpdateModuleOrder(objModule.TabID, objModule.ModuleID, objModule.ModuleOrder, objModule.PaneName);
                if (PortalSettings.Current != null)
                {
                    if (objModule.IsDefaultModule)
                    {
                        if (objModule.ModuleID != PortalSettings.Current.DefaultModuleId)
                        {
                            PortalController.UpdatePortalSetting(objModule.PortalID, "defaultmoduleid", objModule.ModuleID.ToString());
                        }
                        if (objModule.TabID != PortalSettings.Current.DefaultTabId)
                        {
                            PortalController.UpdatePortalSetting(objModule.PortalID, "defaulttabid", objModule.TabID.ToString());
                        }
                    }
                    else
                    {
                        if (objModule.ModuleID == PortalSettings.Current.DefaultModuleId && objModule.TabID == PortalSettings.Current.DefaultTabId)
                        {
                            PortalController.DeletePortalSetting(objModule.PortalID, "defaultmoduleid");
                            PortalController.DeletePortalSetting(objModule.PortalID, "defaulttabid");
                        }
                    }
                }
                if (objModule.AllModules)
                {
                    TabController objTabs = new TabController();
                    foreach (KeyValuePair<int, TabInfo> tabPair in objTabs.GetTabsByPortal(objModule.PortalID))
                    {
                        TabInfo objTab = tabPair.Value;
                        foreach (KeyValuePair<int, ModuleInfo> modulePair in GetTabModules(objTab.TabID))
                        {
                            ModuleInfo objTargetModule = modulePair.Value;
                            objTargetModule.VersionGuid = Guid.NewGuid();
                            objTargetModule.LocalizedVersionGuid = Guid.NewGuid();

                            dataProvider.UpdateTabModule(objTargetModule.TabModuleID, objTargetModule.TabID,
                                                         objTargetModule.ModuleID,
                                                         objTargetModule.ModuleTitle, objTargetModule.Header,
                                                         objTargetModule.Footer,
                                                         objTargetModule.ModuleOrder, objTargetModule.PaneName,
                                                         objTargetModule.CacheTime,
                                                         objModule.CacheMethod, objModule.Alignment, objModule.Color,
                                                         objModule.Border,
                                                         objModule.IconFile, (int) objModule.Visibility,
                                                         objModule.ContainerSrc, objModule.DisplayTitle,
                                                         objModule.DisplayPrint, objModule.DisplaySyndicate,
                                                         objModule.IsWebSlice,
                                                         objModule.WebSliceTitle, objModule.WebSliceExpiryDate,
                                                         objModule.WebSliceTTL,
                                                         objModule.VersionGuid, objModule.DefaultLanguageGuid,
                                                         objModule.LocalizedVersionGuid,
                                                         objModule.CultureCode,
                                                         UserController.GetCurrentUserInfo().UserID);
                        }
                    }
                }
            }
            foreach (ModuleInfo tabModule in GetModuleTabs(objModule.ModuleID))
            {
                ClearCache(tabModule.TabID);
            }
        }

        public void UpdateModuleOrder(int TabId, int ModuleId, int ModuleOrder, string PaneName)
        {
            ModuleInfo objModule = GetModule(ModuleId, TabId, false);
            if (objModule != null)
            {
                if (ModuleOrder == -1)
                {
                    IDataReader dr = null;
                    try
                    {
                        dr = dataProvider.GetTabModuleOrder(TabId, PaneName);
                        while (dr.Read())
                        {
                            ModuleOrder = Convert.ToInt32(dr["ModuleOrder"]);
                        }
                    }
                    catch (Exception ex)
                    {
                        DotNetNuke.Services.Exceptions.Exceptions.LogException(ex);
                    }
                    finally
                    {
                        CBO.CloseDataReader(dr, true);
                    }
                    ModuleOrder += 2;
                }
                dataProvider.UpdateModuleOrder(TabId, ModuleId, ModuleOrder, PaneName);

                ClearCache(TabId);
            }
        }
        public void UpdateTabModuleOrder(int TabId)
        {
            int ModuleCounter;
            IDataReader dr = null;
            dr = dataProvider.GetTabPanes(TabId);
            try
            {
                while (dr.Read())
                {
                    ModuleCounter = 0;
                    IDataReader dr2 = null;
                    dr2 = dataProvider.GetTabModuleOrder(TabId, Convert.ToString(dr["PaneName"]));
                    try
                    {
                        while (dr2.Read())
                        {
                            ModuleCounter += 1;
                            dataProvider.UpdateModuleOrder(TabId, Convert.ToInt32(dr2["ModuleID"]), (ModuleCounter * 2) - 1, Convert.ToString(dr["PaneName"]));
                        }
                    }
                    catch (Exception ex2)
                    {
                        DotNetNuke.Services.Exceptions.Exceptions.LogException(ex2);
                    }
                    finally
                    {
                        CBO.CloseDataReader(dr2, true);
                    }
                }
            }
            catch (Exception ex)
            {
                DotNetNuke.Services.Exceptions.Exceptions.LogException(ex);
            }
            finally
            {
                CBO.CloseDataReader(dr, true);
            }
            ClearCache(TabId);
        }

        public void UpdateTranslationStatus(ModuleInfo localizedModule, bool isTranslated)
        {
            if (isTranslated && (localizedModule.DefaultLanguageModule != null))
            {
                localizedModule.LocalizedVersionGuid = localizedModule.DefaultLanguageModule.LocalizedVersionGuid;
            }
            else
            {
                localizedModule.LocalizedVersionGuid = Guid.NewGuid();
            }
            DataProvider.Instance().UpdateTabModuleTranslationStatus(localizedModule.TabModuleID, localizedModule.LocalizedVersionGuid, UserController.GetCurrentUserInfo().UserID);

            //Clear Tab Caches
            ClearCache(localizedModule.TabID);
        }


        public Hashtable GetModuleSettings(int ModuleId)
        {
            Hashtable objSettings;
            string strCacheKey = "GetModuleSettings" + ModuleId.ToString();
            objSettings = (Hashtable)DataCache.GetCache(strCacheKey);
            if (objSettings == null)
            {
                objSettings = new Hashtable();
                IDataReader dr = null;
                try
                {
                    dr = dataProvider.GetModuleSettings(ModuleId);
                    while (dr.Read())
                    {
                        if (!dr.IsDBNull(1))
                        {
                            objSettings[dr.GetString(0)] = dr.GetString(1);
                        }
                        else
                        {
                            objSettings[dr.GetString(0)] = string.Empty;
                        }
                    }
                }
                catch (Exception ex)
                {
                    DotNetNuke.Services.Exceptions.Exceptions.LogException(ex);
                }
                finally
                {
                    CBO.CloseDataReader(dr, true);
                }
                int intCacheTimeout = 20 * Convert.ToInt32(Host.Host.PerformanceSetting);
                DataCache.SetCache(strCacheKey, objSettings, TimeSpan.FromMinutes(intCacheTimeout));
            }
            return objSettings;
        }
        public void UpdateModuleSetting(int ModuleId, string SettingName, string SettingValue)
        {
            UpdateModuleSettingInternal(ModuleId, SettingName, SettingValue, true);
        }

        public void DeleteModuleSetting(int ModuleId, string SettingName)
        {
            dataProvider.DeleteModuleSetting(ModuleId, SettingName);
            Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
            Services.Log.EventLog.LogInfo objEventLogInfo = new Services.Log.EventLog.LogInfo();
            objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("ModuleId", ModuleId.ToString()));
            objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("SettingName", SettingName.ToString()));
            objEventLogInfo.LogTypeKey = DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.MODULE_SETTING_DELETED.ToString();
            objEventLog.AddLog(objEventLogInfo);
            UpdateTabModuleVersionsByModuleID(ModuleId);
            DataCache.RemoveCache("GetModuleSettings" + ModuleId.ToString());
        }
        public void DeleteModuleSettings(int ModuleId)
        {
            dataProvider.DeleteModuleSettings(ModuleId);
            Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
            Services.Log.EventLog.LogInfo objEventLogInfo = new Services.Log.EventLog.LogInfo();
            objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("ModuleId", ModuleId.ToString()));
            objEventLogInfo.LogTypeKey = DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.MODULE_SETTING_DELETED.ToString();
            objEventLog.AddLog(objEventLogInfo);
            UpdateTabModuleVersionsByModuleID(ModuleId);
            DataCache.RemoveCache("GetModuleSettings" + ModuleId.ToString());
        }
        public Hashtable GetTabModuleSettings(int TabModuleId)
        {
            string strCacheKey = "GetTabModuleSettings" + TabModuleId.ToString();
            Hashtable objSettings = (Hashtable)DataCache.GetCache(strCacheKey);
            if (objSettings == null)
            {
                objSettings = new Hashtable();
                IDataReader dr = null;
                try
                {
                    dr = dataProvider.GetTabModuleSettings(TabModuleId);
                    while (dr.Read())
                    {
                        if (!dr.IsDBNull(1))
                        {
                            objSettings[dr.GetString(0)] = dr.GetString(1);
                        }
                        else
                        {
                            objSettings[dr.GetString(0)] = string.Empty;
                        }
                    }
                }
                catch (Exception ex)
                {
                    DotNetNuke.Services.Exceptions.Exceptions.LogException(ex);
                }
                finally
                {
                    CBO.CloseDataReader(dr, true);
                }
                int intCacheTimeout = 20 * Convert.ToInt32(Host.Host.PerformanceSetting);
                DataCache.SetCache(strCacheKey, objSettings, TimeSpan.FromMinutes(intCacheTimeout));
            }
            return objSettings;
        }
        public void UpdateTabModuleSetting(int TabModuleId, string SettingName, string SettingValue)
        {
            Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
            Services.Log.EventLog.LogInfo objEventLogInfo = new Services.Log.EventLog.LogInfo();
            objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("TabModuleId", TabModuleId.ToString()));
            objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("SettingName", SettingName.ToString()));
            objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("SettingValue", SettingValue.ToString()));
            IDataReader dr = null;
            try
            {
                dr = dataProvider.GetTabModuleSetting(TabModuleId, SettingName);
                if (dr.Read())
                {
                    dataProvider.UpdateTabModuleSetting(TabModuleId, SettingName, SettingValue, UserController.GetCurrentUserInfo().UserID);
                    objEventLogInfo.LogTypeKey = DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.TABMODULE_SETTING_UPDATED.ToString();
                    objEventLog.AddLog(objEventLogInfo);
                }
                else
                {
                    dataProvider.AddTabModuleSetting(TabModuleId, SettingName, SettingValue, UserController.GetCurrentUserInfo().UserID);
                    objEventLogInfo.LogTypeKey = DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.TABMODULE_SETTING_CREATED.ToString();
                    objEventLog.AddLog(objEventLogInfo);
                }
                UpdateTabModuleVersion(TabModuleId);
            }
            catch (Exception ex)
            {
                DotNetNuke.Services.Exceptions.Exceptions.LogException(ex);
            }
            finally
            {
                CBO.CloseDataReader(dr, true);
            }
            DataCache.RemoveCache("GetTabModuleSettings" + TabModuleId.ToString());
        }
        public void DeleteTabModuleSetting(int TabModuleId, string SettingName)
        {
            dataProvider.DeleteTabModuleSetting(TabModuleId, SettingName);
            UpdateTabModuleVersion(TabModuleId);
            Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
            Services.Log.EventLog.LogInfo objEventLogInfo = new Services.Log.EventLog.LogInfo();
            objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("TabModuleId", TabModuleId.ToString()));
            objEventLogInfo.LogProperties.Add(new DotNetNuke.Services.Log.EventLog.LogDetailInfo("SettingName", SettingName.ToString()));
            objEventLogInfo.LogTypeKey = DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.TABMODULE_SETTING_DELETED.ToString();
            objEventLog.AddLog(objEventLogInfo);
            DataCache.RemoveCache("GetTabModuleSettings" + TabModuleId.ToString());
        }
        public void DeleteTabModuleSettings(int TabModuleId)
        {
            dataProvider.DeleteTabModuleSettings(TabModuleId);
            UpdateTabModuleVersion(TabModuleId);
            Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
            objEventLog.AddLog("TabModuleID", TabModuleId.ToString(), PortalController.GetCurrentPortalSettings(), UserController.GetCurrentUserInfo().UserID, DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.TABMODULE_SETTING_DELETED);
            DataCache.RemoveCache("GetTabModuleSettings" + TabModuleId.ToString());
        }


        [Obsolete("The module caching feature has been updated in version 5.2.0.  This method is no longer used.")]
        public static string CacheDirectory()
        {
            return PortalController.GetCurrentPortalSettings().HomeDirectoryMapPath + "Cache";
        }

        [Obsolete("The module caching feature has been updated in version 5.2.0.  This method is no longer used.")]
        public static string CacheFileName(int TabModuleID)
        {
            string strCacheKey = "TabModule:";
            strCacheKey += TabModuleID.ToString() + ":";
            strCacheKey += System.Threading.Thread.CurrentThread.CurrentUICulture.ToString();
            return PortalController.GetCurrentPortalSettings().HomeDirectoryMapPath + "Cache" + "\\" + Globals.CleanFileName(strCacheKey) + ".resources";
        }

        [Obsolete("The module caching feature has been updated in version 5.2.0.  This method is no longer used.")]
        public static string CacheKey(int TabModuleID)
        {
            string strCacheKey = "TabModule:";
            strCacheKey += TabModuleID.ToString() + ":";
            strCacheKey += System.Threading.Thread.CurrentThread.CurrentUICulture.ToString();
            return strCacheKey;
        }

        [Obsolete("Deprecated in DNN 5.0.  Replaced by CopyModule(ModuleInfo, TabInfo, String, Boolean)")]
        public void CopyModule(int moduleId, int fromTabId, List<TabInfo> toTabs, bool includeSettings)
        {
            ModuleInfo objModule = GetModule(moduleId, fromTabId, false);
            //Iterate through collection copying the module to each Tab (except the source)
            foreach (TabInfo objTab in toTabs)
            {
                if (objTab.TabID != fromTabId)
                {
                    CopyModule(objModule, objTab, "", includeSettings);
                }
            }
        }

        [Obsolete("Deprecated in DNN 5.5.  Replaced by CopyModule(ModuleInfo, TabInfo, String, Boolean)")]
        public void CopyModule(int moduleId, int fromTabId, int toTabId, string toPaneName, bool includeSettings)
        {
            PortalSettings _portalSettings = PortalController.GetCurrentPortalSettings();
            ModuleInfo objModule = GetModule(moduleId, fromTabId, false);
            TabInfo objTab = new TabController().GetTab(toTabId, _portalSettings.PortalId, false);
            CopyModule(objModule, objTab, toPaneName, includeSettings);
        }

        [Obsolete("Replaced in DotNetNuke 5.0 by CopyModule(Integer, integer, List(Of TabInfo), Boolean)")]
        public void CopyModule(int moduleId, int fromTabId, ArrayList toTabs, bool includeSettings)
        {
            ModuleInfo objModule = GetModule(moduleId, fromTabId, false);
            foreach (TabInfo objTab in toTabs)
            {
                if (objTab.TabID != fromTabId)
                {
                    CopyModule(objModule, objTab, "", includeSettings);
                }
            }
        }
        [Obsolete("Deprectaed in DNN 5.1.  Replaced By DeleteAllModules(Integer,Integer, List(Of TabInfo), Boolean, Boolean, Boolean)")]
        public void DeleteAllModules(int moduleId, int tabId, List<TabInfo> fromTabs, bool includeCurrent, bool deleteBaseModule)
        {
            DeleteAllModules(moduleId, tabId, fromTabs, true, includeCurrent, deleteBaseModule);
        }
        [Obsolete("Replaced in DotNetNuke 5.0 by DeleteAllModules(Integer, integer, List(Of TabInfo), Boolean, boolean)")]
        public void DeleteAllModules(int moduleId, int tabId, ArrayList fromTabs, bool includeCurrent, bool deleteBaseModule)
        {
            List<TabInfo> listTabs = new List<TabInfo>();
            foreach (TabInfo objTab in fromTabs)
            {
                listTabs.Add(objTab);
            }
            DeleteAllModules(moduleId, tabId, listTabs, true, includeCurrent, deleteBaseModule);
        }
        [Obsolete("Deprectaed in DNN 5.1. Replaced by DeleteTabModule(Integer, integer, boolean)")]
        public void DeleteTabModule(int tabId, int moduleId)
        {
            DeleteTabModule(tabId, moduleId, true);
        }
        [Obsolete("Replaced in DotNetNuke 5.0 by GetTabModules(Integer)")]
        public ArrayList GetPortalTabModules(int portalID, int tabID)
        {
            ArrayList arr = new ArrayList();
            foreach (KeyValuePair<int, ModuleInfo> kvp in GetTabModules(tabID))
            {
                arr.Add(kvp.Value);
            }
            return arr;
        }
        [Obsolete("Replaced in DotNetNuke 5.0 by GetModules(Integer)")]
        public ArrayList GetModules(int portalID, bool includePermissions)
        {
            return CBO.FillCollection(dataProvider.GetModules(portalID), typeof(ModuleInfo));
        }
        [Obsolete("Replaced in DotNetNuke 5.0 by UpdateTabModuleOrder(Integer)")]
        public void UpdateTabModuleOrder(int tabId, int portalId)
        {
            UpdateTabModuleOrder(tabId);
        }
    }
}
