using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
//
// DotNetNuke?- http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//



namespace DotNetNuke.Entities.Modules.Communications
{

    public class ModuleCommunicationEventArgs : System.EventArgs
    {

        private string m_Sender = null;
        private string m_Target = null;
        private string m_Text = null;
        private string m_Type = null;

        private object m_Value = null;
        public ModuleCommunicationEventArgs()
        {
        }

        public ModuleCommunicationEventArgs(string Text)
        {
            m_Text = Text;
        }

        public ModuleCommunicationEventArgs(string Type, object Value, string Sender, string Target)
        {
            m_Type = Type;
            m_Value = Value;
            m_Sender = Sender;
            m_Target = m_Target;

        }

        public string Sender
        {
            get { return m_Sender; }
            set { m_Sender = value; }
        }

        public string Target
        {
            get { return m_Target; }
            set { m_Target = value; }
        }

        public string Text
        {
            get { return m_Text; }
            set { m_Text = value; }
        }

        public string Type
        {
            get { return m_Type; }
            set { m_Type = value; }
        }

        public object Value
        {
            get { return m_Value; }
            set { m_Value = value; }
        }

    }

}
