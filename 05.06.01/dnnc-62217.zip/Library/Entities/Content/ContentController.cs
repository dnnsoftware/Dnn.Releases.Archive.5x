﻿using System;
using System.Collections.Generic;
using DotNetNuke.Common;
using DotNetNuke.Common.Utilities;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//


using DotNetNuke.Entities.Content.Common;
using DotNetNuke.Entities.Content.Data;
using DotNetNuke.Entities.Users;
using System.Linq;
using System.Collections.Specialized;
using System.Data;

namespace DotNetNuke.Entities.Content
{

    public class ContentController : IContentController
    {

        #region "Private Members"


        private IDataService _DataService;
        #endregion

        #region "Constructors"

        public ContentController()
            : this(Util.GetDataService())
        {
        }

        public ContentController(IDataService dataService)
        {
            _DataService = dataService;
        }

        #endregion

        #region "Public Methods"

        public int AddContentItem(ContentItem contentItem)
        {
            //Argument Contract
			Requires.NotNull("contentItem", contentItem);

            contentItem.ContentItemId = _DataService.AddContentItem(contentItem, UserController.GetCurrentUserInfo().UserID);

            return contentItem.ContentItemId;
        }

        public void DeleteContentItem(ContentItem contentItem)
        {
            //Argument Contract
			Requires.NotNull("contentItem", contentItem);
			Requires.PropertyNotNegative("contentItem", "ContentItemId", contentItem.ContentItemId);

            _DataService.DeleteContentItem(contentItem);
        }

        public ContentItem GetContentItem(int contentItemId)
        {
            //Argument Contract
			Requires.NotNegative("contentItemId", contentItemId);

            return CBO.FillObject<ContentItem>(_DataService.GetContentItem(contentItemId));
        }

		public IQueryable<ContentItem> GetContentItemsByTerm(string term)
		{
			//Argument Contract
			Requires.NotNullOrEmpty("term", term);

			return CBO.FillQueryable<ContentItem>(_DataService.GetContentItemsByTerm(term));
		}

		public IQueryable<ContentItem> GetUnIndexedContentItems()
        {
			return CBO.FillQueryable<ContentItem>(_DataService.GetUnIndexedContentItems());
        }

        public void UpdateContentItem(ContentItem contentItem)
        {
            //Argument Contract
			Requires.NotNull("contentItem", contentItem);
			Requires.PropertyNotNegative("contentItem", "ContentItemId", contentItem.ContentItemId);

            _DataService.UpdateContentItem(contentItem, UserController.GetCurrentUserInfo().UserID);
        }

		public void AddMetaData(ContentItem contentItem, string name, string value)
		{
			//Argument Contract
			Requires.NotNull("contentItem", contentItem);
			Requires.PropertyNotNegative("contentItem", "ContentItemId", contentItem.ContentItemId);
			Requires.NotNullOrEmpty("name", name);

			_DataService.AddMetaData(contentItem, name, value);
		}
		public void DeleteMetaData(ContentItem contentItem, string name, string value)
		{
			//Argument Contract
			Requires.NotNull("contentItem", contentItem);
			Requires.PropertyNotNegative("contentItem", "ContentItemId", contentItem.ContentItemId);
			Requires.NotNullOrEmpty("name", name);

			_DataService.DeleteMetaData(contentItem, name, value);
		}
		public NameValueCollection GetMetaData(int contentItemId)
		{
			//Argument Contract
			Requires.NotNegative("contentItemId", contentItemId);

			NameValueCollection metadata = new NameValueCollection();
			IDataReader dr = _DataService.GetMetaData(contentItemId);
			while (dr.Read())
			{
				metadata.Add(dr.GetString(0), dr.GetString(1));
			}

			return metadata;
		}

        #endregion

    }

}

