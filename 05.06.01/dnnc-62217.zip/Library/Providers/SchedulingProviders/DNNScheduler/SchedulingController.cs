//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Host;
namespace DotNetNuke.Services.Scheduling.DNNScheduling
{
	public class SchedulingController
	{
        [Obsolete("Obsoleted in 5.2.1 - use overload that pass's a FriendlyName")]
        public static int AddSchedule(string TypeFullName, int TimeLapse, string TimeLapseMeasurement, int RetryTimeLapse, string RetryTimeLapseMeasurement, int RetainHistoryNum, string AttachToEvent, bool CatchUpEnabled, bool Enabled, string ObjectDependencies, string Servers)
        {
            return AddSchedule(TypeFullName, TimeLapse, TimeLapseMeasurement, RetryTimeLapse, RetryTimeLapseMeasurement,
                               RetainHistoryNum, AttachToEvent, CatchUpEnabled, Enabled, ObjectDependencies, Servers,
                               TypeFullName);
        }

	    public static int AddSchedule(string TypeFullName, int TimeLapse, string TimeLapseMeasurement, int RetryTimeLapse, string RetryTimeLapseMeasurement, int RetainHistoryNum, string AttachToEvent, bool CatchUpEnabled, bool Enabled, string ObjectDependencies,
		string Servers, string FriendlyName)
		{
			Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
			objEventLog.AddLog("TypeFullName", TypeFullName, Entities.Portals.PortalController.GetCurrentPortalSettings(), Entities.Users.UserController.GetCurrentUserInfo().UserID, Log.EventLog.EventLogController.EventLogType.SCHEDULE_CREATED);
			return DataProvider.Instance().AddSchedule(TypeFullName, TimeLapse, TimeLapseMeasurement, RetryTimeLapse, RetryTimeLapseMeasurement, RetainHistoryNum, AttachToEvent, CatchUpEnabled, Enabled, ObjectDependencies,
			Servers, Entities.Users.UserController.GetCurrentUserInfo().UserID, FriendlyName);
		}
		public static int AddScheduleHistory(ScheduleHistoryItem objScheduleHistoryItem)
		{
			return DataProvider.Instance().AddScheduleHistory(objScheduleHistoryItem.ScheduleID, objScheduleHistoryItem.StartDate, ServerController.GetExecutingServerName());
		}
		public static void AddScheduleItemSetting(int ScheduleID, string Name, string Value)
		{
			DataProvider.Instance().AddScheduleItemSetting(ScheduleID, Name, Value);
		}
		public static void DeleteSchedule(int ScheduleID)
		{
			DataProvider.Instance().DeleteSchedule(ScheduleID);
			Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
			objEventLog.AddLog("ScheduleID", ScheduleID.ToString(), Entities.Portals.PortalController.GetCurrentPortalSettings(), Entities.Users.UserController.GetCurrentUserInfo().UserID, Log.EventLog.EventLogController.EventLogType.SCHEDULE_DELETED);
		}
		public static int GetActiveThreadCount()
		{
			return Scheduler.CoreScheduler.GetActiveThreadCount();
		}
		public static int GetFreeThreadCount()
		{
			return Scheduler.CoreScheduler.GetFreeThreadCount();
		}
		public static int GetMaxThreadCount()
		{
			return Scheduler.CoreScheduler.GetMaxThreadCount();
		}
		public static ScheduleItem GetNextScheduledTask(string Server)
		{
			return CBO.FillObject<ScheduleItem>(DataProvider.Instance().GetNextScheduledTask(Server));
		}
		public static List<ScheduleItem> GetSchedule()
		{
			return CBO.FillCollection<ScheduleItem>(DataProvider.Instance().GetSchedule());
		}
		public static List<ScheduleItem> GetSchedule(string Server)
		{
			return CBO.FillCollection<ScheduleItem>(DataProvider.Instance().GetSchedule(Server));
		}
		public static ScheduleItem GetSchedule(string TypeFullName, string Server)
		{
			return CBO.FillObject<ScheduleItem>(DataProvider.Instance().GetSchedule(TypeFullName, Server));
		}
		public static ScheduleItem GetSchedule(int ScheduleID)
		{
			return CBO.FillObject<ScheduleItem>(DataProvider.Instance().GetSchedule(ScheduleID));
		}
		public static List<ScheduleItem> GetScheduleByEvent(string EventName, string Server)
		{
			return CBO.FillCollection<ScheduleItem>(DataProvider.Instance().GetScheduleByEvent(EventName, Server));
		}
		public static List<ScheduleHistoryItem> GetScheduleHistory(int ScheduleID)
		{
			return CBO.FillCollection<ScheduleHistoryItem>(DataProvider.Instance().GetScheduleHistory(ScheduleID));
		}
		public static Hashtable GetScheduleItemSettings(int ScheduleID)
		{
			Hashtable h = new Hashtable();
			IDataReader r = DataProvider.Instance().GetScheduleItemSettings(ScheduleID);
			while (r.Read()) {
				h.Add(r["SettingName"], r["SettingValue"]);
			}
			if (r != null) {
				r.Close();
			}
			return h;
		}
		public static IList<ScheduleItem> GetScheduleProcessing()
		{
			return Scheduler.CoreScheduler.GetScheduleInProgress();
		}
		public static IList<ScheduleItem> GetScheduleQueue()
		{
			return Scheduler.CoreScheduler.GetScheduleQueue();
		}
		public static ScheduleStatus GetScheduleStatus()
		{
			return Scheduler.CoreScheduler.GetScheduleStatus();
		}
		public static void PurgeScheduleHistory()
		{
			DataProvider.Instance().PurgeScheduleHistory();
		}
		public static void ReloadSchedule()
		{
			Scheduler.CoreScheduler.ReloadSchedule();
		}

		public static void UpdateSchedule(int ScheduleID, string TypeFullName, int TimeLapse, string TimeLapseMeasurement, int RetryTimeLapse, string RetryTimeLapseMeasurement, int RetainHistoryNum, string AttachToEvent, bool CatchUpEnabled, bool Enabled,
		string ObjectDependencies, string Servers, string FriendlyName)
		{
			DataProvider.Instance().UpdateSchedule(ScheduleID, TypeFullName, TimeLapse, TimeLapseMeasurement, RetryTimeLapse, RetryTimeLapseMeasurement, RetainHistoryNum, AttachToEvent, CatchUpEnabled, Enabled,
			ObjectDependencies, Servers, Entities.Users.UserController.GetCurrentUserInfo().UserID, FriendlyName);
			Services.Log.EventLog.EventLogController objEventLog = new Services.Log.EventLog.EventLogController();
			objEventLog.AddLog("TypeFullName", TypeFullName, Entities.Portals.PortalController.GetCurrentPortalSettings(), Entities.Users.UserController.GetCurrentUserInfo().UserID, Log.EventLog.EventLogController.EventLogType.SCHEDULE_UPDATED);
		}
		public static void UpdateScheduleHistory(ScheduleHistoryItem objScheduleHistoryItem)
		{
			DataProvider.Instance().UpdateScheduleHistory(objScheduleHistoryItem.ScheduleHistoryID, objScheduleHistoryItem.EndDate, objScheduleHistoryItem.Succeeded, objScheduleHistoryItem.LogNotes, objScheduleHistoryItem.NextStart);
		}
	}
}
