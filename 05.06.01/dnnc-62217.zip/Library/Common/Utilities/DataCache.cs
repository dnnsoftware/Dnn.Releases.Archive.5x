//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Web.Caching;
using DotNetNuke.Collections;
using DotNetNuke.Entities.Host;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Tabs;
using DotNetNuke.Services.Cache;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Services.Log.EventLog;
using DotNetNuke.Services.OutputCache;

namespace DotNetNuke.Common.Utilities
{
	public enum CoreCacheType
	{
		Host = 1,
		Portal = 2,
		Tab = 3
	}
	public class DataCache
	{
		private static string _CachePersistenceEnabled = "";

		private static ReaderWriterLock dictionaryLock = new ReaderWriterLock();
		private static Dictionary<string, object> lockDictionary = new Dictionary<string, object>();
	    private static SharedDictionary<string, Object> dictionaryCache = new SharedDictionary<string, Object>();

		public const string SecureHostSettingsCacheKey = "SecureHostSettings";
	    public const string UnSecureHostSettingsCacheKey = "UnsecureHostSettings";
		public const string HostSettingsCacheKey = "HostSettings";
		public const CacheItemPriority HostSettingsCachePriority = CacheItemPriority.NotRemovable;
		public const int HostSettingsCacheTimeOut = 20;
		public const string PortalAliasCacheKey = "PortalAlias";
		public const CacheItemPriority PortalAliasCachePriority = CacheItemPriority.NotRemovable;
		public const int PortalAliasCacheTimeOut = 200;
		public const string PortalSettingsCacheKey = "PortalSettings{0}";
		public const CacheItemPriority PortalSettingsCachePriority = CacheItemPriority.NotRemovable;
		public const int PortalSettingsCacheTimeOut = 20;
		public const string PortalDictionaryCacheKey = "PortalDictionary";
		public const CacheItemPriority PortalDictionaryCachePriority = CacheItemPriority.High;
		public const int PortalDictionaryTimeOut = 20;
		public const string PortalCacheKey = "Portal{0}_{1}";
		public const CacheItemPriority PortalCachePriority = CacheItemPriority.High;
		public const int PortalCacheTimeOut = 20;
		public const string TabCacheKey = "Tab_Tabs{0}";
		public const CacheItemPriority TabCachePriority = CacheItemPriority.High;
		public const int TabCacheTimeOut = 20;
		public const string TabPathCacheKey = "Tab_TabPathDictionary{0}_{1}";
		public const CacheItemPriority TabPathCachePriority = CacheItemPriority.High;
		public const int TabPathCacheTimeOut = 20;
		public const string TabPermissionCacheKey = "Tab_TabPermissions{0}";
		public const CacheItemPriority TabPermissionCachePriority = CacheItemPriority.High;
		public const int TabPermissionCacheTimeOut = 20;
		public const string AuthenticationServicesCacheKey = "AuthenticationServices";
		public const CacheItemPriority AuthenticationServicesCachePriority = CacheItemPriority.NotRemovable;
		public const int AuthenticationServicesCacheTimeOut = 20;
		public const string DesktopModulePermissionCacheKey = "DesktopModulePermissions";
		public const CacheItemPriority DesktopModulePermissionCachePriority = CacheItemPriority.High;
		public const int DesktopModulePermissionCacheTimeOut = 20;
		public const string DesktopModuleCacheKey = "DesktopModulesByPortal{0}";
		public const CacheItemPriority DesktopModuleCachePriority = CacheItemPriority.High;
		public const int DesktopModuleCacheTimeOut = 20;
		public const string PortalDesktopModuleCacheKey = "PortalDesktopModules{0}";
		public const CacheItemPriority PortalDesktopModuleCachePriority = CacheItemPriority.AboveNormal;
		public const int PortalDesktopModuleCacheTimeOut = 20;
		public const string ModuleDefinitionCacheKey = "ModuleDefinitions";
		public const CacheItemPriority ModuleDefinitionCachePriority = CacheItemPriority.High;
		public const int ModuleDefinitionCacheTimeOut = 20;
		public const string ModuleControlsCacheKey = "ModuleControls";
		public const CacheItemPriority ModuleControlsCachePriority = CacheItemPriority.High;
		public const int ModuleControlsCacheTimeOut = 20;
		public const string TabModuleCacheKey = "TabModules{0}";
		public const CacheItemPriority TabModuleCachePriority = CacheItemPriority.AboveNormal;
		public const int TabModuleCacheTimeOut = 20;
		public const string ModulePermissionCacheKey = "ModulePermissions{0}";
		public const CacheItemPriority ModulePermissionCachePriority = CacheItemPriority.AboveNormal;
		public const int ModulePermissionCacheTimeOut = 20;
		public const string ModuleCacheKey = "Modules{0}";
		public const int ModuleCacheTimeOut = 20;
		public const string FolderCacheKey = "Folders{0}";
		public const int FolderCacheTimeOut = 20;
		public const CacheItemPriority FolderCachePriority = CacheItemPriority.Normal;
		public const string FolderPermissionCacheKey = "FolderPermissions{0}";
		public const CacheItemPriority FolderPermissionCachePriority = CacheItemPriority.Normal;
		public const int FolderPermissionCacheTimeOut = 20;
		public const string ListsCacheKey = "Lists{0}";
		public const CacheItemPriority ListsCachePriority = CacheItemPriority.Normal;
		public const int ListsCacheTimeOut = 20;
		public const string ProfileDefinitionsCacheKey = "ProfileDefinitions{0}";
		public const int ProfileDefinitionsCacheTimeOut = 20;
		public const string UserCacheKey = "UserInfo|{0}|{1}";
		public const int UserCacheTimeOut = 1;
		public const CacheItemPriority UserCachePriority = CacheItemPriority.Normal;
		public const string LocalesCacheKey = "Locales{0}";
		public const CacheItemPriority LocalesCachePriority = CacheItemPriority.Normal;
		public const int LocalesCacheTimeOut = 20;
		public const string SkinDefaultsCacheKey = "SkinDefaults_{0}";
		public const CacheItemPriority SkinDefaultsCachePriority = CacheItemPriority.Normal;
		public const int SkinDefaultsCacheTimeOut = 20;
		public const CacheItemPriority ResourceFilesCachePriority = CacheItemPriority.Normal;
		public const int ResourceFilesCacheTimeOut = 20;
		public const string ResourceFileLookupDictionaryCacheKey = "ResourceFileLookupDictionary";
		public const CacheItemPriority ResourceFileLookupDictionaryCachePriority = CacheItemPriority.NotRemovable;
		public const int ResourceFileLookupDictionaryTimeOut = 200;
		public const string SkinsCacheKey = "GetSkins{0}";
		public const string BannersCacheKey = "Banners:{0}:{1}:{2}";
		public const CacheItemPriority BannersCachePriority = CacheItemPriority.Normal;
		public const int BannersCacheTimeOut = 20;
		public static bool CachePersistenceEnabled {
			get {
				if (string.IsNullOrEmpty(_CachePersistenceEnabled)) {
					if (Config.GetSetting("EnableCachePersistence") == null) {
						_CachePersistenceEnabled = "false";
					} else {
						_CachePersistenceEnabled = Config.GetSetting("EnableCachePersistence");
					}
				}
				return bool.Parse(_CachePersistenceEnabled);
			}
		}
		private static string GetDnnCacheKey(string CacheKey)
		{
			return CachingProvider.GetCacheKey(CacheKey);
		}
		private static string CleanCacheKey(string CacheKey)
		{
			return CachingProvider.CleanCacheKey(CacheKey);
        }
		static internal void ItemRemovedCallback(string key, object value, CacheItemRemovedReason removedReason)
		{
			try {
				if (Globals.Status == Globals.UpgradeStatus.None) {
					LogInfo objEventLogInfo = new LogInfo();
					switch (removedReason) {
						case CacheItemRemovedReason.Removed:
							objEventLogInfo.LogTypeKey = EventLogController.EventLogType.CACHE_REMOVED.ToString();
							break;
						case CacheItemRemovedReason.Expired:
							objEventLogInfo.LogTypeKey = EventLogController.EventLogType.CACHE_EXPIRED.ToString();
							break;
						case CacheItemRemovedReason.Underused:
							objEventLogInfo.LogTypeKey = EventLogController.EventLogType.CACHE_UNDERUSED.ToString();
							break;
						case CacheItemRemovedReason.DependencyChanged:
							objEventLogInfo.LogTypeKey = EventLogController.EventLogType.CACHE_DEPENDENCYCHANGED.ToString();
							break;
					}
					objEventLogInfo.LogProperties.Add(new LogDetailInfo(key, removedReason.ToString()));
					EventLogController objEventLog = new EventLogController();
					objEventLog.AddLog(objEventLogInfo);
				}
			} catch (Exception ex) {
			}
		}
		public static void ClearCache()
		{
			CachingProvider.Instance().Clear("Prefix", "DNN_");
            using (ISharedCollectionLock writeLock = dictionaryCache.GetWriteLock())
            {
                dictionaryCache.Clear();
            }
		    LogInfo objEventLogInfo = new LogInfo();
			objEventLogInfo.LogTypeKey = EventLogController.EventLogType.CACHE_REFRESH.ToString();
			objEventLogInfo.LogProperties.Add(new LogDetailInfo("*", "Refresh"));
			EventLogController objEventLog = new EventLogController();
			objEventLog.AddLog(objEventLogInfo);
		}
		public static void ClearCache(string cachePrefix)
		{
			CachingProvider.Instance().Clear("Prefix", GetDnnCacheKey(cachePrefix));
		}
		public static void ClearFolderCache(int PortalId)
		{
			CachingProvider.Instance().Clear("Folder", PortalId.ToString());
		}
		public static void ClearHostCache(bool Cascade)
		{
			if (Cascade) {
				ClearCache();
			} else {
				CachingProvider.Instance().Clear("Host", "");
			}
		}
		public static void ClearModuleCache(int TabId)
		{
			CachingProvider.Instance().Clear("Module", TabId.ToString());
			Dictionary<int, int> portals = PortalController.GetPortalDictionary();
			if (portals.ContainsKey(TabId)) {
                TabController tabController = new TabController();
                Hashtable tabSettings = null;

                tabSettings = tabController.GetTabSettings(TabId);
                if (tabSettings["CacheProvider"] != null && tabSettings["CacheProvider"].ToString().Length > 0)
                {
                    OutputCachingProvider outputProvider = OutputCachingProvider.Instance(tabSettings["CacheProvider"].ToString());
                    if (outputProvider != null)
                    {
                        outputProvider.Remove(TabId);
                    }
                }

			}
		}
		public static void ClearModulePermissionsCachesByPortal(int PortalId)
		{
			CachingProvider.Instance().Clear("ModulePermissionsByPortal", PortalId.ToString());
		}
		public static void ClearPortalCache(int PortalId, bool Cascade)
		{
			if (Cascade) {
				CachingProvider.Instance().Clear("PortalCascade", PortalId.ToString());
			} else {
				CachingProvider.Instance().Clear("Portal", PortalId.ToString());
			}
		}
		public static void ClearTabsCache(int PortalId)
		{
			CachingProvider.Instance().Clear("Tab", PortalId.ToString());
		}
		public static void ClearDefinitionsCache(int PortalId)
		{
			RemoveCache(string.Format(ProfileDefinitionsCacheKey, PortalId));
		}
		public static void ClearDesktopModulePermissionsCache()
		{
			RemoveCache(DesktopModulePermissionCacheKey);
		}
		public static void ClearFolderPermissionsCache(int PortalId)
		{
			RemoveCache(string.Format(FolderPermissionCacheKey, PortalId));
		}
		public static void ClearListsCache(int PortalId)
		{
			RemoveCache(string.Format(ListsCacheKey, PortalId));
		}
		public static void ClearModulePermissionsCache(int TabId)
		{
			RemoveCache(string.Format(ModulePermissionCacheKey, TabId));
		}
		public static void ClearTabPermissionsCache(int PortalId)
		{
			RemoveCache(string.Format(TabPermissionCacheKey, PortalId));
		}
		public static void ClearUserCache(int PortalId, string username)
		{
			RemoveCache(string.Format(UserCacheKey, PortalId, username));
		}

        private static object GetCachedDataFromRuntimeCache(CacheItemArgs cacheItemArgs, CacheItemExpiredCallback cacheItemExpired)
        {
            object objObject = GetCache(cacheItemArgs.CacheKey);

            // if item is not cached
            if (objObject == null)
            {
                //Get Unique Lock for cacheKey
                object @lock = GetUniqueLockObject(cacheItemArgs.CacheKey);

                // prevent other threads from entering this block while we regenerate the cache
                lock (@lock)
                {
                    // try to retrieve object from the cache again (in case another thread loaded the object since we first checked)
                    objObject = GetCache(cacheItemArgs.CacheKey);

                    // if object was still not retrieved

                    if (objObject == null)
                    {
                        // get object from data source using delegate
                        try
                        {
                            objObject = cacheItemExpired(cacheItemArgs);
                        }
                        catch (Exception ex)
                        {
                            objObject = null;
                            Exceptions.LogException(ex);
                        }

                        // set cache timeout
                        int timeOut = cacheItemArgs.CacheTimeOut * Convert.ToInt32(Host.PerformanceSetting);

                        // if we retrieved a valid object and we are using caching
                        if (objObject != null && timeOut > 0)
                        {
                            // save the object in the cache
                            DataCache.SetCache(cacheItemArgs.CacheKey, objObject, cacheItemArgs.CacheDependency, Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(timeOut), cacheItemArgs.CachePriority, cacheItemArgs.CacheCallback);

                            // check if the item was actually saved in the cache

                            if (DataCache.GetCache(cacheItemArgs.CacheKey) == null)
                            {
                                // log the event if the item was not saved in the cache ( likely because we are out of memory )
                                LogInfo objEventLogInfo = new LogInfo();
                                objEventLogInfo.LogTypeKey = EventLogController.EventLogType.CACHE_OVERFLOW.ToString();
                                objEventLogInfo.LogProperties.Add(new LogDetailInfo(cacheItemArgs.CacheKey, "Overflow - Item Not Cached"));
                                EventLogController objEventLog = new EventLogController();
                                objEventLog.AddLog(objEventLogInfo);
                            }
                        }

                        //This thread won so remove unique Lock from collection
                        RemoveUniqueLockObject(cacheItemArgs.CacheKey);
                    }
                }
            }

            return objObject;
        }

        private static object GetCachedDataFromDictionary(CacheItemArgs cacheItemArgs, CacheItemExpiredCallback cacheItemExpired)
        {
            object objObject = null;

            bool idFound = Null.NullBoolean;
            using (ISharedCollectionLock readLock = dictionaryCache.GetReadLock())
            {
                if (dictionaryCache.ContainsKey(cacheItemArgs.CacheKey))
                {
                    //Return value
                    objObject = dictionaryCache[cacheItemArgs.CacheKey];
                    idFound = true;
                }
            }

            if (!idFound)
            {
                // get object from data source using delegate
                try
                {
                    objObject = cacheItemExpired(cacheItemArgs);
                }
                catch (Exception ex)
                {
                    objObject = null;
                    Exceptions.LogException(ex);
                }

                using (ISharedCollectionLock writeLock = dictionaryCache.GetWriteLock())
                {
                    if (!dictionaryCache.ContainsKey(cacheItemArgs.CacheKey))
                    {
                        if (objObject != null)
                        {
                            dictionaryCache[cacheItemArgs.CacheKey] = objObject;
                        }
                    }
                }
            }

            return objObject;
        }

        public static TObject GetCachedData<TObject>(CacheItemArgs cacheItemArgs, CacheItemExpiredCallback cacheItemExpired)
        {
            // declare local object and try and retrieve item from the cache
            return GetCachedData<TObject>(cacheItemArgs, cacheItemExpired, false);
        }

        static internal TObject GetCachedData<TObject>(CacheItemArgs cacheItemArgs, CacheItemExpiredCallback cacheItemExpired, bool storeInDictionary)
        {
            object objObject = null;

            if (storeInDictionary)
            {
                //Use Thread Safe SharedDictionary
                objObject = GetCachedDataFromDictionary(cacheItemArgs, cacheItemExpired);
            }
            else
            {
                //Use Cache
                objObject = GetCachedDataFromRuntimeCache(cacheItemArgs, cacheItemExpired);
            }

            // return the object
            if (objObject == null)
            {
                return default(TObject);
            }
            else
            {
                return (TObject)objObject;
            }

        }

		private static object GetUniqueLockObject(string key)
		{
			object @lock = null;
			dictionaryLock.AcquireReaderLock(new TimeSpan(0, 0, 5));
			try {
				if (lockDictionary.ContainsKey(key)) {
					@lock = lockDictionary[key];
				}
			} finally {
				dictionaryLock.ReleaseReaderLock();
			}
			if (@lock == null) {
				dictionaryLock.AcquireWriterLock(new TimeSpan(0, 0, 5));
				try {
					if (!lockDictionary.ContainsKey(key)) {
						lockDictionary[key] = new object();
					}
					@lock = lockDictionary[key];
				} finally {
					dictionaryLock.ReleaseWriterLock();
				}
			}
			return @lock;
		}
		private static void RemoveUniqueLockObject(string key)
		{
			dictionaryLock.AcquireWriterLock(new TimeSpan(0, 0, 5));
			try {
				if (lockDictionary.ContainsKey(key)) {
					lockDictionary.Remove(key);
				}
			} finally {
				dictionaryLock.ReleaseWriterLock();
			}
		}
		public static TObject GetCache<TObject>(string CacheKey)
		{
			object objObject = GetCache(CacheKey);
			if (objObject == null) {
				return default(TObject);
			}
			return (TObject)objObject;
		}
		public static object GetCache(string CacheKey)
		{
			return CachingProvider.Instance().GetItem(GetDnnCacheKey(CacheKey));
		}
		public static void RemoveCache(string CacheKey)
		{
			CachingProvider.Instance().Remove(GetDnnCacheKey(CacheKey));
		}
		public static void RemoveFromPrivateDictionary(string DnnCacheKey)
		{
            using (ISharedCollectionLock writeLock = dictionaryCache.GetWriteLock())
            {
                dictionaryCache.Remove(CleanCacheKey(DnnCacheKey));
            }
		}
		public static void SetCache(string CacheKey, object objObject)
		{
			DNNCacheDependency objDependency = null;
			SetCache(CacheKey, objObject, objDependency, Cache.NoAbsoluteExpiration, Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
		}
		public static void SetCache(string CacheKey, object objObject, DNNCacheDependency objDependency)
		{
			SetCache(CacheKey, objObject, objDependency, Cache.NoAbsoluteExpiration, Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
		}
		public static void SetCache(string CacheKey, object objObject, System.DateTime AbsoluteExpiration)
		{
			DNNCacheDependency objDependency = null;
			SetCache(CacheKey, objObject, objDependency, AbsoluteExpiration, Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
		}
		public static void SetCache(string CacheKey, object objObject, TimeSpan SlidingExpiration)
		{
			DNNCacheDependency objDependency = null;
			SetCache(CacheKey, objObject, objDependency, Cache.NoAbsoluteExpiration, SlidingExpiration, CacheItemPriority.Normal, null);
		}
		public static void SetCache(string CacheKey, object objObject, DNNCacheDependency objDependency, System.DateTime AbsoluteExpiration, System.TimeSpan SlidingExpiration)
		{
			SetCache(CacheKey, objObject, objDependency, AbsoluteExpiration, SlidingExpiration, CacheItemPriority.Normal, null);
		}
		public static void SetCache(string CacheKey, object objObject, DNNCacheDependency objDependency, System.DateTime AbsoluteExpiration, System.TimeSpan SlidingExpiration, CacheItemPriority Priority, CacheItemRemovedCallback OnRemoveCallback)
		{
			if (objObject != null) {
				if (OnRemoveCallback == null) {
					OnRemoveCallback = ItemRemovedCallback;
				}
				CachingProvider.Instance().Insert(GetDnnCacheKey(CacheKey), objObject, objDependency, AbsoluteExpiration, SlidingExpiration, Priority, OnRemoveCallback);
			}
		}

		#region "Obsolete Methods"

		[Obsolete("Deprecated in DNN 5.0 - Replace by ClearHostCache(True)")]
		public static void ClearModuleCache()
		{
			ClearHostCache(true);
		}

		[Obsolete("Deprecated in DNN 5.1 - Cache Persistence is not supported")]
		public static object GetPersistentCacheItem(string CacheKey, Type objType)
		{
			return CachingProvider.Instance().GetItem(GetDnnCacheKey(CacheKey));
		}

		[Obsolete("Deprecated in DNN 5.1.1 - Should have been declared Friend")]
		public static void ClearDesktopModuleCache(int PortalId)
		{
			RemoveCache(string.Format(DesktopModuleCacheKey, PortalId.ToString()));
			RemoveCache(ModuleDefinitionCacheKey);
			RemoveCache(ModuleControlsCacheKey);
		}

		[Obsolete("Deprecated in DNN 5.1.1 - Should have been declared Friend")]
		public static void ClearHostSettingsCache()
		{
			RemoveCache(HostSettingsCacheKey);
			RemoveCache(SecureHostSettingsCacheKey);
		}

		[Obsolete("Deprecated in DNN 5.1 - Cache Persistence is not supported")]
		public static void RemovePersistentCacheItem(string CacheKey)
		{
			CachingProvider.Instance().Remove(GetDnnCacheKey(CacheKey));
		}

		[Obsolete("Deprecated in DNN 5.1 - Cache Persistence is not supported")]
		public static void SetCache(string CacheKey, object objObject, bool PersistAppRestart)
		{
			DNNCacheDependency objDependency = null;
			SetCache(CacheKey, objObject, objDependency, Cache.NoAbsoluteExpiration, Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
		}

		[Obsolete("Deprecated in DNN 5.1 - Cache Persistence is not supported")]
		public static void SetCache(string CacheKey, object objObject, System.Web.Caching.CacheDependency objDependency, bool PersistAppRestart)
		{
			SetCache(CacheKey, objObject, new DNNCacheDependency(objDependency), Cache.NoAbsoluteExpiration, Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
		}

		[Obsolete("Deprecated in DNN 5.1 - Cache Persistence is not supported")]
		public static void SetCache(string CacheKey, object objObject, System.DateTime AbsoluteExpiration, bool PersistAppRestart)
		{
			DNNCacheDependency objDependency = null;
			SetCache(CacheKey, objObject, objDependency, AbsoluteExpiration, Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
		}

		[Obsolete("Deprecated in DNN 5.1 - Cache Persistence is not supported")]
		public static void SetCache(string CacheKey, object objObject, TimeSpan SlidingExpiration, bool PersistAppRestart)
		{
			DNNCacheDependency objDependency = null;
			SetCache(CacheKey, objObject, objDependency, Cache.NoAbsoluteExpiration, SlidingExpiration, CacheItemPriority.Normal, null);
		}

		[Obsolete("Deprecated in DNN 5.1 - SetCache(ByVal CacheKey As String, ByVal objObject As Object, ByVal objDependency As DotNetNuke.Services.Cache.DNNCacheDependency, ByVal AbsoluteExpiration As Date, ByVal SlidingExpiration As System.TimeSpan)")]
		public static void SetCache(string CacheKey, object objObject, System.Web.Caching.CacheDependency objDependency, System.DateTime AbsoluteExpiration, System.TimeSpan SlidingExpiration, bool PersistAppRestart)
		{
			SetCache(CacheKey, objObject, new DNNCacheDependency(objDependency), AbsoluteExpiration, SlidingExpiration, CacheItemPriority.Normal, null);
		}

		[Obsolete("Deprecated in DNN 5.1 - SetCache(ByVal CacheKey As String, ByVal objObject As Object, ByVal objDependency As DotNetNuke.Services.Cache.DNNCacheDependency, ByVal AbsoluteExpiration As Date, ByVal SlidingExpiration As System.TimeSpan, ByVal Priority As CacheItemPriority, ByVal OnRemoveCallback As CacheItemRemovedCallback)")]
		public static void SetCache(string CacheKey, object objObject, System.Web.Caching.CacheDependency objDependency, System.DateTime AbsoluteExpiration, System.TimeSpan SlidingExpiration, CacheItemPriority Priority, CacheItemRemovedCallback OnRemoveCallback, bool PersistAppRestart)
		{
			SetCache(CacheKey, objObject, new DNNCacheDependency(objDependency), AbsoluteExpiration, SlidingExpiration, Priority, OnRemoveCallback);
		}

		[Obsolete("Deprecated in DNN 5.1 - Use new overload that uses a DNNCacheDependency")]
		public static void SetCache(string CacheKey, object objObject, CacheDependency objDependency)
		{
			SetCache(CacheKey, objObject, new DNNCacheDependency(objDependency), Cache.NoAbsoluteExpiration, Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
		}

		[Obsolete("Deprecated in DNN 5.1 - Use new overload that uses a DNNCacheDependency")]
		public static void SetCache(string CacheKey, object objObject, CacheDependency objDependency, System.DateTime AbsoluteExpiration, System.TimeSpan SlidingExpiration)
		{
			SetCache(CacheKey, objObject, new DNNCacheDependency(objDependency), AbsoluteExpiration, SlidingExpiration, CacheItemPriority.Normal, null);
		}

		[Obsolete("Deprecated in DNN 5.1 - Use new overload that uses a DNNCacheDependency")]
		public static void SetCache(string CacheKey, object objObject, CacheDependency objDependency, System.DateTime AbsoluteExpiration, System.TimeSpan SlidingExpiration, CacheItemPriority Priority, CacheItemRemovedCallback OnRemoveCallback)
		{
			SetCache(CacheKey, objObject, new DNNCacheDependency(objDependency), AbsoluteExpiration, SlidingExpiration, Priority, OnRemoveCallback);
		}

		#endregion
	}
}
