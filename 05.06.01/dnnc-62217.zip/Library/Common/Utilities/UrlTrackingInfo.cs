//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

namespace DotNetNuke.Common.Utilities
{
	public class UrlTrackingInfo
	{
		private int _UrlTrackingID;
		private int _PortalID;
		private string _Url;
		private string _UrlType;
		private int _Clicks;
		private System.DateTime _LastClick;
		private System.DateTime _CreatedDate;
		private bool _LogActivity;
		private bool _TrackClicks;
		private int _ModuleID;
		private bool _NewWindow;
		public UrlTrackingInfo()
		{
		}
		public int UrlTrackingID {
			get { return _UrlTrackingID; }
			set { _UrlTrackingID= value; }
		}
		public int PortalID {
			get { return _PortalID; }
			set { _PortalID= value; }
		}
		public string Url {
			get { return _Url; }
			set { _Url= value; }
		}
		public string UrlType {
			get { return _UrlType; }
			set { _UrlType= value; }
		}
		public int Clicks {
			get { return _Clicks; }
			set { _Clicks= value; }
		}
		public System.DateTime LastClick {
			get { return _LastClick; }
			set { _LastClick= value; }
		}
		public System.DateTime CreatedDate {
			get { return _CreatedDate; }
			set { _CreatedDate= value; }
		}
		public bool LogActivity {
			get { return _LogActivity; }
			set { _LogActivity= value; }
		}
		public bool TrackClicks {
			get { return _TrackClicks; }
			set { _TrackClicks= value; }
		}
		public int ModuleID {
			get { return _ModuleID; }
			set { _ModuleID= value; }
		}
		public bool NewWindow {
			get { return _NewWindow; }
			set { _NewWindow= value; }
		}
	}
}
