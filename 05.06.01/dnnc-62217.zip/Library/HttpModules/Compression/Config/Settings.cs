//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections.Specialized;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml.XPath;
using DotNetNuke.Common;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Host;
using DotNetNuke.Services.Cache;
namespace DotNetNuke.HttpModules.Compression
{
	[Serializable()]
	public class Settings
	{
		private Algorithms _preferredAlgorithm;
		private StringCollection _excludedPaths;
		private Regex _reg;
		private bool _whitespace;
		private Settings()
		{
			_preferredAlgorithm = Algorithms.None;
			_excludedPaths = new StringCollection();
			_whitespace = false;
		}
		public static Settings Default {
			get { return new Settings(); }
		}
		public Algorithms PreferredAlgorithm {
			get { return _preferredAlgorithm; }
		}
		public Regex Reg {
			get { return _reg; }
		}
		public bool Whitespace {
			get { return _whitespace; }
		}
		public static Settings GetSettings()
		{
			Settings _Settings = (Settings)DataCache.GetCache("CompressionConfig");
			if (_Settings == null) {
				_Settings = Settings.Default;
				try {
					_Settings._preferredAlgorithm = (Algorithms)Host.HttpCompressionAlgorithm;
					_Settings._whitespace = Host.WhitespaceFilter;
				} catch (Exception e) {
				}
				string filePath = Globals.ApplicationMapPath + "\\Compression.config";
				if (!File.Exists(filePath)) {
					if (File.Exists(Globals.ApplicationMapPath + Globals.glbConfigFolder + "Compression.config")) {
						File.Copy(Globals.ApplicationMapPath + Globals.glbConfigFolder + "Compression.config", Globals.ApplicationMapPath + "\\Compression.config", true);
					}
				}
				FileStream fileReader = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read);
				XPathDocument doc = new XPathDocument(fileReader);
				_Settings._reg = new Regex(doc.CreateNavigator().SelectSingleNode("compression/whitespace").Value);
				foreach (XPathNavigator nav in doc.CreateNavigator().Select("compression/excludedPaths/path")) {
					_Settings._excludedPaths.Add(nav.Value.ToLower());
				}
				if ((File.Exists(filePath))) {
					DataCache.SetCache("CompressionConfig", _Settings, new DNNCacheDependency(filePath));
				}
			}
			return _Settings;
		}
		public bool IsExcludedPath(string relUrl)
		{
			bool Match = false;
			foreach (string path in _excludedPaths) {
				if (relUrl.ToLower().Contains(path)) {
					Match = true;
					break;
				}
			}
			return Match;
		}
	}
}
