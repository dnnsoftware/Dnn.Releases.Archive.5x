using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using DotNetNuke.Collections;

namespace DotNetNuke.ComponentModel
{

    public class SimpleContainer : AbstractContainer
    {

        private ComponentBuilderCollection componentBuilders = new ComponentBuilderCollection();
        private SharedDictionary<string, IDictionary> componentDependencies = new SharedDictionary<string, IDictionary>();
        private ComponentTypeCollection componentTypes = new ComponentTypeCollection();

        private SharedDictionary<System.Type, string> registeredComponents = new SharedDictionary<System.Type, string>();

        private string _Name;
        #region "Constructors"

        /// <summary>
        /// Initializes a new instance of the SimpleContainer class.
        /// </summary>
        public SimpleContainer()
            : this(string.Format("Container_{0}", Guid.NewGuid().ToString()))
        {
        }

        /// <summary>
        /// Initializes a new instance of the SimpleContainer class.
        /// </summary>
        /// <param name="name"></param>
        public SimpleContainer(string name)
        {
            _Name = name;
        }

        #endregion

        #region "Private Methods"

        private void AddBuilder(System.Type contractType, IComponentBuilder builder)
        {
            ComponentType componentType = GetComponentType(contractType);
            if (componentType != null)
            {
                ComponentBuilderCollection builders = componentType.ComponentBuilders;

                using (ISharedCollectionLock writeLock = builders.GetWriteLock())
                {
                    builders.AddBuilder(builder, true);
                }

                using (ISharedCollectionLock writeLock = componentBuilders.GetWriteLock())
                {
                    componentBuilders.AddBuilder(builder, false);
                }
            }

        }

        private void AddComponentType(System.Type contractType)
        {
            ComponentType componentType = GetComponentType(contractType);

            if (componentType == null)
            {
                componentType = new ComponentType(contractType);

                using (ISharedCollectionLock writeLock = componentTypes.GetWriteLock())
                {
                    componentTypes[componentType.BaseType] = componentType;
                }
            }
        }

        private object GetComponent(IComponentBuilder builder)
        {
            object component = null;
            if (builder == null)
            {
                component = null;
            }
            else
            {
                component = builder.BuildComponent();
            }
            return component;
        }

        private IComponentBuilder GetComponentBuilder(string name)
        {
            IComponentBuilder builder = null;

            using (ISharedCollectionLock writeLock = componentBuilders.GetReadLock())
            {
                componentBuilders.TryGetValue(name, out builder);
            }

            return builder;
        }

        private IComponentBuilder GetDefaultComponentBuilder(ComponentType componentType)
        {
            IComponentBuilder builder = null;

            using (ISharedCollectionLock writeLock = componentType.ComponentBuilders.GetReadLock())
            {
                builder = componentType.ComponentBuilders.DefaultBuilder;
            }

            return builder;
        }

        private ComponentType GetComponentType(System.Type contractType)
        {
            ComponentType componentType = null;

            using (ISharedCollectionLock writeLock = componentTypes.GetReadLock())
            {
                componentTypes.TryGetValue(contractType, out componentType);
            }

            return componentType;
        }

        private void RegisterComponent(string name, System.Type type)
        {
            using (ISharedCollectionLock writeLock = registeredComponents.GetWriteLock())
            {
                registeredComponents[type] = name;
            }
        }

        #endregion

        public override object GetComponent(string name)
        {
            IComponentBuilder builder = GetComponentBuilder(name);

            return GetComponent(builder);
        }

        public override object GetComponent(System.Type contractType)
        {
            ComponentType componentType = GetComponentType(contractType);
            object component = null;

            if (componentType != null)
            {
                int builderCount = 0;

                using (ISharedCollectionLock readLock = componentType.ComponentBuilders.GetReadLock())
                {
                    builderCount = componentType.ComponentBuilders.Count;
                }

                if (builderCount > 0)
                {
                    IComponentBuilder builder = GetDefaultComponentBuilder(componentType);

                    component = GetComponent(builder);
                }
            }

            return component;
        }

        public override object GetComponent(string name, System.Type contractType)
        {
            ComponentType componentType = GetComponentType(contractType);
            object component = null;

            if (componentType != null)
            {
                IComponentBuilder builder = GetComponentBuilder(name);

                component = GetComponent(builder);
            }
            return component;
        }

        public override string[] GetComponentList(System.Type contractType)
        {
            List<string> components = new List<string>();

            using (ISharedCollectionLock readLock = registeredComponents.GetReadLock())
            {
                foreach (KeyValuePair<Type, string> kvp in registeredComponents)
                {
                    if (object.ReferenceEquals(kvp.Key.BaseType, contractType))
                    {
                        components.Add(kvp.Value);
                    }
                }
            }
            return components.ToArray();
        }

        public override System.Collections.IDictionary GetComponentSettings(string name)
        {
            IDictionary settings = null;
            using (ISharedCollectionLock readLock = componentDependencies.GetReadLock())
            {
                settings = componentDependencies[name];
            }
            return settings;
        }

        public override string Name
        {
            get { return _Name; }
        }

        public override void RegisterComponent(string name, System.Type contractType, System.Type type, ComponentLifeStyleType lifestyle)
        {
            AddComponentType(contractType);

            IComponentBuilder builder = null;
            switch (lifestyle)
            {
                case ComponentLifeStyleType.Transient:
                    builder = new TransientComponentBuilder(name, type);
                    break;
                case ComponentLifeStyleType.Singleton:
                    builder = new SingletonComponentBuilder(name, type);
                    break;
            }
            AddBuilder(contractType, builder);

            RegisterComponent(name, type);
        }

        public override void RegisterComponentInstance(string name, System.Type contractType, object instance)
        {
            AddComponentType(contractType);

            AddBuilder(contractType, new InstanceComponentBuilder(name, instance));
        }

        public override void RegisterComponentSettings(string name, System.Collections.IDictionary dependencies)
        {
            using (ISharedCollectionLock writeLock = componentDependencies.GetWriteLock())
            {
                componentDependencies[name] = dependencies;
            }
        }

    }

}
