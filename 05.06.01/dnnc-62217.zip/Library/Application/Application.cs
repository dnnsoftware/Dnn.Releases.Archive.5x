//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Reflection;
namespace DotNetNuke.Application
{
	public class Application
	{
		private static ReleaseMode _status = ReleaseMode.None;
		protected internal Application()
		{
		}
		public string Company
		{
			get { return "DotNetNuke Corporation"; }
		}
		public virtual string Description
		{
			get { return "DotNetNuke Community Edition"; }
		}
		public string HelpUrl
		{
			get { return "http://www.dotnetnuke.com/default.aspx?tabid=787"; }
		}
		public string LegalCopyright
		{
			get { return "DotNetNuke® is copyright 2002-" + DateTime.Today.ToString("yyyy") + " by DotNetNuke Corporation"; }
		}
		public virtual string Name
		{
			get { return "DNNCORP.CE"; }
		}
		public virtual string SKU
		{
			get { return "DNN"; }
		}
		public ReleaseMode Status
		{
			get
			{
				if (_status == ReleaseMode.None)
				{
					Assembly assy = System.Reflection.Assembly.GetExecutingAssembly();
					if (Attribute.IsDefined(assy, typeof(AssemblyStatusAttribute)))
					{
						Attribute attr = Attribute.GetCustomAttribute(assy, typeof(AssemblyStatusAttribute));
						if (attr != null)
						{
							_status = ((AssemblyStatusAttribute)attr).Status;
						}
					}
				}
				return _status;
			}
		}
		public string Title
		{
			get { return "DotNetNuke"; }
		}
		public string Trademark
		{
			get { return "DotNetNuke,DNN"; }
		}
		public string Type
		{
			get { return "Framework"; }
		}
		public string UpgradeUrl
		{
			get { return "http://update.dotnetnuke.com"; }
		}
		public string Url
		{
			get { return "http://www.dotnetnuke.com"; }
		}
		public System.Version Version
		{
			get { return System.Reflection.Assembly.GetExecutingAssembly().GetName().Version; }
		}

        #region "Public Functions"
        /// <summary>
        /// Determine whether a product specific change is to be applied
        /// </summary>
        /// <param name="productNames">list of product names</param>
        /// <returns>true if product is within list of names</returns>
        /// <remarks></remarks>
        public virtual bool ApplyToProduct(string productNames)
        {
            return productNames.Contains(this.Name);
        }

        #endregion

	}
}
