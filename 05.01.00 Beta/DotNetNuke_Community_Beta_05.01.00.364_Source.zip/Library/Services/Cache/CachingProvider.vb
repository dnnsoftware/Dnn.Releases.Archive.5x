'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2009
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Web.Caching

Namespace DotNetNuke.Services.Cache

    Public MustInherit Class CachingProvider

#Region "Private Members"

        Private Shared _objCache As Caching.Cache

#End Region

#Region "Protected Properties"

        Protected Shared ReadOnly Property Cache() As System.Web.Caching.Cache
            Get
                'create singleton of the cache object
                If _objCache Is Nothing Then
                    _objCache = HttpRuntime.Cache
                End If
                Return _objCache
            End Get
        End Property

#End Region

#Region "Shared/Static Methods"

        Public Shared Function Instance() As CachingProvider
            Return DotNetNuke.ComponentModel.ComponentFactory.GetComponent(Of CachingProvider)()
        End Function

#End Region

#Region "Virtual Methods"

        Public Overridable Function Add(ByVal Key As String, ByVal Value As Object, ByVal Dependency As CacheDependency, ByVal AbsoluteExpiration As DateTime, ByVal SlidingExpiration As TimeSpan, ByVal Priority As CacheItemPriority, ByVal OnRemoveCallback As CacheItemRemovedCallback) As Object
            Dim retValue As Object = GetItem(Key)
            If retValue Is Nothing Then
                Cache.Insert(Key, Value, Dependency, AbsoluteExpiration, SlidingExpiration, Priority, OnRemoveCallback)
            End If
            Return retValue
        End Function

        Public Overridable Function GetEnumerator() As IDictionaryEnumerator
            Return Cache.GetEnumerator
        End Function

        Public Overridable Function GetItem(ByVal CacheKey As String) As Object
            Return Cache(CacheKey)
        End Function

        Public Overridable Overloads Sub Insert(ByVal CacheKey As String, ByVal objObject As Object)
            Insert(CacheKey, objObject, Nothing, Caching.Cache.NoAbsoluteExpiration, Caching.Cache.NoSlidingExpiration, CacheItemPriority.Default, Nothing)
        End Sub

        Public Overridable Overloads Sub Insert(ByVal CacheKey As String, ByVal objObject As Object, ByVal objDependency As CacheDependency)
            Insert(CacheKey, objObject, objDependency, Caching.Cache.NoAbsoluteExpiration, Caching.Cache.NoSlidingExpiration, CacheItemPriority.Default, Nothing)
        End Sub

        Public Overridable Overloads Sub Insert(ByVal CacheKey As String, ByVal objObject As Object, ByVal objDependency As CacheDependency, ByVal AbsoluteExpiration As Date, ByVal SlidingExpiration As System.TimeSpan)
            Insert(CacheKey, objObject, objDependency, AbsoluteExpiration, SlidingExpiration, CacheItemPriority.Default, Nothing)
        End Sub

        Public Overridable Overloads Sub Insert(ByVal Key As String, ByVal Value As Object, ByVal Dependency As CacheDependency, ByVal AbsoluteExpiration As Date, ByVal SlidingExpiration As System.TimeSpan, ByVal Priority As CacheItemPriority, ByVal OnRemoveCallback As CacheItemRemovedCallback)
            Cache.Insert(Key, Value, Dependency, AbsoluteExpiration, SlidingExpiration, Priority, OnRemoveCallback)
        End Sub

        Public Overridable Function PurgeCache() As String
            Return Localization.Localization.GetString("PurgeCacheUnsupported.Text", Localization.Localization.GlobalResourceFile)
        End Function

        Public Overridable Sub Remove(ByVal Key As String)
            ' remove item from memory
            If Not Cache(Key) Is Nothing Then
                Cache.Remove(Key)
            End If
        End Sub

        Public Overridable Sub RemovePersistentCacheItem(ByVal CacheKey As String)
            Remove(CacheKey)
        End Sub

#End Region

#Region "Obsolete Methods"

        <Obsolete("Deprecated in DNN 5.1 - Cache Persistence is not supported")> _
        Public Overridable Function GetPersistentCacheItem(ByVal CacheKey As String, ByVal objType As Type) As Object
            Return GetItem(CacheKey)
        End Function

        <Obsolete("Deprecated in DNN 5.1 - Cache Persistence is not supported")> _
        Public Overridable Overloads Sub Insert(ByVal CacheKey As String, ByVal objObject As Object, ByVal PersistAppRestart As Boolean)
            Insert(CacheKey, objObject, Nothing, Caching.Cache.NoAbsoluteExpiration, Caching.Cache.NoSlidingExpiration, CacheItemPriority.Default, Nothing)
        End Sub

        <Obsolete("Deprecated in DNN 5.1 - Cache Persistence is not supported")> _
        Public Overridable Overloads Sub Insert(ByVal CacheKey As String, ByVal objObject As Object, ByVal objDependency As CacheDependency, ByVal PersistAppRestart As Boolean)
            Insert(CacheKey, objObject, objDependency, Caching.Cache.NoAbsoluteExpiration, Caching.Cache.NoSlidingExpiration, CacheItemPriority.Default, Nothing)
        End Sub

        <Obsolete("Deprecated in DNN 5.1 - Cache Persistence is not supported")> _
        Public Overridable Overloads Sub Insert(ByVal CacheKey As String, ByVal objObject As Object, ByVal objDependency As CacheDependency, ByVal AbsoluteExpiration As Date, ByVal SlidingExpiration As System.TimeSpan, ByVal PersistAppRestart As Boolean)
            Insert(CacheKey, objObject, objDependency, AbsoluteExpiration, SlidingExpiration, CacheItemPriority.Default, Nothing)
        End Sub

        <Obsolete("Deprecated in DNN 5.1 - Cache Persistence is not supported")> _
        Public Overridable Overloads Sub Insert(ByVal Key As String, ByVal Value As Object, ByVal Dependency As CacheDependency, ByVal AbsoluteExpiration As Date, ByVal SlidingExpiration As System.TimeSpan, ByVal Priority As CacheItemPriority, ByVal OnRemoveCallback As CacheItemRemovedCallback, ByVal PersistAppRestart As Boolean)
            Cache.Insert(Key, Value, Dependency, AbsoluteExpiration, SlidingExpiration, Priority, OnRemoveCallback)
        End Sub

#End Region

    End Class

End Namespace
