'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2009
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke.Services.Installer.Dependencies

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The InvalidDependency signifies a dependency that is always invalid, 
    ''' taking the place of dependencies that could not be created
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[bdukes]	03/03/2009  created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class InvalidDependency
        Inherits DependencyBase

        Private _ErrorMessage As String

        ''' <summary>
        ''' Initializes a new instance of the <see cref="InvalidDependency" /> class.
        ''' </summary>
        ''' <param name="ErrorMessage">The error message to display.</param>
        Public Sub New(ByVal ErrorMessage As String)
            Me._ErrorMessage = ErrorMessage
        End Sub

        Public Overrides ReadOnly Property ErrorMessage() As String
            Get
                Return Me._ErrorMessage
            End Get
        End Property

        Public Overrides ReadOnly Property IsValid() As Boolean
            Get
                Return False
            End Get
        End Property
    End Class
End Namespace