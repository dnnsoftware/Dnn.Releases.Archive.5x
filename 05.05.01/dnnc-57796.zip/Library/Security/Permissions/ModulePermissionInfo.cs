//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Xml.Serialization;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Modules;
namespace DotNetNuke.Security.Permissions
{
	[Serializable()]
	public class ModulePermissionInfo : PermissionInfoBase, IHydratable
	{
		int _ModulePermissionID;
		int _ModuleID;
		public ModulePermissionInfo() : base()
		{
			_ModulePermissionID = Null.NullInteger;
			_ModuleID = Null.NullInteger;
		}
		public ModulePermissionInfo(PermissionInfo permission) : this()
		{
			this.ModuleDefID = permission.ModuleDefID;
			this.PermissionCode = permission.PermissionCode;
			this.PermissionID = permission.PermissionID;
			this.PermissionKey = permission.PermissionKey;
			this.PermissionName = permission.PermissionName;
		}
		[XmlElement("modulepermissionid")]
		public int ModulePermissionID {
			get { return _ModulePermissionID; }
			set { _ModulePermissionID= value; }
		}
		[XmlElement("moduleid")]
		public int ModuleID {
			get { return _ModuleID; }
			set { _ModuleID= value; }
		}
		public override bool Equals(object obj)
		{
			if (obj == null || !object.ReferenceEquals(this.GetType(), obj.GetType()))
			{
				return false;
			}
			ModulePermissionInfo perm = (ModulePermissionInfo)obj;
			return (this.AllowAccess == perm.AllowAccess) && (this.ModuleID == perm.ModuleID) && (this.RoleID == perm.RoleID) && (this.PermissionID == perm.PermissionID);
		}
		public void Fill(System.Data.IDataReader dr)
		{
			base.FillInternal(dr);
			ModulePermissionID = Null.SetNullInteger(dr["ModulePermissionID"]);
			ModuleID = Null.SetNullInteger(dr["ModuleID"]);
		}
		[XmlIgnore()]
		public int KeyID {
			get { return ModulePermissionID; }
			set { ModulePermissionID = value; }
		}
	}
}
