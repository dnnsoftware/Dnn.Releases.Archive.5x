//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Users;
using DotNetNuke.Security.Roles;
namespace DotNetNuke.Security.Permissions.Controls
{
	public class ModulePermissionsGrid : PermissionsGrid
	{
		private bool _InheritViewPermissionsFromTab = false;
		private int _ModuleID = -1;
		private ModulePermissionCollection _ModulePermissions;
		private List<PermissionInfoBase> _PermissionsList;
		private int _TabId = -1;
		private int _ViewColumnIndex;
		protected override List<PermissionInfoBase> PermissionsList {
			get {
				if (_PermissionsList == null && _ModulePermissions != null) {
					_PermissionsList = _ModulePermissions.ToList();
				}
				return _PermissionsList;
			}
		}
		public bool InheritViewPermissionsFromTab {
			get { return _InheritViewPermissionsFromTab; }
			set {
				_InheritViewPermissionsFromTab= value;
				_PermissionsList = null;
			}
		}
		public int ModuleID {
			get { return _ModuleID; }
			set {
				_ModuleID= value;
				if (!Page.IsPostBack) {
					GetModulePermissions();
				}
			}
		}
		public int TabId {
			get { return _TabId; }
			set { _TabId= value; }
		}
		public Security.Permissions.ModulePermissionCollection Permissions {
			get {
				UpdatePermissions();
				return _ModulePermissions;
			}
		}
		private void GetModulePermissions()
		{
			_ModulePermissions = new ModulePermissionCollection(ModulePermissionController.GetModulePermissions(this.ModuleID, this.TabId));
			_PermissionsList = null;
		}
		private ModulePermissionInfo ParseKeys(string[] Settings)
		{
			Security.Permissions.ModulePermissionInfo objModulePermission = new Security.Permissions.ModulePermissionInfo();
			base.ParsePermissionKeys(objModulePermission, Settings);
			if (String.IsNullOrEmpty(Settings[2])) {
				objModulePermission.ModulePermissionID = -1;
			} else {
				objModulePermission.ModulePermissionID = Convert.ToInt32(Settings[2]);
			}
			objModulePermission.ModuleID = ModuleID;
			return objModulePermission;
		}
		protected override void AddPermission(ArrayList permissions, UserInfo user)
		{
			bool isMatch = false;
			foreach (ModulePermissionInfo objModulePermission in _ModulePermissions) {
				if (objModulePermission.UserID == user.UserID) {
					isMatch = true;
					break;
				}
			}
			if (!isMatch) {
				foreach (PermissionInfo objPermission in permissions) {
					if (objPermission.PermissionKey == "VIEW") {
						AddPermission(objPermission, int.Parse(DotNetNuke.Common.Globals.glbRoleNothing), Null.NullString, user.UserID, user.DisplayName, true);
					}
				}
			}
		}
		protected override void AddPermission(PermissionInfo permission, int roleId, string roleName, int userId, string displayName, bool allowAccess)
		{
			ModulePermissionInfo objPermission = new ModulePermissionInfo(permission);
			objPermission.ModuleID = ModuleID;
			objPermission.RoleID = roleId;
			objPermission.RoleName = roleName;
			objPermission.AllowAccess = allowAccess;
			objPermission.UserID = userId;
			objPermission.DisplayName = displayName;
			_ModulePermissions.Add(objPermission, true);
			_PermissionsList = null;
		}
		protected override bool GetEnabled(PermissionInfo objPerm, RoleInfo role, int column)
		{
			bool enabled;
			if (InheritViewPermissionsFromTab && column == _ViewColumnIndex) {
				enabled = false;
			} else {
				if (role.RoleID == AdministratorRoleId) {
					enabled = false;
				} else {
					enabled = true;
				}
			}
			return enabled;
		}
		protected override bool GetEnabled(PermissionInfo objPerm, UserInfo user, int column)
		{
			return InheritViewPermissionsFromTab && column != _ViewColumnIndex;
		}
		protected override string GetPermission(PermissionInfo objPerm, RoleInfo role, int column, string defaultState)
		{
			string permission;
			if (InheritViewPermissionsFromTab && column == _ViewColumnIndex) {
				permission = PermissionTypeNull;
			} else {
				if (role.RoleID == AdministratorRoleId) {
					permission = PermissionTypeGrant;
				} else {
					permission = base.GetPermission(objPerm, role, column, defaultState);
				}
			}
			return permission;
		}
		protected override string GetPermission(PermissionInfo objPerm, UserInfo user, int column, string defaultState)
		{
			string permission;
			if (InheritViewPermissionsFromTab && column == _ViewColumnIndex) {
				permission = PermissionTypeNull;
			} else {
				permission = base.GetPermission(objPerm, user, column, defaultState);
			}
			return permission;
		}
		protected override ArrayList GetPermissions()
		{
			Security.Permissions.PermissionController objPermissionController = new Security.Permissions.PermissionController();
			ArrayList arrPermissions = objPermissionController.GetPermissionsByModuleID(this.ModuleID);
			int i;
			for (i = 0; i <= arrPermissions.Count - 1; i++) {
				Security.Permissions.PermissionInfo objPermission;
				objPermission = (Security.Permissions.PermissionInfo)arrPermissions[i];
				if (objPermission.PermissionKey == "VIEW") {
					_ViewColumnIndex = i + 1;
				}
			}
			return arrPermissions;
		}
		protected override void LoadViewState(object savedState)
		{
			if (savedState != null) {
				object[] myState = (object[])savedState;
				if (myState[0] != null)
				{
					base.LoadViewState(myState[0]);
				}
				if (myState[1] != null)
				{
					ModuleID = Convert.ToInt32(myState[1]);
				}
				if (myState[2] != null)
				{
					InheritViewPermissionsFromTab = Convert.ToBoolean(myState[2]);
				}
				if (myState[3] != null)
				{
					_ModulePermissions = new ModulePermissionCollection();
					string state = Convert.ToString(myState[3]);
					if (!String.IsNullOrEmpty(state)) {
						string[] permissionKeys = state.Split(new string[]{"##"}, StringSplitOptions.None);
						foreach (string key in permissionKeys) {
							string[] Settings = key.Split('|');
							_ModulePermissions.Add(ParseKeys(Settings));
						}
					}
				}
			}
		}
		protected override void RemovePermission(int permissionID, int roleID, int userID)
		{
			_ModulePermissions.Remove(permissionID, roleID, userID);
		}
		protected override object SaveViewState()
		{
			object[] allStates = new object[4];
			allStates[0] = base.SaveViewState();
			allStates[1] = ModuleID;
			allStates[2] = InheritViewPermissionsFromTab;
			StringBuilder sb = new StringBuilder();
			if (_ModulePermissions != null) {
				bool addDelimiter = false;
				foreach (ModulePermissionInfo objModulePermission in _ModulePermissions) {
					if (addDelimiter) {
						sb.Append("##");
					} else {
						addDelimiter = true;
					}
					sb.Append(BuildKey(objModulePermission.AllowAccess, objModulePermission.PermissionID, objModulePermission.ModulePermissionID, objModulePermission.RoleID, objModulePermission.RoleName, objModulePermission.UserID, objModulePermission.DisplayName));
				}
			}
			allStates[3] = sb.ToString();
			return allStates;
		}
		protected override bool SupportsDenyPermissions()
		{
			return true;
		}
		public override void GenerateDataGrid()
		{
		}
	}
}
