//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Security.Roles;
namespace DotNetNuke.Entities.Users
{
	[Serializable()]
	public class UserRoleInfo : RoleInfo
	{
		private int _UserRoleID;
		private int _UserID;
		private string _FullName;
		private string _Email;
		private System.DateTime _EffectiveDate;
		private System.DateTime _ExpiryDate;
		private bool _IsTrialUsed;
		private bool _Subscribed;
		public int UserRoleID {
			get { return _UserRoleID; }
			set { _UserRoleID= value; }
		}
		public int UserID {
			get { return _UserID; }
			set { _UserID= value; }
		}
		public string FullName {
			get { return _FullName; }
			set { _FullName= value; }
		}
		public string Email {
			get { return _Email; }
			set { _Email= value; }
		}
		public System.DateTime EffectiveDate {
			get { return _EffectiveDate; }
			set { _EffectiveDate= value; }
		}
		public System.DateTime ExpiryDate {
			get { return _ExpiryDate; }
			set { _ExpiryDate= value; }
		}
		public bool IsTrialUsed {
			get { return _IsTrialUsed; }
			set { _IsTrialUsed= value; }
		}
		public bool Subscribed {
			get { return _Subscribed; }
			set { _Subscribed= value; }
		}
		public override void Fill(System.Data.IDataReader dr)
		{
			base.Fill(dr);
			UserRoleID = Null.SetNullInteger(dr["UserRoleID"]);
			UserID = Null.SetNullInteger(dr["UserID"]);
			FullName = Null.SetNullString(dr["DisplayName"]);
			Email = Null.SetNullString(dr["Email"]);
			EffectiveDate = Null.SetNullDateTime(dr["EffectiveDate"]);
			ExpiryDate = Null.SetNullDateTime(dr["ExpiryDate"]);
			IsTrialUsed = Null.SetNullBoolean(dr["IsTrialUsed"]);
			if (UserRoleID > Null.NullInteger) {
				Subscribed = true;
			}
		}
	}
}
