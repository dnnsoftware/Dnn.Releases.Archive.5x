//
// DotNetNuke - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//

using System.Collections.Generic;
namespace DotNetNuke.Modules.Dashboard.Components.Database
{
	public class DbInfo
	{
		private string _ProductVersion;
		public string ProductVersion {
			get { return _ProductVersion; }
			set { _ProductVersion = value; }
		}
		private string _ServicePack;
		public string ServicePack {
			get { return _ServicePack; }
			set { _ServicePack = value; }
		}
		private string _ProductEdition;
		public string ProductEdition {
			get { return _ProductEdition; }
			set { _ProductEdition = value; }
		}
		private string _SoftwarePlatform;
		public string SoftwarePlatform {
			get { return _SoftwarePlatform; }
			set { _SoftwarePlatform = value; }
		}
		public List<BackupInfo> Backups {
			get { return DatabaseController.GetDbBackups(); }
		}
		public List<DbFileInfo> Files {
			get { return DatabaseController.GetDbFileInfo(); }
		}
	}
}
