using System;
using System.Collections;
//
// DotNetNuke® - http://www.dotnetnuke.com
// Copyright (c) 2002-2010
// by DotNetNuke Corporation
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
// documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
// to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or substantial portions 
// of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
// DEALINGS IN THE SOFTWARE.
//
using System.IO;
using System.Reflection;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Xml;
using DotNetNuke.Framework.Providers;
using DotNetNuke.Services.Exceptions;
using Telerik.Web.UI;
using DotNetNuke.UI.Utilities;
using DotNetNuke.Entities.Modules;
using DotNetNuke.UI;

namespace DotNetNuke.HtmlEditor.TelerikEditorProvider
{

	public class EditorProvider : DotNetNuke.Modules.HTMLEditorProvider.HtmlEditorProvider
	{
		private Panel withEventsField__panel = new Panel();

		#region "Private Members"

		private Panel _panel {
			get { return withEventsField__panel; }
			set {
				if (withEventsField__panel != null) {
					withEventsField__panel.Init -= Panel_Init;
					withEventsField__panel.Load -= Panel_Load;
					withEventsField__panel.PreRender -= Panel_PreRender;
				}
				withEventsField__panel = value;
				if (withEventsField__panel != null) {
					withEventsField__panel.Init += Panel_Init;
					withEventsField__panel.Load += Panel_Load;
					withEventsField__panel.PreRender += Panel_PreRender;
				}
			}
		}
		private RadEditor withEventsField__editor = new RadEditor();
		private RadEditor _editor {
			get { return withEventsField__editor; }
			set {
				if (withEventsField__editor != null) {
					withEventsField__editor.Load -= RadEditor_Load;
				}
				withEventsField__editor = value;
				if (withEventsField__editor != null) {
					withEventsField__editor.Load += RadEditor_Load;
				}
			}

		}
		//properties that will be skipped during ConfigFile processing

		private string _propertiesNotSupported = ",ContentProviderTypeName,ToolProviderID,Modules,AllowScripts,DialogHandlerUrl,RegisterWithScriptManager,ClientStateFieldID,Enabled,Visible,ControlStyleCreated,HasAttributes,ClientID,ID,EnableViewState,NamingContainer,BindingContainer,Page,TemplateControl,Parent,TemplateSourceDirectory,AppRelativeTemplateSourceDirectory,Site,UniqueID,Controls,ViewState,ViewStateIgnoreCase,";
		//default paths for the editor file browser dialogs (portal based)

		private System.String[] _portalRootPath = new string[] { FileSystemValidation.EndUserHomeDirectory };
		//config file settings
		private bool _isControlInitialized = false;

		private bool _languageSet = false;
		private const string ProviderType = "htmlEditor";
		private static ProviderConfiguration _providerConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType);

		private DotNetNuke.Framework.Providers.Provider objProvider = (DotNetNuke.Framework.Providers.Provider)_providerConfiguration.Providers[_providerConfiguration.DefaultProvider];
			#endregion
		private Exception _TrackException = null;

		#region "Properties"

		private ArrayList _additionalToolbars;
		public override ArrayList AdditionalToolbars {
			get { return _additionalToolbars; }
			set { _additionalToolbars = value; }
		}

		public override string ControlID {
			get { return _editor.ID; }
			set { _editor.ID = value; }
		}

		public override Unit Height {
			get { return _editor.Height; }
			set {
				if ((!value.IsEmpty)) {
					_editor.Height = value;
				}
			}
		}

		public override Control HtmlEditorControl {
			get { return (Control)_panel; }
		}

		private string _rootImageDirectory = string.Empty;
		public override string RootImageDirectory {
			get {
				if ((string.IsNullOrEmpty(_rootImageDirectory))) {
					return PortalSettings.HomeDirectory;
				} else {
					return _rootImageDirectory;
				}
			}
			set { _rootImageDirectory = value; }
		}

		public override string Text {
			get { return _editor.Content; }
			set { _editor.Content = value; }
		}

		public override Unit Width {
			get { return _editor.Width; }
			set {
				if ((!value.IsEmpty)) {
					_editor.Width = value;
				}
			}
		}

		private string _toolsFile = string.Empty;
		public string ToolsFile {
			get {
				if ((string.IsNullOrEmpty(_toolsFile) && (objProvider.Attributes["ToolsFile"] != null))) {
					_toolsFile = objProvider.Attributes["ToolsFile"];
				}

				return _toolsFile;
			}
			set
			{
			    _editor.ToolsFile = value;
                _toolsFile = value;
			}
		}

		private string _configFile = string.Empty;
		public string ConfigFile {
			get {
				if ((string.IsNullOrEmpty(_configFile) && (objProvider.Attributes["ConfigFile"] != null))) {
					_configFile = objProvider.Attributes["ConfigFile"];
				}

				return _configFile;
			}
			set {
				_configFile = value;
				if ((_isControlInitialized)) {
					ProcessConfigFile();
				}
			}
		}

		private bool _filterHostExtensions = true;
		public bool FilterHostExtensions {
			get { return _filterHostExtensions; }
			set { _filterHostExtensions = value; }
		}

		private string _providerPath = string.Empty;
		public string ProviderPath {
			get {
				if ((string.IsNullOrEmpty(_providerPath) && (objProvider.Attributes["providerPath"] != null))) {
					_providerPath = objProvider.Attributes["providerPath"];
				} else {
					_providerPath = "~/Providers/HtmlEditorProviders/Telerik/";
				}

				if ((!_providerPath.EndsWith("/"))) {
					_providerPath = _providerPath + "/";
				}

				return _providerPath;
			}
		}

		#endregion

		#region "Public Methods"

		public override void AddToolbar()
		{
		}

		public override void Initialize()
		{
			_panel.Init += new EventHandler(Panel_Init);
			_panel.Load += new EventHandler(Panel_Load);
			_panel.PreRender += new EventHandler(Panel_PreRender);
			_editor.Load += new EventHandler(RadEditor_Load);
			try {
				//initialize the control
				LoadEditorProperties();
				_isControlInitialized = true;
				_editor.EnableViewState = false;
				_editor.ExternalDialogsPath = ProviderPath + "Dialogs/";

				if ((!string.IsNullOrEmpty(ToolsFile))) {
					//this will check if the file exists
					GetFilePath(ToolsFile, "tools file");
					_editor.ToolsFile = ToolsFile;
				}

				ProcessConfigFile();
			} catch (Exception ex) {
				_TrackException = new Exception("Could not load RadEditor. " + Environment.NewLine + ex.Message, ex);
				Exceptions.LogException(_TrackException);
			}
		}

		protected void Panel_Init(object sender, EventArgs e)
		{
			try {
				if (((_TrackException == null))) {
					//Add save template js and gif
					_panel.Controls.Add(new LiteralControl("<script type=\"text/javascript\" src=\"" + _panel.Page.ResolveUrl(ProviderPath + "js/RegisterDialogs.js") + "\"></script>"));
					_panel.Controls.Add(new LiteralControl("<script type=\"text/javascript\">var __textEditorSaveTemplateDialog = \"" + _panel.Page.ResolveUrl(ProviderPath + "Dialogs/SaveTemplate.aspx") + "\";</script>"));
					_panel.Controls.Add(new LiteralControl("<style type=\"text/css\">.reTool .SaveTemplate { background-image: url('" + _panel.Page.ResolveUrl(ProviderPath + "images/SaveTemplate.gif") + "'); }</style>"));

					_panel.Controls.Add(_editor);
				}
			} catch (Exception ex) {
				_TrackException = new Exception("Could not load RadEditor." + Environment.NewLine + ex.Message, ex);
				Exceptions.LogException(_TrackException);
			}
		}

		protected void Panel_Load(object sender, EventArgs e)
		{
			try {
				if (((_TrackException == null))) {
					//register the override CSS file to take care of the DNN default skin problems
					string cssOverrideUrl = _panel.Page.ResolveUrl(ProviderPath + "EditorOverride.css");
					ScriptManager pageScriptManager = ScriptManager.GetCurrent(_panel.Page);
					if (((pageScriptManager != null)) && (pageScriptManager.IsInAsyncPostBack)) {
						_panel.Controls.Add(new LiteralControl(string.Format("<link title='Telerik stylesheet' type='text/css' rel='stylesheet' href='{0}'></link>", _panel.Page.Server.HtmlEncode(cssOverrideUrl))));
					} else if ((_panel.Page.Header != null)) {
						HtmlLink link = new HtmlLink();
						link.Href = cssOverrideUrl;
						link.Attributes.Add("type", "text/css");
						link.Attributes.Add("rel", "stylesheet");
						link.Attributes.Add("title", "Telerik stylesheet");
						_panel.Page.Header.Controls.Add(link);
					}
				}
			} catch (Exception ex) {
				_TrackException = new Exception("Could not load RadEditor." + Environment.NewLine + ex.Message, ex);
				Exceptions.LogException(_TrackException);
			}
		}

		protected void Panel_PreRender(object sender, EventArgs e)
		{
			try {
				//Exceptions are causing a stream of other NullReferenceExceptions
				//as a work around, track the exception and print out
				if (((_TrackException != null))) {
					_panel.Controls.Clear();
					_panel.Controls.Add(new LiteralControl(_TrackException.Message));
				}
                PortalModuleBase parentModule = ControlUtilities.FindParentControl<PortalModuleBase>(HtmlEditorControl);
                int moduleid = Convert.ToInt32(parentModule == null ? -1 : parentModule.ModuleId);
                int portalId = Convert.ToInt32(parentModule == null ? -1 : parentModule.PortalId);
                int tabId = Convert.ToInt32(parentModule == null ? -1 : parentModule.TabId);
                ClientAPI.RegisterClientVariable(HtmlEditorControl.Page, "editorModuleId", moduleid.ToString(), true);
                ClientAPI.RegisterClientVariable(HtmlEditorControl.Page, "editorTabId", tabId.ToString(), true);
                ClientAPI.RegisterClientVariable(HtmlEditorControl.Page, "editorPortalId", portalId.ToString(), true);
                ClientAPI.RegisterClientVariable(HtmlEditorControl.Page, "editorHomeDirectory", PortalSettings.HomeDirectory, true);
                ClientAPI.RegisterClientVariable(HtmlEditorControl.Page, "editorPortalGuid", PortalSettings.GUID.ToString(), true);
                ClientAPI.RegisterClientVariable(HtmlEditorControl.Page, "editorEnableUrlLanguage", PortalSettings.EnableUrlLanguage.ToString(), true);

			} catch (Exception ex) {
				throw ex;
			}
		}

		protected void RadEditor_Load(object sender, EventArgs e)
		{
			try {
				if (((_TrackException == null))) {
					SetLanguage();

					//set content paths to portal root
					SetContentPaths(_editor.ImageManager);
					SetContentPaths(_editor.FlashManager);
					SetContentPaths(_editor.MediaManager);
					SetContentPaths(_editor.DocumentManager);
					SetContentPaths(_editor.TemplateManager);
					SetContentPaths(_editor.SilverlightManager);

					//set content provider type
					Type providerType = typeof(PortalContentProvider);
					string providerName = providerType.FullName + ", " + providerType.Assembly.FullName;
					_editor.ImageManager.ContentProviderTypeName = providerName;
					_editor.DocumentManager.ContentProviderTypeName = providerName;
					_editor.FlashManager.ContentProviderTypeName = providerName;
					_editor.MediaManager.ContentProviderTypeName = providerName;
					_editor.SilverlightManager.ContentProviderTypeName = providerName;
					_editor.TemplateManager.ContentProviderTypeName = providerName;

					//SetSearchPatterns
					//telerik defaults + dnn extensions filter
					string patterns = string.Empty;
					patterns = "*.gif, *.xbm, *.xpm, *.png, *.ief, *.jpg, *.jpe, *.jpeg, *.tiff, *.tif, *.rgb, *.g3f, *.xwd, *.pict, *.ppm, *.pgm, *.pbm, *.pnm, *.bmp, *.ras, *.pcd, *.cgm, *.mil, *.cal, *.fif, *.dsf, *.cmx, *.wi, *.dwg, *.dxf, *.svf".Replace(", ", ",");
					SetFileManagerSearchPatterns(_editor.ImageManager, patterns);
					patterns = ("*.doc, *.txt, *.docx, *.xls, *.xlsx, *.pdf" + ", *.ppt, *.pptx, *.xml, *.zip").Replace(", ", ",");
					SetFileManagerSearchPatterns(_editor.DocumentManager, patterns);
					patterns = "*.swf".Replace(", ", ",");
					SetFileManagerSearchPatterns(_editor.FlashManager, patterns);
					patterns = "*.wma, *.wmv, *.avi, *.wav, *.mpeg, *.mpg, *.mpe, *.mp3, *.m3u, *.mid, *.midi, *.snd, *.mkv".Replace(", ", ",");
					SetFileManagerSearchPatterns(_editor.MediaManager, patterns);
					patterns = "*.xap".Replace(", ", ",");
					SetFileManagerSearchPatterns(_editor.SilverlightManager, patterns);
					patterns = "*.htmtemplate, *.htm, *,html".Replace(", ", ",");
					SetFileManagerSearchPatterns(_editor.TemplateManager, patterns);

					//Can't set individual dialogdefinitions because they are not available, instead set globally for all dialogs
					//this is done to fix problem with TemplateManager Window not reloading after saving a template
					_editor.DialogOpener.Window.ReloadOnShow = true;

					//Set dialog handlers
					string tempHandlerUrl = "Telerik.Web.UI.DialogHandler.aspx?tabid=" + PortalSettings.ActiveTab.TabID.ToString();
					_editor.DialogHandlerUrl = _panel.Page.ResolveUrl(ProviderPath + tempHandlerUrl);
					tempHandlerUrl = "Telerik.Web.UI.SpellCheckHandler.ashx?tabid=" + PortalSettings.ActiveTab.TabID.ToString();
					_editor.SpellCheckSettings.AjaxUrl = _panel.Page.ResolveUrl(ProviderPath + tempHandlerUrl);
				}
			} catch (Exception ex) {
				_TrackException = new Exception("Could not load RadEditor." + Environment.NewLine + ex.Message, ex);
				Exceptions.LogException(_TrackException);
			}
		}

		#endregion

		#region "Config File related code"

		private string GetFilePath(string path, string fileDescription)
		{
			string convertedPath = path;
			if (convertedPath.StartsWith("~") || convertedPath.StartsWith("~")) {
				convertedPath = _panel.ResolveUrl(path);
			}

			convertedPath = Context.Request.MapPath(convertedPath);
			if (!File.Exists(convertedPath)) {
				throw new Exception("Invalid " + fileDescription + ". Check provider settings in the web.config: " + path);
			}

			return convertedPath;
		}

		private XmlDocument GetValidConfigFile()
		{
			XmlDocument xmlConfigFile = new XmlDocument();
			try {
				xmlConfigFile.Load(GetFilePath(ConfigFile, "config file"));
			} catch (Exception generatedExceptionName) {
				throw new Exception("Invalid Configuration File:" + ConfigFile);
			}
			return xmlConfigFile;
		}

		//don't allow property assignment of certain base control properties
		private void ProcessConfigFile()
		{
			if (ConfigFile != string.Empty) {
				XmlDocument xmlDoc = GetValidConfigFile();
				foreach (XmlNode node in xmlDoc.DocumentElement.ChildNodes) {
					if (node.Attributes == null || node.Attributes["name"] == null) {
						continue;
					}

					string propertyName = node.Attributes["name"].Value;
					string propValue = node.InnerText;

					if ((propertyName.ToLower() == "cssfiles")) {
						AddCssFiles(propValue);
						continue;
					}

					//don't allow property assignment of certain base control properties
					if ((_propertiesNotSupported.Contains("," + propertyName + ","))) {
						throw new NotSupportedException("Property assignment is not supported [" + propertyName + "]");
					}

					//use reflection to set all string, integer, long, short, bool, enum properties
					SetEditorProperty(_editor, propertyName, propValue);
				}
			}
		}

		private void SetEditorProperty(object source, string propName, string propValue)
		{
			string[] properties = propName.Split('.');

			if ((properties.Length > 0)) {
				for (int i = 0; i <= properties.Length - 2; i++) {
					if ((_propertiesNotSupported.Contains("," + properties[i] + ","))) {
						throw new NotSupportedException("Property assignment is not supported for this property FullPath:[" + propName + "] Property:[" + properties[i] + "]");
					}

					PropertyInfo prop = source.GetType().GetProperty(properties[i]);
					if ((prop == null)) {
						throw new NotSupportedException("Property does not exist. FullPath:[" + propName + "] Property:[" + properties[i] + "]");
					}

					source = prop.GetValue(source, null);
					if ((source == null)) {
						throw new NotSupportedException("Property does not exist or is null. FullPath:[" + propName + "] Property:[" + properties[i] + "]");
					}
				}
				SetProperty(source, properties[properties.Length - 1], propValue);
			}
		}

		private void SetProperty(object source, string propName, string propValue)
		{
			try {
				if ((source == null)) {
					return;
				}
				//Dim pi As PropertyInfo = DotNetNuke.Common.Utilities.DataCache.GetCache(Of PropertyInfo)("Telerik.EditorProvider." + propName + ".InfoCache")
				//If (pi Is Nothing) Then
				//	pi = _editor.GetType().GetProperty(propName)
				//	DotNetNuke.Common.Utilities.DataCache.SetCache("Telerik.EditorProvider." + propName + ".InfoCache", pi)
				//End If

				propValue = GetFileValueVirtualPath(propValue);

				PropertyInfo pi = source.GetType().GetProperty(propName);
				object propObj = null;
				if ((pi != null)) {
					if (pi.PropertyType.Equals(typeof(string))) {
						pi.SetValue(source, propValue, null);
					} else if (pi.PropertyType.Equals(typeof(bool))) {
						pi.SetValue(source, bool.Parse(propValue), null);
					} else if (pi.PropertyType.Equals(typeof(Unit))) {
						pi.SetValue(source, Unit.Parse(propValue), null);
					} else if (pi.PropertyType.Equals(typeof(int))) {
						pi.SetValue(source, int.Parse(propValue), null);
					} else if (pi.PropertyType.Equals(typeof(short))) {
						pi.SetValue(source, short.Parse(propValue), null);
					} else if (pi.PropertyType.Equals(typeof(long))) {
						pi.SetValue(source, long.Parse(propValue), null);
					} else if (pi.PropertyType.BaseType.Equals(typeof(System.Enum))) {
						pi.SetValue(source, System.Enum.Parse(pi.PropertyType, propValue), null);
					} else if (pi.PropertyType.Equals(typeof(string[]))) {
						pi.SetValue(source, propValue.Split(','), null);
					} else if (pi.PropertyType.Equals(typeof(Telerik.Web.UI.EditorFontCollection))) {
						propObj = pi.GetValue(source, null);
						if (((propObj != null))) {
							((Telerik.Web.UI.EditorFontCollection)propObj).Add(propValue);
						}
					} else if (pi.PropertyType.Equals(typeof(Telerik.Web.UI.EditorFontSizeCollection))) {
						propObj = pi.GetValue(source, null);
						if (((propObj != null))) {
							((Telerik.Web.UI.EditorFontSizeCollection)propObj).Add(propValue);
						}
					} else if (pi.PropertyType.Equals(typeof(Telerik.Web.UI.EditorRealFontSizeCollection))) {
						propObj = pi.GetValue(source, null);
						if (((propObj != null))) {
							((Telerik.Web.UI.EditorRealFontSizeCollection)propObj).Add(propValue);
						}
					} else if (pi.PropertyType.Equals(typeof(Telerik.Web.UI.EditorSymbolCollection))) {
						propObj = pi.GetValue(source, null);
						if (((propObj != null))) {
							((Telerik.Web.UI.EditorSymbolCollection)propObj).Add(propValue);
						}
					} else if (pi.PropertyType.Equals(typeof(Telerik.Web.UI.EditorColorCollection))) {
						propObj = pi.GetValue(source, null);
						if (((propObj != null))) {
							((Telerik.Web.UI.EditorColorCollection)propObj).Add(propValue);
						}
					} else if (pi.PropertyType.Equals(typeof(Telerik.Web.UI.EditorParagraphCollection))) {
						propObj = pi.GetValue(source, null);
						if (((propObj != null))) {
							((Telerik.Web.UI.EditorParagraphCollection)propObj).Add(propValue, "." + propValue);
						}
					}
				}
				if ((propName == "Language")) {
					_languageSet = true;
				}
			} catch (Exception ex) {
				throw new Exception("Error parsing config file Type:[" + source.GetType().ToString() + "] Property:[" + propName + "] Error:[" + ex.Message + "]", ex);
			}
		}

		private void AddCssFiles(string cssFiles)
		{
			string[] files = cssFiles.Split(',');

			if (files.Length > 0) {
				_editor.CssFiles.Clear();
				string cssfile = null;
				foreach (string cssfile_loopVariable in files) {
					cssfile = cssfile_loopVariable;
					cssfile = GetFileValueVirtualPath(cssfile);
					_editor.CssFiles.Add(cssfile);
				}
			}
		}

		private string GetFileValueVirtualPath(string propValue)
		{
			if ((propValue.StartsWith("[PortalRoot]") || propValue.StartsWith("[ProviderPath]") || propValue.StartsWith("~"))) {
				propValue = propValue.Replace("[PortalRoot]", PortalSettings.HomeDirectory);
				propValue = propValue.Replace("[ProviderPath]", ProviderPath);
				if ((propValue.StartsWith("~"))) {
					propValue = _panel.ResolveUrl(propValue);
				}
			}

			return propValue;
		}

		#endregion

		#region "Private Helper Methods"

		private void SetLanguage()
		{
			_editor.LocalizationPath = ProviderPath + "App_LocalResources/";

			if ((!_languageSet)) {
				string localizationLang = string.Empty;
				//first check portal settings
				localizationLang = PortalSettings.DefaultLanguage;
				//then check if language cookie is present
				if ((_panel.Page.Request.Cookies["language"] != null)) {
					string cookieValue = _panel.Page.Request.Cookies.Get("language").Value;
					localizationLang = cookieValue;
				}
				//set new value
				if ((localizationLang != string.Empty)) {
					_editor.Language = localizationLang;
				}
			}
		}

		private void SetContentPaths(FileManagerDialogConfiguration manager)
		{
			if (((manager.ViewPaths == null) || manager.ViewPaths.Length < 1)) {
				manager.ViewPaths = _portalRootPath;
			}
			if (((manager.UploadPaths == null) || manager.UploadPaths.Length < 1)) {
				manager.UploadPaths = _portalRootPath;
			}
			if (((manager.DeletePaths == null) || manager.DeletePaths.Length < 1)) {
				manager.DeletePaths = _portalRootPath;
			}
		}

		private void SetFileManagerSearchPatterns(Telerik.Web.UI.FileManagerDialogConfiguration dialogConfig, string patterns)
		{
			if (((dialogConfig.SearchPatterns == null) || dialogConfig.SearchPatterns.Length < 1)) {
				dialogConfig.SearchPatterns = ApplySearchPatternFilter(patterns.Split(','));
			} else {
				dialogConfig.SearchPatterns = ApplySearchPatternFilter(dialogConfig.SearchPatterns);
			}
		}

		private void RemoveTool(string sToolName)
		{
			EditorToolGroup toolbar = null;
			foreach (EditorToolGroup toolbar_loopVariable in _editor.Tools) {
				toolbar = toolbar_loopVariable;
				EditorTool toolRef = toolbar.FindTool(sToolName);
				if ((toolRef != null)) {
					toolbar.Tools.Remove(toolRef);
				}
			}
		}

		private void LoadEditorProperties()
		{
			try {
				if ((objProvider.Attributes["ConfigFile"] != null))
					_configFile = objProvider.Attributes["ConfigFile"];
				if ((objProvider.Attributes["ToolsFile"] != null))
					_toolsFile = objProvider.Attributes["ToolsFile"];
			} catch (Exception exc) {
				throw new Exception("Could not load RadEditor! Error while loading provider attributes: " + exc.Message);
			}
		}

		private string[] ApplySearchPatternFilter(string[] patterns)
		{
			if ((!FilterHostExtensions)) {
				return patterns;
			}

			ArrayList returnPatterns = new ArrayList();
			string hostExtensions = DotNetNuke.Entities.Host.Host.FileExtensions.ToLowerInvariant().Replace(" ", "");

			if ((patterns.Length == 1 && patterns[0] == "*.*")) {
				//Include all host partterns
				foreach (string pattern in hostExtensions.Split(',')) {
					returnPatterns.Add("*." + pattern);
				}
			} else {
				foreach (string pattern in patterns) {
					string p = pattern.Replace("*.", "").ToLowerInvariant();
					if ((("," + hostExtensions + ",").IndexOf("," + p + ",") > -1)) {
						returnPatterns.Add("*." + p);
					}
				}
			}

			return (string[])returnPatterns.ToArray(typeof(string));
		}

		#endregion

	}

}
