﻿(function($) {
	$.fn.dnnConsole = function(options) {
		var opts = $.extend({}, $.fn.dnnConsole.defaults, options);

		$(this).find("img").each(function() {
			this.style.borderWidth = "0px";
		});

		if (opts.showTooltip) {
			$(this).find("div > div").each(function() {
				var $this = $(this);
				var $title = $this.find("h3");

				if ($title.length > 0) {
					this.title = $title[0].innerHTML;

					var tracking = !$.browser.msie;
					$this.cluetip(
					function() { return $this.find("div")[0].innerHTML; },
					{
						dropShadow: true,
						showTitle: true,
						arrows: false,
						local: true,
						tracking: tracking,
						positionBy: 'mouse',
						topOffset: -25,
						leftOffset: 0,
						cursor: 'pointer',
						onActivate: function() { return ($this[0].className.indexOf("detail") == -1); }
					}
				);
				}
			});
		}

		function _changeView(jObj) {
			var style = opts.selectedSize == "IconFile" ? "console-small" : "console-large";
			style += opts.showDetails == "Show" ? "-detail" : "";

			if (opts.selectedSize == "IconFile") {
				$(jObj).find("div > div img").hide();
				$(jObj).find("div > div img:first-child").show();
			}
			else {
				$(jObj).find("div > div img").show();
				$(jObj).find("div > div img:first-child").hide();
			}

			$(jObj).find("div").removeClass(opts.currentClass).addClass(style);

			opts.currentClass = style;
		}

		$(this).find("div > div").bind(
			"click"
			, function() {
				if ($(this).children("a").length > 0)
					window.location.href = $(this).children("a")[0].href;
			}
		);

		$(this).find("div > div").hover(
			function(e) { $(this).addClass("console-mouseon"); }
			, function(e) { $(this).removeClass("console-mouseon"); }
		);

		var self = this;
		$(this).find("select").bind("change", function() {
			var data = "";
			if (this.value == "IconFile" || this.value == "IconFileLarge") {
				opts.selectedSize = this.value;
				data = "CS=" + opts.selectedSize;
			}
			if (this.value == "Show" || this.value == "Hide") {
				opts.showDetails = this.value;
				data = "CV=" + opts.showDetails;
			}

			_changeView(self, opts);

			if (data != "") {
				if (opts.tabModuleID.toString() != "-1") {
					data = data + "&CTMID=" + opts.tabModuleID.toString();
					$.ajax({
						type: 'get',
						data: data,
						error: function() {
							return;
						},
						success: function(msg) {
							return;
						}
					});
				}
			}
		});

		_changeView(this);

		//this[0].style.display = "inline";
		return this;
	};

	$.fn.dnnConsole.defaults = { allowIconSizeChange: true, allowDetailChange: true, selectedSize: 'IconFile', showDetails: 'Hide', showTooltip: true };
})(jQuery);
