'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2009
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports DotNetNuke.Application
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Services.Installer
Imports DotNetNuke.Services.Installer.Packages
Imports DotNetNuke.Services.Installer.Writers

Namespace DotNetNuke.Modules.Admin.Languages
    Partial Class LanguagePackWriter
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase

        Private packageWriter As DotNetNuke.Services.Installer.Writers.LanguagePackWriter

        Private Sub CreateModulePackage(ByVal desktopModule As DesktopModuleInfo)
            'Get the Module Package
            Dim modulePackage As PackageInfo = PackageController.GetPackage(desktopModule.PackageID)

            Dim Package As New PackageInfo()
            Package.Name = modulePackage.Name
            Package.FriendlyName = modulePackage.Name
            Package.Version = modulePackage.Version
            Package.License = Util.PACKAGE_NoLicense

            Dim fileName As String = Path.Combine(HostMapPath, "ResourcePack." & Package.Name)

            CreatePackage(Package, modulePackage.PackageID, Path.Combine("DesktopModules\", desktopModule.FolderName), fileName)
        End Sub
        Private Sub CreateCorePackage()
            Dim Package As New PackageInfo()
            Package.Name = DotNetNuke.Common.Globals.CleanFileName(txtFileName.Text)
            Package.Version = DotNetNukeContext.Current.Application.Version
            Package.License = Util.PACKAGE_NoLicense

            Dim fileName As String = Path.Combine(HostMapPath, "ResourcePack." & Package.Name)

            CreatePackage(Package, -2, "", fileName)
        End Sub
        Private Sub CreatePackage(ByVal package As PackageInfo, ByVal dependentPackageID As Integer, ByVal basePath As String, ByVal fileName As String)
            Dim manifest As String

            Dim language As Locale = Localization.GetLocale(cboLanguage.SelectedValue)
            Dim languagePack As New LanguagePackInfo()
            languagePack.LanguageID = language.LanguageID
            languagePack.DependentPackageID = dependentPackageID

            If dependentPackageID = -2 Then
                package.PackageType = "CoreLanguagePack"
            Else
                package.PackageType = "ExtensionLanguagePack"
            End If

            package.Name += " " + language.Text
            package.FriendlyName += " " + language.Text

            packageWriter = PackageWriterFactory.GetWriter(package)
            packageWriter.Language = language
            packageWriter.LanguagePack = languagePack
            packageWriter.BasePath = basePath
            packageWriter.GetFiles(False)
            manifest = packageWriter.WriteManifest(True)

            fileName = fileName & "." & package.Version.ToString(3) & "." & language.Code & ".zip"

            packageWriter.CreatePackage(fileName, package.Name + ".dnn", manifest, True)
        End Sub

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If Not Page.IsPostBack Then
                For Each language As Locale In Localization.GetLocales(Null.NullInteger).Values
                    cboLanguage.Items.Add(New ListItem(language.Text, language.Code))
                Next

                rowitems.Visible = False
            End If
        End Sub

        Private Sub rbPackType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbPackType.SelectedIndexChanged
            pnlLogs.Visible = False
            Select Case rbPackType.SelectedValue
                Case "Core"
                    rowitems.Visible = False
                    txtFileName.Text = "Core"
                    lblFilenameFix.Text = Server.HtmlEncode(".<version>.<locale>.zip")
                    rowFileName.Visible = True
                Case "Module"
                    rowitems.Visible = True
                    lstItems.Items.Clear()
                    lstItems.ClearSelection()
                    For Each objDM As DesktopModuleInfo In DesktopModuleController.GetDesktopModules(Null.NullInteger).Values
                        If Not objDM.FolderName.StartsWith("Admin/") Then
                            If Null.IsNull(objDM.Version) Then
                                lstItems.Items.Add(New ListItem(objDM.FriendlyName, objDM.DesktopModuleID))
                            Else
                                lstItems.Items.Add(New ListItem(objDM.FriendlyName + " [" + objDM.Version + "]", objDM.DesktopModuleID))
                            End If
                        End If
                    Next
                    lblItems.Text = Localization.GetString("SelectModules", LocalResourceFile)
                    rowFileName.Visible = False
                Case "Provider"
                    rowitems.Visible = True
                    lstItems.Items.Clear()
                    lstItems.ClearSelection()

                    Dim objFolder As New DirectoryInfo(Server.MapPath("~/Providers/HtmlEditorProviders"))
                    For Each folder As DirectoryInfo In objFolder.GetDirectories()
                        lstItems.Items.Add(New ListItem(folder.Name, folder.Name))
                    Next

                    rowFileName.Visible = False
                Case "Full"
                    rowitems.Visible = False
                    txtFileName.Text = "Full"
                    lblFilenameFix.Text = Server.HtmlEncode(".<version>.<locale>.zip")
                    rowFileName.Visible = True
            End Select
        End Sub

        Private Sub cmdCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCreate.Click
            Select Case rbPackType.SelectedValue
                Case "Core"
                    CreateCorePackage()
                Case "Module"
                    For Each moduleItem As ListItem In lstItems.Items
                        If moduleItem.Selected Then
                            'Get the Module
                            Dim desktopModule As DesktopModuleInfo = DesktopModuleController.GetDesktopModule(Integer.Parse(moduleItem.Value), Null.NullInteger)
                            CreateModulePackage(desktopModule)
                        End If
                    Next
                Case "Provider"
                Case "Full"
                    CreateCorePackage()
                    For Each desktopModule As DesktopModuleInfo In DesktopModuleController.GetDesktopModules(Null.NullInteger).Values
                        If Not desktopModule.FolderName.StartsWith("Admin/") Then
                            CreateModulePackage(desktopModule)
                        End If
                    Next
            End Select
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL())
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
#End Region

    End Class
End Namespace