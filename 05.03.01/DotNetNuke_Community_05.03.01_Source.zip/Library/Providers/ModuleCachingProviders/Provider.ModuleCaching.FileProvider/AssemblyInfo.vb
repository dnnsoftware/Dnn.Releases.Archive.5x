﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("DotNetNuke Module Caching File Provider")> 
<Assembly: AssemblyDescription("DotNetNuke Module Caching File Provider")> 
<Assembly: AssemblyCompany("DotNetNuke Corporation")> 
<Assembly: AssemblyProduct("http://www.dotnetnuke.com")> 
<Assembly: AssemblyCopyright("DotNetNuke is Copyright 2002-2009 DotNetNuke Corporation")> 
<Assembly: AssemblyTrademark("DotNetNuke")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("b67a0fc1-3060-4035-ac14-c935bea3e25a")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("5.2.1.0")> 
<Assembly: AssemblyFileVersion("5.2.1.0")> 
